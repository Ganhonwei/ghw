package ftype

import (
	"server/internals/generated/core"
	"server/internals/generated/webapi/gm/pbauth"
	"server/internals/generated/webapi/pbbase"
	"server/internals/generated/webapi/plat/platactivity"
	"time"
)

type ConfigItem pbbase.ConfigItem
type Config []*ConfigItem

var DefaultValueConfig = Config{}

type PriceOpts []int64

var PriceOptsDefaultValue = PriceOpts{}

type RechargeWayOpt struct {
	Code         string       `json:"code,omitempty"`           //支付方式标识
	ThirdCode    string       `json:"third_code,omitempty"`     //第三方支付标识
	Input        bool         `json:"input,omitempty"`          //是否自由输入
	Opts         PriceOpts    `json:"opts,omitempty"`           //挡位
	OptsFav      PriceFavOpts `json:"opts_fav,omitempty"`       //挡位优惠
	Min          int64        `json:"min,omitempty"`            //最小值
	Max          int64        `json:"max,omitempty"`            //最大值
	IsPayerName  bool         `json:"is_payer_name,omitempty"`  //是否需要输入付款人真实名称
	IsUserMobile bool         `json:"is_user_mobile,omitempty"` //是否需要输入付款人手机号
	PayUrlType   int          `json:"pay_url_type,omitempty"`   //支付页面打开方式
}

type PriceFavOpts []PriceFavOpt

type PriceFavOpt struct {
	Amount    int64 `json:"amount,omitempty"`     //挡位金额
	FavAmount int64 `json:"fav_amount,omitempty"` //优惠金额
	MaxVip    int64 `json:"max_vip,omitempty"`    //最大vip等级(小于等于这个等级才能看到这个档位)
}

type RechargeWayOpts []RechargeWayOpt

var RechargeWayOptsDefaultValue = RechargeWayOpts{}

type BankOpt struct {
	Icon string `json:"icon,omitempty"`
	Code string `json:"code,omitempty"`
}

type BankOpts []BankOpt

var BankOptsDefaultValue = BankOpts{}

type VIPVar struct {
	UpgradeRewardLv  int32           `json:"upgrade_reward_lv,omitempty"`  //已领取升级奖金的等级(废弃)
	RewardNo1        int64           `json:"reward_no_1,omitempty"`        //已领取1号派红奖金YMD:20230305
	RewardNo10       int64           `json:"reward_no_10,omitempty"`       //已领取10号派红奖金YMD:20230305
	RewardNo20       int64           `json:"reward_no_20,omitempty"`       //已领取20号派红奖金YMD:20230305
	UpgradeRewardLvs map[int32]int32 `json:"upgrade_reward_lvs,omitempty"` //已领取升级奖金的等级
	ExclusiveGift    []int32         `json:"exclusive_gift,omitempty"`     //已购买的专属礼包
	HighGift         []int32         `json:"high_gift,omitempty"`          //已购买的高级礼包
	IsRecharged      bool            `json:"is_recharged,omitempty"`       //是否已充值
}

type VIPPool struct {
	BetAmount          int64 //打码触发-打码量
	LossAmount         int64 //亏损触发-亏损量
	LossRechargeAmount int64 //亏损触发-充值
	LossWithdrawAmount int64 //亏损触发-提现
	LossBeforeAmount   int64 //亏损触发-上期剩余金币
}

type TemplateFile struct {
	Type  core.InboxFileType `json:"type,omitempty"`  //类型
	Icon  string             `json:"icon,omitempty"`  //图标
	Name  string             `json:"name,omitempty"`  //名称
	Value string             `json:"value,omitempty"` //值
}

type TemplateConfig struct {
	Code  string            `json:"code,omitempty"`  //模板
	Args  map[string]string `json:"args,omitempty"`  //变量
	Files []*TemplateFile   `json:"files,omitempty"` //附件
}

var TemplateConfigDefaultValue = TemplateConfig{}

type SSKeyValue map[string]string

// 每个游戏商都用此对象保存，自行使用合适的属性保存即可
type SyncGameBetStatus struct {
	StartTime int64 `json:"start_time,omitempty"` //开始时间戳(毫秒)
	EndTime   int64 `json:"end_time,omitempty"`   //结束时间戳(毫秒)
}

// 为了方便，所有游戏商都用此对象保存，允许存在冗余
type GameCompanyConfig struct {
	GameDomain string `json:"game_domain,omitempty"` //游戏域名
	ApiDomain  string `json:"api_domain,omitempty"`  //API域名
}

var GameCompanyConfigDefaultValue = GameCompanyConfig{}

type DeviceOpts []string

var DeviceOptsDefaultValue = DeviceOpts{}

type CpSortOpt struct {
	Id    int64 `json:"id,omitempty"`    //游戏商ID
	Index int64 `json:"index,omitempty"` //排序
	Show  bool  `json:"show,omitempty"`  //是否显示
}

type CpSortOpts []CpSortOpt

var CpSortDefaultValue = CpSortOpts{}

type ShowTagOpts []int64

var ShowTagDefaultValue = ShowTagOpts{}

type UserChannelOpts []int64

var UserChannelDefaultValue = UserChannelOpts{}

type RechargeChannelOpts []int64

var RechargeChannelDefaultValue = RechargeChannelOpts{}

type PkgOpts []string

var PkgOptsDefaultValue = PkgOpts{}

var GoogleConfigDefaultValue = GoogleConfigCfg{}

type GoogleConfigCfg struct {
	Type                    string `json:"type,omitempty"`
	ProjectId               string `json:"project_id,omitempty"`
	PrivateKeyId            string `json:"private_key_id,omitempty"`
	PrivateKey              string `json:"private_key,omitempty"`
	ClientEmail             string `json:"client_email,omitempty"`
	ClientId                string `json:"client_id,omitempty"`
	AuthUri                 string `json:"auth_uri,omitempty"`
	TokenUri                string `json:"token_uri,omitempty"`
	AuthProviderX509CertUrl string `json:"auth_provider_x509_cert_url,omitempty"`
	ClientX509CertUrl       string `json:"client_x509_cert_url,omitempty"`
	UniverseDomain          string `json:"universe_domain,omitempty"`
}

var LbRechargeCfgDefaultValue = []LbRechargeWay{}

type LbRechargeWay struct {
	Amount    int64    `json:"amount,omitempty"`     //充值金额
	FavAmount int64    `json:"fav_amount,omitempty"` //优惠金额
	WayList   []string `json:"way_list,omitempty"`   //充值方式
}

type ApiPathOpts map[string]string

var ApiPathOptsDefaultValue = ApiPathOpts{}

type GameCompanyWarnConfig struct {
	NotRecordMinute int64 `json:"not_record_minute,omitempty"` //x分钟内
	MinNewUser      int64 `json:"min_new_user,omitempty"`      //x分钟内
}

var GameCompanyWarnConfigDefaultValue = GameCompanyWarnConfig{}

type PkgConfig struct {
	ChannelId               int64  `json:"channel_id,omitempty"`       //渠道号(默认值1)
	AfUrl                   string `json:"af_url,omitempty"`           //afurl
	AfKey                   string `json:"af_key,omitempty"`           //afkey
	IsInternalPkg           bool   `json:"is_internal_pkg,omitempty"`  //是否内部包
	IsGooglePkg             bool   `json:"is_google_pkg,omitempty"`    //是否谷歌包
	FbApp                   string `json:"fb_app,omitempty"`           //fbapp
	FbKey                   string `json:"fb_key,omitempty"`           //fbkey
	AdUrl                   string `json:"ad_url,omitempty"`           // adurl
	AdKey                   string `json:"ad_key,omitempty"`           // ad解密key
	AdAppToken              string `json:"ad_app_token,omitempty"`     // ad应用识别码
	AdS2sCode               string `json:"ad_s2s_code,omitempty"`      // ad安全码
	AdLogin                 string `json:"ad_login,omitempty"`         // ad识别码
	AdRegister              string `json:"ad_register,omitempty"`      // ad识别码
	AdFirstDeposit          string `json:"ad_first_deposit,omitempty"` // ad识别码
	AdDeposit               string `json:"ad_deposit,omitempty"`       // ad识别码
	AdWithdraw              string `json:"ad_withdraw,omitempty"`      // ad识别码
	AdReDeposit             string `json:"ad_re_deposit,omitempty"`    // ad识别码
	AdPlaceOrder            string `json:"ad_place_order,omitempty"`   // ad识别码
	AdAppActivated          string `json:"ad_app_activated,omitempty"`
	AdPageSplash            string `json:"ad_page_splash,omitempty"`
	AdPageLogin             string `json:"ad_page_login,omitempty"`
	AdPageLobby             string `json:"ad_page_lobby,omitempty"`
	AdPageGameA             string `json:"ad_page_game_a,omitempty"`
	AdPageWithdraw          string `json:"ad_page_withdraw,omitempty"`
	AdPageRecharge          string `json:"ad_page_recharge,omitempty"`
	AdPagePerson            string `json:"ad_page_person,omitempty"`
	AdPageUpdateDownloaded  string `json:"ad_page_update_downloaded,omitempty"`
	AdPageUpdateDownloading string `json:"ad_page_update_downloading,omitempty"`
	AdPageUpdateTipi        string `json:"ad_page_update_tipi,omitempty"`
	AdPageHotUpdate         string `json:"ad_page_hot_update,omitempty"`
	AdPageHotUpdateFailed   string `json:"ad_page_hot_update_failed,omitempty"`
	AdPageHotUpdateOk       string `json:"ad_page_hot_update_ok,omitempty"`
	AdPageHotUpdateStart    string `json:"ad_page_hot_update_start,omitempty"`
}

var PkgConfigDefaultValue = PkgConfig{}

type Line []int64

var AgentInfo = Line{}

type Turntable struct {
	FreeLottery int64 `json:"free_lottery,omitempty"` //免费抽奖时间
	PrizePool   int64 `json:"prize_pool,omitempty"`   //奖池剩余金额
	Purses      int64 `json:"purses,omitempty"`       //已领取奖励
	OpenPool    int64 `json:"open_pool,omitempty"`    //开启奖池时间
}

var TurntableInfo = Turntable{}

var TemplateFileDefaultValue = []*TemplateFile{}

type ChampionConfig struct {
	DayLastRank   int64 //日榜上次排名
	DayCurrRank   int64 //日榜当前排名
	Day           int64 //日榜奖品日 20240628
	IsDay         bool  //日榜是否领取 1
	WeekLastRank  int64 //周榜上次排名
	WeekCurrRank  int64 //周榜当前排名
	Week          int64 //周榜奖品日：周日的日期
	IsWeek        bool  //周榜是否领取 1
	MonthLastRank int64 //月榜上次排名
	MonthCurrRank int64 //月榜当前排名
	Month         int64 //月榜奖品日：每月末的日期
	IsMonth       bool  //月榜是否领取 1
}

var ChampionConfigDefault = ChampionConfig{}

var CheckInReward = []*platactivity.CheckInRewardType{}

type PclbPrizeOpts []string

var PclbPrizeOptsDefaultValue = PclbPrizeOpts{}

type RandExpConfig struct {
	Id       int64 `json:"id,omitempty"`        //挡位ID
	MinVip   int64 `json:"min_vip,omitempty"`   //最小VIP
	MaxVip   int64 `json:"max_vip,omitempty"`   //最大VIP
	MinValue int64 `json:"min_value,omitempty"` //最小值
	MaxValue int64 `json:"max_value,omitempty"` //最大值
}

var RandExpConfigDefault = []*RandExpConfig{}

var FixedRechargeDefault = []*platactivity.FixedRechargeConfig{}

var LuckyPrizeDefaultValue = []LuckyPrize{}

type LuckyPrize struct {
	PrizeType    int64  `json:"prize_type,omitempty"`    //类型 1.金币 2.成长值
	Code         string `json:"code,omitempty"`          //奖品编号
	FavAmount    int64  `json:"fav_amount,omitempty"`    //优惠金额/成长值
	WithdrawRate int64  `json:"withdraw_rate,omitempty"` //流水倍数
	WinRate      int64  `json:"win_rate,omitempty"`      //中奖概率
}

var LuckyPlayDefaultValue = []LuckyPlay{}

type LuckyPlay struct {
	Name   string `json:"name,omitempty"`   //转盘类型:A / B
	Amount int64  `json:"amount,omitempty"` //金额
	Count  int64  `json:"count,omitempty"`  //次数
}

var LuckyVipPlayDefaultValue = []LuckyVipPlay{}

type LuckyVipPlay struct {
	MinVip int32 `json:"min_vip,omitempty"` //最小VIP
	MaxVip int32 `json:"max_vip,omitempty"` //最大VIP
	ACount int64 `json:"a_count,omitempty"` //A次数
	BCount int64 `json:"b_count,omitempty"` //B次数
}

var WelfareProgressDefaultValue = []*WelfareProgress{}

type WelfareProgress struct {
	Tasktype       int32            `json:"key"`
	Progress       int64            `json:"value"`        // 配置进度
	AccProgress    int64            `json:"acc_progress"` // 玩家进度
	BetGame        map[int64]string `json:"bet_game"`
	LastOnlineTime int64            `json:"last_online_time"`
}

var MonthCheckInDefaultValue = MonthCheckIn{}

type MonthCheckIn struct {
	Days map[int32]*platactivity.MonthCheckInRewardType `json:"days"`
}

type VipMonthCheckIn []int32

var VipMonthCheckInDefaultValue = VipMonthCheckIn{}

type CouponRecharge struct {
	StartTime   int64   `json:"start_time,omitempty"`   //本期开始时间
	RechagedVip []int32 `json:"recharge_vip,omitempty"` //已充值vip
	CurEndTime  int64   `json:"cur_end_time,omitempty"` //当前充值档位结束时间
	CurVip      int32   `json:"cur_vip,omitempty"`      //当前充值档位
	LastVip     int32   `json:"last_vip,omitempty"`     //最后充值档位
}

type LiejiRecharge struct {
	StartTime      int64   `json:"start_time,omitempty"`      //本期开始时间
	Ids            []int32 `json:"ids,omitempty"`             //已获取次数的档次
	RechargeAmount int64   `json:"recharge_amount,omitempty"` //充值金额
	Num            int32   `json:"num,omitempty"`             //可抽奖次数
	DrawNum        int32   `json:"draw_num,omitempty"`        //已抽奖次数
	ResetTime      int64   `json:"reset_time,omitempty"`      //重置时间
}

type Dingyue struct {
	CurId       int32           `json:"cur_id,omitempty"`        //当前生效id
	BuyIds      []int32         `json:"buy_ids,omitempty"`       //已购买id
	IdDays      map[int32]int32 `json:"id_days,omitempty"`       //id对应领取天数
	LastGetTime time.Time       `json:"last_get_time,omitempty"` //最后获取时间
	BuyTime     time.Time       `json:"buy_time,omitempty"`      //购买时间
}

type TGGroup struct {
	Ids []int64 `json:"ids,omitempty"` //群id
}

type LotteryRewards struct {
	Rewards []*pbauth.LotteryReward `json:"rewards,omitempty"` //奖励
}

// 推广用户每日佣金
type AgentDailyCommission []int64

// 拼多多
type Pdd struct {
	TargetAmount  int64                     `json:"target_amount,omitempty"`  //目标金额
	DrawNum       int32                     `json:"draw_num,omitempty"`       //抽奖次数
	Amount        int64                     `json:"amount,omitempty"`         //获得的总金额
	Step          int32                     `json:"step,omitempty"`           //当前阶段
	InviteNum     int32                     `json:"invite_num,omitempty"`     //已邀请用户数
	FreeNum       int32                     `json:"free_num,omitempty"`       //已获得的免费次数
	IsGet         bool                      `json:"is_get,omitempty"`         //是否提现成功
	Rewards       []*platactivity.PddReward `json:"rewards,omitempty"`        //已获得奖励
	RewardId      int32                     `json:"reward_id,omitempty"`      //当前奖励编号
	StepAmount    int64                     `json:"step_amount,omitempty"`    //当前阶段累计获得金额
	InviteAcctIds []int64                   `json:"invite_acctids,omitempty"` //邀请用户id数组
}
