package ftype

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"regexp"
	"strings"

	"entgo.io/ent/dialect/sql"
)

type BigInt struct {
	*big.Int
}

func NewBigInt(i int64) BigInt {
	return BigInt{Int: big.NewInt(i)}
}

var (
	MustBeDigitals  = regexp.MustCompile(`(^0$)|(^[1-9]\d*$)`)
	ErrBigIntFailed = errors.New("BigInt failed to parse: (^0$)|(^[1-9]\\d*$)")
	BigIntValidator = func(s string) error {
		if MustBeDigitals.MatchString(s) {
			return nil
		}
		return ErrBigIntFailed
	}
)

func Parse(v string) (BigInt, error) {
	vv, ok := big.NewInt(0).SetString(v, 10)
	if !ok {
		return BigInt{Int: big.NewInt(0)}, ErrBigIntFailed
	}
	return BigInt{Int: vv}, nil
}

func MustParse(v string) BigInt {
	if v == "" { //todo
		return BigInt{big.NewInt(0)}
	}
	vv, _ := big.NewInt(0).SetString(v, 10)

	return BigInt{Int: vv}
}

func (b *BigInt) UnmarshalJSON(buf []byte) error {
	var s string
	if err := json.Unmarshal(buf, &s); err != nil {
		return err
	}

	if b.Int == nil {
		b.Int = big.NewInt(0)
	}

	_, ok := b.SetString(s, 10)
	if !ok {
		return fmt.Errorf("unexpected type %T for field", s)
	}

	return nil
}

func (b *BigInt) MarshalJSON() ([]byte, error) {
	return json.Marshal(b.String())
}

func (b *BigInt) Scan(src any) error {
	var i sql.NullString
	if err := i.Scan(src); err != nil {
		return err
	}
	if !i.Valid {
		return nil
	}
	if b.Int == nil {
		b.Int = big.NewInt(0)
	}
	// Value came in a floating point format.
	if strings.ContainsAny(i.String, ".+e") {
		f := big.NewFloat(0)
		if _, err := fmt.Sscan(i.String, f); err != nil {
			return err
		}
		b.Int, _ = f.Int(b.Int)
	} else if _, err := fmt.Sscan(i.String, b.Int); err != nil {
		return err
	}
	return nil
}

func (b BigInt) Value() (driver.Value, error) {
	return b.String(), nil
}

func (b BigInt) Add(c BigInt) BigInt {
	b.Int = b.Int.Add(b.Int, c.Int)
	return b
}

func (b BigInt) Mul(c BigInt) BigInt {
	b.Int = b.Int.Mul(b.Int, c.Int)
	return b
}

func (b BigInt) Div(c BigInt) BigInt {
	b.Int = b.Int.Div(b.Int, c.Int)
	return b
}

func (b BigInt) Sub(c BigInt) BigInt {
	b.Int = b.Int.Sub(b.Int, c.Int)
	return b
}

func (b BigInt) Cmp(c BigInt) int {
	return b.Int.Cmp(c.Int)
}

func (b BigInt) Clone() BigInt {
	return BigInt{
		Int: big.NewInt(0).Set(b.Int),
	}
}
