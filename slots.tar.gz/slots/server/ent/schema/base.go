package schema

import (
	"time"
)

var (
	incrementalEnabled  = true // nolint: unused, deadcode, varcheck
	incrementalDisabled = false // nolint: unused, deadcode, varcheck
	unixEpoch           = time.Date(1970, 1, 1, 0, 0, 1, 0, time.UTC)
	unixMax             = time.Date(2038, 1, 19, 3, 14, 7, 0, time.UTC) // mysql timestamp max value 2038-01-19 03:14:07 UTC
)

func IncrementalEnabled() *bool {
	return &incrementalEnabled
}

func IncrementalDisabled() *bool {
	return &incrementalDisabled
}

func NilTime() time.Time {
	return unixEpoch
}

func MaxTime() time.Time {
	return unixMax
}
