package mixin

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"entgo.io/ent/schema/mixin"
)

type Time struct {
	mixin.Schema
}

func (Time) Fields() []ent.Field {
	return append(UpdatedTime{}.Fields(),
		append(CreatedTime{}.Fields(), DeletedTime{}.Fields()...)...,
	)
}

type UpdatedTime struct {
	mixin.Schema
}

func (UpdatedTime) Fields() []ent.Field {
	return []ent.Field{
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now).
			Annotations(entsql.Annotation{
				Default: "CURRENT_TIMESTAMP",
			}),
	}
}

type CreatedTime struct {
	mixin.Schema
}

func (CreatedTime) Fields() []ent.Field {
	return []ent.Field{
		field.Time("created_at").
			Immutable().
			Default(time.Now).
			Annotations(entsql.Annotation{
				Default: "CURRENT_TIMESTAMP",
			}),
	}
}

type CreatedTimeWithIndex struct {
	mixin.Schema
}

func (CreatedTimeWithIndex) Fields() []ent.Field {
	return []ent.Field{
		field.Time("created_at").
			Immutable().
			Default(time.Now).
			Annotations(entsql.Annotation{
				Default: "CURRENT_TIMESTAMP",
			}),
	}
}

func (CreatedTimeWithIndex) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("created_at").Annotations(entsql.Desc()),
	}
}

type DeletedTime struct {
	mixin.Schema
}

func (DeletedTime) Fields() []ent.Field {
	return []ent.Field{
		field.Time("deleted_at").
			Optional(),
	}
}

type ExpireTime struct {
	mixin.Schema
}

func (ExpireTime) Fields() []ent.Field {
	return []ent.Field{
		field.Time("expire_at").
			Optional(),
	}
}
