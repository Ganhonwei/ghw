package mixin

import (
	"entgo.io/ent"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/mixin"
)

type Control struct {
	mixin.Schema
}

func (Control) Fields() []ent.Field {
	return append(CreateBy{}.Fields(),
		UpdateBy{}.Fields()...,
	)
}

type CreateBy struct {
	mixin.Schema
}

func (CreateBy) Fields() []ent.Field {
	return []ent.Field{
		field.Int32("create_by").
			Comment("创建者"),
	}
}

type UpdateBy struct {
	mixin.Schema
}

func (UpdateBy) Fields() []ent.Field {
	return []ent.Field{
		field.Int32("update_by").
			Comment("更新者").Optional(),
	}
}
