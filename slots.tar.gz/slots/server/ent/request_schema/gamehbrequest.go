package request_schema

import (
	"server/ent/schema"
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameHbRequest holds the schema definition for the GameHbRequest entity.
type GameHbRequest struct {
	ent.Schema
}

// Fields of the GameHbRequest.
func (GameHbRequest) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: schema.IncrementalEnabled(),
		}),
		field.String("path").Comment("请求路径"),
		field.String("reference").Comment("交易ID"),
		field.Text("params").Comment("请求参数"),
	}
}

// Edges of the GameHbRequest.
func (GameHbRequest) Edges() []ent.Edge {
	return nil
}

func (GameHbRequest) Indexes() []ent.Index {
	return nil
}

func (GameHbRequest) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
