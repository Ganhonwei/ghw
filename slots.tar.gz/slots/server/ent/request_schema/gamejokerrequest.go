package request_schema

import (
	"server/ent/schema"
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameJokerRequest holds the schema definition for the GameJokerRequest entity.
type GameJokerRequest struct {
	ent.Schema
}

// Fields of the GameJokerRequest.
func (GameJokerRequest) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: schema.IncrementalEnabled(),
		}),
		field.String("path").Comment("请求路径"),
		field.String("reference").Comment("交易ID"),
		field.Text("params").Comment("请求参数"),
	}
}

// Edges of the GameJokerRequest.
func (GameJokerRequest) Edges() []ent.Edge {
	return nil
}

func (GameJokerRequest) Indexes() []ent.Index {
	return nil
}

func (GameJokerRequest) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
