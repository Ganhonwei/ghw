package request_schema

import (
	"server/ent/schema"
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameMgRequest holds the schema definition for the GameMgRequest entity.
type GameMgRequest struct {
	ent.Schema
}

// Fields of the GameMgRequest.
func (GameMgRequest) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: schema.IncrementalEnabled(),
		}),
		field.String("path").Comment("请求路径"),
		field.String("reference").Comment("交易ID"),
		field.Text("params").Comment("请求参数"),
	}
}

// Edges of the GameMgRequest.
func (GameMgRequest) Edges() []ent.Edge {
	return nil
}

func (GameMgRequest) Indexes() []ent.Index {
	return nil
}

func (GameMgRequest) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
