package request_schema

import (
	"server/ent/schema"
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameOneapiRequest holds the schema definition for the GameOneapiRequest entity.
type GameOneapiRequest struct {
	ent.Schema
}

// Fields of the GameOneapiRequest.
func (GameOneapiRequest) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: schema.IncrementalEnabled(),
		}),
		field.String("provider").Optional().Comment("游戏商"),
		field.String("path").Comment("请求路径"),
		field.String("reference").Comment("交易ID"),
		field.Text("params").Comment("请求参数"),
	}
}

// Edges of the GameOneapiRequest.
func (GameOneapiRequest) Edges() []ent.Edge {
	return nil
}

func (GameOneapiRequest) Indexes() []ent.Index {
	return nil
}

func (GameOneapiRequest) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
