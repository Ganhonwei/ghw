package request_schema

import (
	"server/ent/schema"
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameWcRequest holds the schema definition for the GameWcRequest entity.
type GameWcRequest struct {
	ent.Schema
}

// Fields of the GameWcRequest.
func (GameWcRequest) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: schema.IncrementalEnabled(),
		}),
		field.String("provider").Optional().Comment("游戏商"),
		field.String("path").Comment("请求路径"),
		field.String("reference").Comment("交易ID"),
		field.Text("params").Comment("请求参数"),
	}
}

// Edges of the GameWcRequest.
func (GameWcRequest) Edges() []ent.Edge {
	return nil
}

func (GameWcRequest) Indexes() []ent.Index {
	return nil
}

func (GameWcRequest) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
