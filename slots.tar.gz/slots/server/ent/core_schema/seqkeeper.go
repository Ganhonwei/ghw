package core_schema

import (
	"entgo.io/ent"
	"entgo.io/ent/schema/field"
)

// SeqKeeper holds the schema definition for the SeqKeeper entity.
type SeqKeeper struct {
	ent.Schema
}

// Fields of the SeqKeeper.
func (SeqKeeper) Fields() []ent.Field {
	return []ent.Field{
		field.String("key").Unique().MaxLen(64),
		field.Int64("seq").Default(1),
	}
}

// Edges of the SeqKeeper.
func (SeqKeeper) Edges() []ent.Edge {
	return nil
}
