package core_schema

import (
	"server/ent/schema/mixin"
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// GameRecord holds the schema definition for the GameRecord entity.
type GameRecord struct {
	ent.Schema
}

// Fields of the GameRecord.
func (GameRecord) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.Int64("company_id").StructTag("excel:\"游戏商ID\"").Comment("游戏商ID"),
		field.String("company_name").StructTag("excel:\"游戏商名称\"").Comment("游戏商名称"),
		field.Int64("game_id").StructTag("excel:\"游戏ID\"").Comment("游戏ID"),
		field.String("game_name").StructTag("excel:\"游戏名称\"").Comment("游戏名称"),
		field.Int64("channel_id").StructTag("excel:\"账号渠道ID\"").Default(1).Comment("账号渠道ID"),
		field.Int64("partition_id").StructTag("excel:\"账号区服ID\"").Default(1).Comment("账号区服ID"),
		field.Int64("account_id").StructTag("excel:\"玩家账号ID\"").Comment("玩家账号ID"),
		field.String("bet_num").StructTag("excel:\"注单编号\"").Comment("注单编号"), //下注和下注结果必须用这个，格式自己组装比如1：游戏商ID-游戏ID-回合ID，比如2：游戏商ID-游戏ID-三方唯一编号
		field.Time("bet_time").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}).StructTag("excel:\"注单编号\"").Comment("下注时间"),
		field.Int64("valid_bet_amount").StructTag("excel:\"有效下注金额\"").Default(0).Comment("有效下注金额"),
		field.Int64("bet_amount").StructTag("excel:\"下注金额\"").Default(0).Comment("下注金额"),
		field.Int64("win_amount").StructTag("excel:\"输赢金额\"").Default(0).Comment("输赢金额"),
		field.Int64("settl_amount").StructTag("excel:\"结算金额\"").Default(0).Comment("结算金额"), //结算金额=下注金额+输赢金额
		field.Bool("settl_status").StructTag("excel:\"是否结算\"").Default(true).Comment("是否结算"),
		field.Time("settl_time").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}).StructTag("excel:\"结算时间\"").Comment("结算时间"),
		//暂时定义这些字段，暂时不建立实体关系
		field.String("bet_result_id").Optional().Comment("result返回ID"), //下注的交易ID+"-result"
		field.String("third_bet_num").Optional().Comment("第三方注单编号"),    // 因为dcs对接过程中发现需要使用
		field.String("round_id").Optional().Comment("下注局号"),            // 下注局号
	}
}

// Edges of the GameRecord.
func (GameRecord) Edges() []ent.Edge {
	return nil
}

func (GameRecord) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("bet_num", "bet_result_id").Unique(),
		index.Fields("bet_time"),
		index.Fields("account_id", "bet_time"),
		index.Fields("partition_id"),
		index.Fields("company_id", "third_bet_num"),
		index.Fields("company_id", "round_id"),
	}
}

func (GameRecord) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
