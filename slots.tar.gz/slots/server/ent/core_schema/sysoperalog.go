package core_schema

import (
	"server/ent/schema/mixin"
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// SysOperaLog holds the schema definition for the SysOperaLog entity.
type SysOperaLog struct {
	ent.Schema
}

// Fields of the SysOperaLog.
func (SysOperaLog) Fields() []ent.Field {
	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).Comment("主键编码"),
		field.String("title").Comment("操作模块"),
		field.String("business_type").Optional().Comment("操作类型"),
		field.String("business_types").Optional(),
		field.String("method").Comment("函数"),
		field.String("request_method").Comment("请求方式 GET POST PUT DELETE"),
		field.String("operator_type").Optional().Comment("操作类型"),
		field.String("oper_name").Comment("操作者"),
		field.String("dept_name").Optional().Comment("部门名称"),
		field.String("oper_url").Comment("访问地址"),
		field.String("oper_ip").Comment("客户端ip"),
		field.String("oper_location").Optional().Comment("访问位置"),
		field.Text("oper_param").Comment("请求参数"),
		field.String("status").MaxLen(4).Comment("Response Code"),
		field.Time("oper_time").Comment("操作时间").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.Text("json_result").Comment("返回数据"),
		field.String("remark").Optional().Comment("备注"),
		field.String("latency_time").Comment("耗时"),
		field.String("user_agent").Comment("ua"),
		field.Time("created_at").Default(time.Now).Comment("创建时间").Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.Time("updated_at").Default(time.Now).Comment("最后更新时间").Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
	}
}

// Edges of the SysOperaLog.
func (SysOperaLog) Edges() []ent.Edge {
	return nil
}

func (SysOperaLog) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("oper_url"),
	}
}

func (SysOperaLog) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Control{},
	}
}
