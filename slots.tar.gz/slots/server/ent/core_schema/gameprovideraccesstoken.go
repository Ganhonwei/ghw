package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// GameProviderAccessToken holds the schema definition for the GameProviderAccessToken entity.
type GameProviderAccessToken struct {
	ent.Schema
}

// Fields of the GameProviderAccessToken.
func (GameProviderAccessToken) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("token").Unique(),
		field.Int64("account_id").Comment("账号Id"),
		field.Int64("game_company_id").Comment("游戏公司Id"),
	}
}

// Edges of the GameProviderAccessToken.
func (GameProviderAccessToken) Edges() []ent.Edge {
	return nil
}

func (GameProviderAccessToken) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
