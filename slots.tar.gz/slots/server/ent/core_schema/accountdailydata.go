package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// AccountDailyData holds the schema definition for the AccountDailyData entity.
type AccountDailyData struct {
	ent.Schema
}

// Fields of the AccountDailyData.
func (AccountDailyData) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.Int64("channel_id").Default(1).Comment("账号渠道ID"),
		field.Int64("partition_id").Default(1).Comment("账号渠道ID"),
		field.Int64("account_id").Comment("账号ID"),
		field.Time("date").Comment("日期").Optional(),
		field.Int64("recharge_count").Default(0).Comment("充值笔数"),
		field.Int64("recharge_amount").Default(0).Comment("充值金额"),
		field.Int64("withdraw_count").Default(0).Comment("提现笔数"),
		field.Int64("withdraw_amount").Default(0).Comment("提现金额"),
		field.Int64("bet_count").Default(0).Comment("下注笔数"),
		field.Int64("bet_amount").Default(0).Comment("下注金额"),
		field.Int64("valid_bet_amount").Default(0).Comment("有效下注金额"),
		field.Int64("bet_win_amount").Default(0).Comment("输赢金额"),
	}
}

// Edges of the AccountDailyData.
func (AccountDailyData) Edges() []ent.Edge {
	return []ent.Edge{
		edge.From("account", Account.Type).Ref("accountdailydatas").Field("account_id").Required().Unique(),
	}
}

func (AccountDailyData) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("date", "account_id").Unique(),
	}
}

func (AccountDailyData) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
