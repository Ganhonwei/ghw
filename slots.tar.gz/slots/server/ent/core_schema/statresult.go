package core_schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// StatResult holds the schema definition for the StatResult entity.
type StatResult struct {
	ent.Schema
}

// Fields of the StatResult.
func (StatResult) Fields() []ent.Field {
	return []ent.Field{
		field.Time("created_at").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}).Comment("创建时间"),
		field.Time("updated_at").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}).Comment("更新时间"),
		field.String("name").MaxLen(64).Comment("统计名称"),
		field.String("opt_a").MaxLen(16).Comment("a关联ID"), //比如:按渠道统计代表渠道ID
		field.String("opt_b").MaxLen(64).Comment("b关联ID"), //比如:按游戏统计就代表游戏ID
		field.String("opt_c").MaxLen(16).Comment("c关联ID"), //比如:按区服统计就代表区服ID
		field.Time("stat_at").Comment("统计时间").Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.Int64("value").Default(0).Comment("统计数量"),
		field.Float("total_property").Optional().Default(0),
	}
}

// Edges of the StatResult.
func (StatResult) Edges() []ent.Edge {
	return nil
}

func (StatResult) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("stat_at", "name", "opt_a", "opt_b", "opt_c").Unique(),
	}
}
