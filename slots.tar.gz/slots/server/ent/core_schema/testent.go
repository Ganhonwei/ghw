package core_schema

import (
	"server/ent/schema/ftype"

	"entgo.io/ent"
	"entgo.io/ent/schema/field"
)

// TestEnt holds the schema definition for the TestEnt entity.
type TestEnt struct {
	ent.Schema
}

// Fields of the TestEnt.
func (TestEnt) Fields() []ent.Field {

	return []ent.Field{
		field.String("dna").
			MaxLen(64).
			Validate(ftype.BigIntValidator).
			GoType(ftype.BigInt{}),
	}
}

// Edges of the TestEnt.
func (TestEnt) Edges() []ent.Edge {
	return nil
}
