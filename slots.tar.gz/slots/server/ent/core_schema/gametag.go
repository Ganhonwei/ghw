package core_schema

import (
	"server/ent/schema/ftype"
	"server/internals/generated/core"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// GameTag holds the schema definition for the GameTag entity.
type GameTag struct {
	ent.Schema
}

// Fields of the GameTag.
func (GameTag) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("icon").Comment("未激活图标"),
		field.String("icon_actived").Comment("激活图标"),
		field.String("name").Comment("标签名称"),
		field.String("remark").Optional().Comment("备注"),
		field.Bool("is_index").Comment("首页显示 true.显示 false.不显示"),
		field.Int32("index_sort").Default(0).Comment("排序"),
		field.Int32("count").Default(0).Comment("游戏数量"),
		field.Bool("is_lock").Default(false).Comment("是否锁定 true.是 false.否"), //锁定：厂商原始标签
		field.Bool("is_user_game").Default(false).Comment("是否用户游戏 true.是 false.否"),
		field.Int32("tag_func").GoType(core.TagFunc(0)).Default(0).Comment("标签作用"), //HOT FAV HISTORY
		field.Bool("is_hot").Default(false).Comment("是否子热门"),
		field.Bool("is_show_hot").Default(false).Comment("是否显示子热门"),
		field.JSON("cp_index", ftype.CpSortDefaultValue).Default(ftype.CpSortDefaultValue).Optional().Comment("游戏商排序"),
		field.Bool("is_history").Default(false).Comment("是否历史/推荐"),
		field.Bool("is_kept_on_sync").Default(false).Comment("同步时是否保留"),
		field.Int64("map_tag").Optional().Comment("映射标签"),
		field.Bool("is_valid_bet").Default(true).Comment("是否计算有效"),
		field.Int64("fanshui_ratio").Default(0).Comment("返水比例"),
	}
}

// Edges of the GameTag.
func (GameTag) Edges() []ent.Edge {

	return []ent.Edge{
		edge.From("games", Game.Type).Ref("gametags").Through("gametag_game", GameGametag.Type),
	}
}

func (GameTag) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("name").Unique(),
	}
}
