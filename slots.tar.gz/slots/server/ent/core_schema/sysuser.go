package core_schema

import (
	"context"
	gen "server/ent/core_db"
	"server/ent/core_db/hook"
	"server/ent/schema/mixin"
	"server/internals/utils/ucrypto"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
)

// SysUser holds the schema definition for the SysUser entity.
type SysUser struct {
	ent.Schema
}

// Fields of the SysUser.
func (e SysUser) Fields() []ent.Field {
	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).StorageKey("user_id"),
		field.String("user_name").Unique().Comment("用户名"),
		field.String("password"),
		field.String("nick_name").Comment("昵称"),
		field.String("phone").Comment("手机号"),
		field.Int32("role_id").Comment("角色ID"),
		field.String("avatar").Comment("头像"),
		field.String("sex").Comment("性别"),
		field.String("email").Comment("邮箱"),
		field.String("remark").Optional().Comment("备注"),
		field.String("status").MaxLen(4).Comment("状态"),
		field.String("TotpSecret").Default("").MaxLen(64).Comment("Totp密钥"),
		field.Strings("ChannelScope").Optional().Comment("渠道范围"),
		field.Strings("whiteips").Default([]string{}).Comment("ip白名单"),
		field.String("jti"),
	}
}

// func (e SysUser) Encrypt() (password string) {
// 	// if e. == "" {
// 	// 	return
// 	// }

// 	var hash []byte
// 	hash, _ = bcrypt.GenerateFromPassword([]byte(string(1111)), bcrypt.DefaultCost)

// 	return string(hash)
// }

// Edges of the SysUser.
func (SysUser) Edges() []ent.Edge {
	return []ent.Edge{
		// edge.To("children", Account.Type).From("parent").Unique().Field("parent_id"),
		// edge.To("sys_dept", SysDept.Type),
		edge.From("owner", SysRole.Type).
			Ref("user_role").
			Field("role_id").
			Required().
			Unique(),
	}
}

func (SysUser) Indexes() []ent.Index {
	return nil
}

func (SysUser) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
		mixin.Control{},
	}
}

func (SysUser) Hooks() []ent.Hook {
	return []ent.Hook{
		hook.On(func(m ent.Mutator) ent.Mutator {
			return hook.SysUserFunc(func(ctx context.Context, sum *gen.SysUserMutation) (ent.Value, error) {
				pwd, ok := sum.Password()
				if ok {
					sum.SetPassword(ucrypto.PasswordHash(pwd))
				}
				return m.Mutate(ctx, sum)
			})
		}, ent.OpCreate|ent.OpUpdate|ent.OpUpdateOne),
	}
}
