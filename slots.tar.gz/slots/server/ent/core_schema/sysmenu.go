package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
)

// SysMenu holds the schema definition for the SysMenu entity.
type SysMenu struct {
	ent.Schema
}

// Fields of the SysMenu.
func (SysMenu) Fields() []ent.Field {

	// SysApi     []SysApi  `json:"sysApi" gorm:"many2many:sys_menu_api_rule"`
	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).StorageKey("menu_id"),
		field.String("menu_name"),
		field.String("title"),
		field.String("icon"),
		field.String("path"),
		field.String("redirect"),
		field.String("menu_type").MaxLen(1),
		field.String("action").MaxLen(16),
		field.String("permission").Optional(),
		field.String("breadcrumb").Optional(),
		field.String("component").Optional(),
		field.String("visible").Optional().MaxLen(1),
		field.String("is_frame").MaxLen(1).Default("0"),
		field.Int32("parent_id").Optional(),
		field.Bool("no_cache").Optional(),
		field.Int("sort").Optional(),
		field.String("auth").Optional(),
		field.String("key").Optional(),
	}
}

// Edges of the SysMenu.
func (SysMenu) Edges() []ent.Edge {
	return []ent.Edge{

		edge.To("apis", SysApi.Type),
		// edge.From("apis", SysApi.Type).
		// 	Ref("owner"),
		edge.To("children", SysMenu.Type).
			From("parent").
			Field("parent_id").
			Unique(),
	}
}

func (SysMenu) Indexes() []ent.Index {
	return nil
}

func (SysMenu) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
		mixin.Control{},
	}
}

// func (SysMenu) Hooks() []ent.Hook {
// 	return []ent.Hook{
// 		hook.On(func(m ent.Mutator) ent.Mutator {
// 			return hook.SysMenuFunc(func(ctx context.Context, sum *gen.SysMenuMutation) (ent.Value, error) {
// 				parentId, ok := sum.ParentID()
// 				if ok {
// 					parent, err := db.Cli.SysMenu.Get(context.Background(), parentId)
// 					if err != nil {
// 						logger.Errorf("Menu Hooks Err:%v", err)
// 						return m.Mutate(ctx, sum)
// 					}
// 					sum.SetPath(fmt.Sprintf("%v/%v", parent.Path, sum.MenuName()))
// 				}
// 				return m.Mutate(ctx, sum)
// 			})
// 		}, ent.OpCreate|ent.OpUpdate|ent.OpUpdateOne),
// 	}
// }
