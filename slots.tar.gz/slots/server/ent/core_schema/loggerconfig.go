package core_schema

import (
	"errors"
	"server/internals/logger"

	"entgo.io/ent"
	"entgo.io/ent/schema/field"
)

// LoggerConfig holds the schema definition for the LoggerConfig entity.
type LoggerConfig struct {
	ent.Schema
}

// Fields of the LoggerConfig.
func (LoggerConfig) Fields() []ent.Field {
	return []ent.Field{
		field.String("key").Unique().Comment("Logger UniqueKey"),
		field.Uint32("log_level").GoType(logger.DebugLevel).Default(uint32(logger.DebugLevel)).Validate(func(u uint32) error {
			if u >= uint32(logger.ErrorLevel) && u <= uint32(logger.DebugLevel) {
				return nil
			}
			return errors.New("LogLevel must be a LogLevel Type value")
		}).Default(uint32(logger.DebugLevel)),
	}
}

// Edges of the LoggerConfig.
func (LoggerConfig) Edges() []ent.Edge {
	return nil
}
