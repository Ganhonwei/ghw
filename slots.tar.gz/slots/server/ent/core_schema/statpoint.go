package core_schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// StatPoint holds the schema definition for the StatPoint entity.
type StatPoint struct {
	ent.Schema
}

// Fields of the StatPoint.
func (StatPoint) Fields() []ent.Field {
	return []ent.Field{
		field.Time("created_at").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.Time("updated_at").Default(time.Now).Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.String("key").Unique(),
		field.Int64("point"),
	}
}

// Edges of the StatPoint.
func (StatPoint) Edges() []ent.Edge {
	return nil
}
