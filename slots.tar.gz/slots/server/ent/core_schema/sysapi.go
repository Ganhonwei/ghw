package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// SysApi holds the schema definition for the SysApi entity.
type SysApi struct {
	ent.Schema
}

// Fields of the SysApi.
func (SysApi) Fields() []ent.Field {

	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("path").Unique().Comment("地址"),
		field.String("handle").Optional(),
		field.String("auth").Optional(),
		field.String("key").Optional(),
		field.String("module").Optional().Comment("模块"),
		field.String("title").Optional().Comment("标题"),
		field.String("method").Comment("请求类型"),
		field.String("type").Comment("接口类型"),
		field.Bool("is_harbor").Default(false).Comment("是否隐藏"),
	}
}

// Edges of the SysApi.
func (SysApi) Edges() []ent.Edge {
	return []ent.Edge{
		edge.From("api_menu", SysMenu.Type).
			Ref("apis"),
		edge.From("api_role", SysRole.Type).
			Ref("role_api"),
	}
	// return nil
}
func (SysApi) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("id", "path").
			Unique(),
	}
}

func (SysApi) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
		mixin.Control{},
	}
}
