package core_schema

import (
	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// LanguagePack holds the schema definition for the LanguagePack entity.
type LanguagePack struct {
	ent.Schema
}

// Fields of the LanguagePack.
func (LanguagePack) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("lang").Comment("语言版本 en/cn"),
		field.String("tn").Comment("表名"),
		field.String("fn").Comment("字段名"),
		field.Int64("ext_id").Comment("数据ID"),
		field.String("key").Unique().Comment("语言key game.name.1"),
		field.Text("val").Comment("语言值"),
		field.String("val_type").Comment("值类型 text,image,video"),
		field.Int64("updated_time").Default(0).Comment("更新时间"),
		field.Bool("server_only").Default(false).Comment("仅服务器使用"),
	}
}

// Edges of the LanguagePack.
func (LanguagePack) Edges() []ent.Edge {
	return nil
}

func (LanguagePack) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("server_only"),
		index.Fields("lang", "server_only", "updated_time"),
		index.Fields("tn", "lang", "ext_id"),
	}
}

func (LanguagePack) Mixin() []ent.Mixin {
	return nil
}
