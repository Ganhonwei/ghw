package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// StatData holds the schema definition for the StatData entity.
type StatData struct {
	ent.Schema
}

// Fields of the StatData.
func (StatData) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("tn").Comment("表名(与语言包相同)"),
		field.Int64("ext_id").Comment("数据ID"),
		field.Int64("date").Comment("日期 20231024"),
		field.String("key").Comment("统计键"),
		field.Int64("val").Comment("统计值"),
	}
}

// Edges of the StatData.
func (StatData) Edges() []ent.Edge {
	return nil
}

func (StatData) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
