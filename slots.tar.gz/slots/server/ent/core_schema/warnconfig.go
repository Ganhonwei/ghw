package core_schema

import (
	"server/internals/generated/core"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// WarnConfig holds the schema definition for the WarnConfig entity.
type WarnConfig struct {
	ent.Schema
}

// Fields of the WarnConfig.
func (WarnConfig) Fields() []ent.Field {

	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("name").Comment("配置名称"),
		field.String("key").Comment("配置键"),
		field.String("val").Comment("配置值").MaxLen(512),
		field.Int32("val_type").GoType(core.ConfType(0)).Default(0).Comment("值类型"),
	}
}

// Edges of the WarnConfig.
func (WarnConfig) Edges() []ent.Edge {
	return nil
}

func (WarnConfig) Mixin() []ent.Mixin {
	return nil
}
