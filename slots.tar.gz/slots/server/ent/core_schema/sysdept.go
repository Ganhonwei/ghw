package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// SysDept holds the schema definition for the SysDept entity.
type SysDept struct {
	ent.Schema
}

// Fields of the SysDept.
func (SysDept) Fields() []ent.Field {

	return []ent.Field{
		field.Int32("dept_id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).Comment("部门编码"),
		// field.Int32("parent_id"),
		field.String("dept_path"),
		field.String("dept_name").Comment("部门名称"),
		field.Int32("sort").Comment("排序"),
		field.String("leader").Comment("负责人"),
		field.String("phone").Comment("手机"),
		field.String("email").Comment("邮箱"),
		field.Int32("status").Comment("状态"),
	}
}

// Edges of the SysDept.
func (SysDept) Edges() []ent.Edge {
	return []ent.Edge{
		// edge.To("children", Account.Type).From("parent").Unique().Field("parent_id"),
		// edge.To("player", Player.Type).Unique(),
	}
}

func (SysDept) Indexes() []ent.Index {
	return nil
}

func (SysDept) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
		mixin.Control{},
	}
}
