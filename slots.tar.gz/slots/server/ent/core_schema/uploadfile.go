package core_schema

import (
	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// UploadFile holds the schema definition for the UploadFile entity.
type UploadFile struct {
	ent.Schema
}

// Fields of the UploadFile.
func (UploadFile) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("module").Comment("所属模块"),
		field.Int64("size").Comment("文件大小"),
		field.String("md5").Comment("MD5"),
		field.String("path").Comment("访问路径"),                      // /tag/xx/bb/xxxxxxxxxxxxxxxxx.jpg
		field.String("client_dir").Default("").Comment("客户端显示目录"), // /xx/xx
		//暂定这几个字段，后续需要在添加
	}
}

// Edges of the UploadFile.
func (UploadFile) Edges() []ent.Edge {
	return nil
}

func (UploadFile) Mixin() []ent.Mixin {
	return nil
}
