package core_schema

import (
	"entgo.io/ent"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// TGGroup holds the schema definition for the TGGroup entity.
type TGGroup struct {
	ent.Schema
}

// Fields of the TGGroup.
func (TGGroup) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique(),
		field.String("name").Comment("群名字"),
		field.String("username").Comment("用户名"),
		field.String("link").Comment("链接"),
	}
}

// Edges of the TGGroup.
func (TGGroup) Edges() []ent.Edge {
	return nil
}

func (TGGroup) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("id"),
	}
}
