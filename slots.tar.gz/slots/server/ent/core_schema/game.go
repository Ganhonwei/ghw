package core_schema

import (
	"server/ent/schema/ftype"
	"server/ent/schema/mixin"
	"server/internals/generated/core"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// Game holds the schema definition for the Game entity.
type Game struct {
	ent.Schema
}

// Fields of the Game.
func (Game) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("logo").Comment("游戏LOGO"),
		field.String("original_logo").Optional().Comment("游戏原始LOGO"),
		field.Int32("logo_type").GoType(core.LogoSizeType(0)).Comment("LOGO类型"),
		field.String("last_visit_logo").Comment("最后访问游戏处的LOGO"),
		field.String("name").Comment("游戏名称"),
		field.String("code").Comment("游戏编码"),
		field.String("config").Optional().Comment("游戏配置"),
		field.Int32("index_sort").Comment("游戏排序"),
		field.Int64("cate_id").Comment("游戏分类ID"),
		field.Int64("company_id").Comment("游戏商ID"),
		field.Int64("show_company_id").Default(0).Comment("显示游戏商ID"),
		field.Int32("status").Comment("游戏状态 1.上架 2.下架"),
		field.Bool("is_playable").Default(false).Comment("游戏是否可玩 true.是. false.否"),
		field.Bool("is_test").Default(false).Comment("是否试玩 true.是. false.否"),
		field.Bool("is_hot").Default(false).Comment("是否热门"),
		field.Bool("is_new").Default(false).Comment("是否最新"),
		field.Bool("is_rec").Default(false).Comment("是否推荐"),
		field.Bool("is_msg").Default(false).Comment("是否繁荣"), // 用于繁荣数据
		field.Bool("is_internal_test").Default(false).Comment("是否内测"),
		field.Bool("is_vertical").Default(false).Comment("是否竖屏"),
		field.Bool("is_maintenance").Default(false).Comment("是否三方维护中"),
		field.JSON("game_pkg", ftype.PkgOptsDefaultValue).Default(ftype.PkgOptsDefaultValue).Optional().Comment("特权包名"),
		field.Bool("is_risk").Default(false).Comment("是否风控"),
		field.Int32("need_vip").Default(0).Comment("所需VIP等级"),
		field.Bool("is_valid_bet").Default(true).Comment("是否计算有效"),
		field.Bool("lock_sync_tag").Default(false).Comment("锁定同步标签"),
		field.Bool("lock_sync_logo").Default(false).Comment("锁定同步LOGO"),
	}
}

// Edges of the Game.
func (Game) Edges() []ent.Edge {
	return []ent.Edge{
		edge.To("gametags", GameTag.Type).
			Through("game_gametags", GameGametag.Type),
		edge.To("rtpgames", GameRtp.Type),
	}
}

func (Game) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}

func (Game) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("company_id", "code").Unique(),
		index.Fields("show_company_id"),
	}
}
