// models.Model
// Username      string    `json:"username" gorm:"size:128;comment:用户名"`
// Status        string    `json:"status" gorm:"size:4;comment:状态"`
// Ipaddr        string    `json:"ipaddr" gorm:"size:255;comment:ip地址"`
// LoginTime     time.Time `json:"loginTime" gorm:"comment:登录时间"`
// Remark        string    `json:"remark" gorm:"size:255;comment:备注"`
// Msg           string    `json:"msg" gorm:"size:255;comment:信息"`
// CreatedAt     time.Time `json:"createdAt" gorm:"comment:创建时间"`
// UpdatedAt     time.Time `json:"updatedAt" gorm:"comment:最后更新时间"`
// models.ControlBy
// }

package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// SysLoginLog holds the schema definition for the SysLoginLog entity.
type SysLoginLog struct {
	ent.Schema
}

// Fields of the SysLoginLog.
func (SysLoginLog) Fields() []ent.Field {
	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).Comment("编码"),
		field.String("user_name").Comment("用户名"),
		field.String("status").Comment("状态"),
		field.String("ip_addr").Comment("ip地址"),
		field.String("login_location").Comment("归属地"),
		field.String("browser").Comment("浏览器"),
		field.String("os").Comment("系统"),
		field.String("platform").Comment("固件"),
		field.Time("login_time").Comment("登录时间").Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}),
		field.String("remark").Comment("备注"),
		field.String("msg").Comment("信息"),
	}
}

// Edges of the SysLoginLog.
func (SysLoginLog) Edges() []ent.Edge {
	return []ent.Edge{}
}

func (SysLoginLog) Indexes() []ent.Index {
	return nil
}

func (SysLoginLog) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
