package core_schema

import (
	"time"

	"entgo.io/ent"
)

var (
	incrementalEnabled  = true
	incrementalDisabled = false // nolint: unused, deadcode, varcheck
	unixEpoch           = time.Date(1970, 1, 1, 0, 0, 1, 0, time.UTC)
	unixMax             = time.Date(2038, 1, 19, 3, 14, 7, 0, time.UTC) // mysql timestamp max value 2038-01-19 03:14:07 UTC
	BaseConfig          = []ent.Field{
		// CreateBy int `json:"createBy" gorm:"index;comment:创建者"`
		// UpdateBy int `json:"updateBy" gorm:"index;comment:更新者"`
		// CreatedAt time.Time      `json:"createdAt" gorm:"comment:创建时间"`
		// UpdatedAt time.Time      `json:"updatedAt" gorm:"comment:最后更新时间"`
		// DeletedAt gorm.DeletedAt `json:"-" gorm:"index;comment:删除时间"`

	}
)

func NilTime() time.Time {
	return unixEpoch
}

func MaxTime() time.Time {
	return unixMax
}
