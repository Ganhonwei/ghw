package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// GameGametag holds the schema definition for the GameGametag entity.
type GameGametag struct {
	ent.Schema
}

// Fields of the GameGametag.
func (GameGametag) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.Int64("game_id").Comment("游戏ID"),
		field.Int64("game_tag_id").Comment("游戏TagID"),
		field.Int32("sort_index").Default(0).Comment("排序序号"),
	}
}

// Edges of the GameGametag.
func (GameGametag) Edges() []ent.Edge {
	return []ent.Edge{
		edge.To("game", Game.Type).
			Unique().
			Required().
			Field("game_id"),
		edge.To("gametag", GameTag.Type).
			Unique().
			Required().
			Field("game_tag_id"),
	}
}

func (GameGametag) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("game_tag_id", "game_id").Unique(),
		index.Fields("game_id", "game_tag_id").Unique(),
	}
}

func (GameGametag) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
