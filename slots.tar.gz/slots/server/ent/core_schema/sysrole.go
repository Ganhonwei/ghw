package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
)

// SysRole holds the schema definition for the SysRole entity.
type SysRole struct {
	ent.Schema
}

// Fields of the SysRole.
func (SysRole) Fields() []ent.Field {

	return []ent.Field{
		field.Int32("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}).Comment("角色编码"),
		field.String("role_name").Comment("角色名称"),
		field.String("status").MaxLen(4).Comment("状态"),
		field.String("role_key").Comment("角色代码"),
		field.Int32("role_sort").Optional().Comment("角色排序"),
		field.String("flag").Optional(),
		field.String("remark").Optional().Comment("备注"),
		field.Bool("admin").Comment("角色代码"),
		field.String("data_scope").Optional(), //todo
	}
}

// Edges of the SysRole.
func (SysRole) Edges() []ent.Edge {
	return []ent.Edge{
		// edge.To("children", Account.Type).From("parent").Unique().Field("parent_id"),
		edge.To("sys_dept", SysDept.Type),
		edge.To("user_role", SysUser.Type),
		edge.To("role_api", SysApi.Type),
	}
}

func (SysRole) Indexes() []ent.Index {
	return nil
}

func (SysRole) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
		mixin.Control{},
	}
}
