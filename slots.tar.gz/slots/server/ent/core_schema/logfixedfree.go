package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
)

// LogFixedFree holds the schema definition for the LogFixedFree entity.
type LogFixedFree struct {
	ent.Schema
}

// Fields of the LogFixedFree.
func (LogFixedFree) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.Int64("ymd").Default(0).Comment("日期"),
		field.Int64("channel_id").Default(1).Comment("账号渠道ID"),
		field.Int64("partition_id").Default(1).Comment("账号区服ID"),
		field.Int64("account_id").Comment("账号ID"),
		field.Int64("tier_id").Default(0).Comment("活动挡位ID"),
		field.Int64("day").Default(0).Comment("领取天数"),
		field.Int64("amount").Default(0).Comment("领取金额"),
	}
}

// Edges of the LogFixedFree.
func (LogFixedFree) Edges() []ent.Edge {
	return nil
}

func (LogFixedFree) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}
