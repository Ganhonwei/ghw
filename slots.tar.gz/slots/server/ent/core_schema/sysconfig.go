package core_schema

import (
	"server/internals/generated/core"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// SysConfig holds the schema definition for the SysConfig entity.
type SysConfig struct {
	ent.Schema
}

// Fields of the SysConfig.
func (SysConfig) Fields() []ent.Field {

	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.String("name").Comment("配置名称"),
		field.String("key").Comment("配置键"),
		field.String("val").Comment("配置值").MaxLen(8192),
		field.Int32("val_type").GoType(core.ConfType(0)).Default(0).Comment("值类型"),
		field.Bool("is_client").Default(false).Comment("是否客户端使用"),
		field.Bool("is_open").Default(false).Comment("是否开放给客服"),
	}
}

// Edges of the SysConfig.
func (SysConfig) Edges() []ent.Edge {
	return nil
}

func (SysConfig) Mixin() []ent.Mixin {
	return nil
}

func (SysConfig) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("key").Unique(),
	}
}
