package core_schema

import (
	"server/ent/schema/ftype"
	"server/ent/schema/mixin"
	"server/internals/generated/core"
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// Account holds the schema definition for the Account entity.
type Account struct {
	ent.Schema
}

// Fields of the Account.
func (Account) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalDisabled,
		}).StructTag("excel:\"id\""),
		field.Int32("source").GoType(core.AccountSource(0)).StructTag("excel:\"账号来源类型: 1.mobile 2.facebook 3.guest 4.acct\"").Comment("账号来源类型: 1.mobile 2.facebook 3.guest 4.acct"),
		field.String("username").Comment("用户名").Annotations(
			entsql.Annotation{Collation: "utf8mb4_general_ci"},
		).StructTag("excel:\"用户名\""), //手机注册时冗余存放手机登录的手机号
		field.String("userpwd").Comment("密码"),
		field.Int64("pwd_question_id").Default(0).Comment("密码问题ID"),
		field.String("pwd_question_answer").Optional().Comment("密码问题答案"),
		field.Int32("state").GoType(core.AccountState(0)).StructTag("excel:\"状态 1.正常 2.禁用\"").Comment("状态 1.正常 2.禁用"),
		field.String("jti").Optional().Comment("jti").Unique(),
		field.String("device").Optional().StructTag("excel:\"注册设备\"").Comment("注册设备"),
		field.String("pkg").Optional().StructTag("excel:\"注册包名\"").Comment("注册包名"),
		field.String("version").Optional().StructTag("excel:\"注册版本\"").Comment("注册版本"),
		field.String("ip").Optional().StructTag("excel:\"注册IP\"").Comment("注册IP"),
		field.String("appsflyer_id").Optional().Comment("appsflyer_id"), //前端知道如何使用
		field.String("adjust_id").Optional().Comment("adjust_id"),
		field.String("adjust_adid").Optional().Comment("adjust_adid"),
		field.Bool("is_side_a").Default(false).StructTag("excel:\"是否A面注册\"").Comment("是否A面注册"),
		//账户信息
		field.Int64("game_amount").StructTag("excel:\"游戏账户\"").Default(0).Comment("游戏账户"),
		field.Int64("out_amount").StructTag("excel:\"冻结账户\"").Default(0).Comment("冻结账户"),
		field.Int64("bank_amount").Default(0).Comment("保险柜账户"),
		field.String("bank_pwd").Optional().Comment("保险柜密码"),
		field.Int64("total_amount").StructTag("excel:\"总资产\"").Default(0).Comment("总资产"),
		//个人信息
		field.String("avatar").Optional().Comment("头像"),
		field.String("name").StructTag("excel:\"昵称\"").Comment("昵称"), //可繁荣使用
		field.String("birthday").Optional().Comment("生日"),
		field.Int32("vip").StructTag("excel:\"VIP等级\"").Default(0).Comment("VIP等级"),
		field.Int64("vip_exp").StructTag("excel:\"成长值\"").Default(0).Comment("成长值"),
		field.Int64("vip_expire").Default(0).Comment("保级过期时间"),
		field.Int64("vip_keep_total_bet").Default(0).Comment("保级期间有效下注总额"),
		field.String("mobile").Optional().StructTag("excel:\"手机号\"").Comment("手机号"),
		field.String("email").Optional().StructTag("excel:\"邮件\"").Comment("邮件"),
		field.String("virtual_mobile").Optional().Comment("虚拟手机号"), //可繁荣使用
		field.JSON("vip_var", ftype.VIPVar{}).Default(ftype.VIPVar{}).Comment("权益领取"),
		field.Time("last_login_time").Annotations(entsql.Annotation{
			Default: "CURRENT_TIMESTAMP",
		}).Default(time.Now).StructTag("excel:\"上次登录时间\"").Comment("上次登录时间"),
		field.String("last_login_device").Optional().StructTag("excel:\"上次登录设备\"").Comment("上次登录设备"),
		field.Int64("email_id").Default(0).Comment("已领邮件ID"),
		field.Int64("total_recharge_amount").Default(0).StructTag("excel:\"总充值\"").Comment("总充值"),
		field.Int64("total_recharge_order").Default(0).StructTag("excel:\"总充值笔数\"").Comment("总充值笔数"),
		field.Int64("total_withdraw_amount").Default(0).StructTag("excel:\"总提现\"").Comment("总提现"),
		field.Int64("total_withdraw_order").Default(0).StructTag("excel:\"总提现笔数\"").Comment("总提现笔数"),
		field.Int64("total_bet_amount").Default(0).StructTag("excel:\"总下注\"").Comment("总下注"),
		field.Int64("total_valid_bet_amount").Default(0).StructTag("excel:\"总有效下注\"").Comment("总有效下注"),
		field.Int64("total_fav_amount").Default(0).StructTag("excel:\"总优惠\"").Comment("总优惠"),
		field.Int64("total_win_amount").Default(0).StructTag("excel:\"总输赢\"").Comment("总输赢"),
		field.String("bind_phone_sms").Optional().StructTag("excel:\"绑定手机验证码\"").Comment("绑定手机验证码"),
		//彩金池
		field.Int64("cjc_bet_amount").Default(0).StructTag("excel:\"彩金池打码触发-打码量\"").Comment("打码触发-打码量"),
		field.Int64("cjc_bet_level").Default(0).StructTag("excel:\"彩金池打码触发-挡位\"").Comment("打码触发-挡位"),
		field.Int64("cjc_win_amount").Default(0).StructTag("excel:\"彩金池亏损触发-亏损量\"").Comment("亏损触发-亏损量"),
		field.Int64("cjc_win_level").Default(0).StructTag("excel:\"彩金池亏损触发-挡位\"").Comment("亏损触发-挡位"),
		//提现流水要求
		field.Int64("fav_need_bet").Default(0).StructTag("excel:\"赠送-流水要求\"").Comment("赠送-流水要求"),
		field.Int64("fav_comp_bet").Default(0).StructTag("excel:\"赠送-已完成流水要求\"").Comment("赠送-已完成流水要求"),
		field.Int64("withdraw_need_bet").Default(0).StructTag("excel:\"流水要求\"").Comment("流水要求"),
		field.Int64("withdraw_comp_bet").Default(0).StructTag("excel:\"已完成流水要求\"").Comment("已完成流水要求"),
		field.Int64("withdraw_clear_time").Default(0).Comment("上次提现流水清零时间"),
		field.Int64("channel_id").Default(1).StructTag("excel:\"账号渠道ID\"").Comment("账号渠道ID"),
		field.Int64("partiotion_id").Default(1).StructTag("excel:\"账号区服ID\"").Comment("账号区服ID"),
		//首充
		field.Int64("sc_amount").Default(0).Comment("首充金额"),
		field.Int32("sc_status").GoType(core.VipPoolWinnerStatus(0)).Default(int32(core.VipPoolWinnerStatus_VipPoolWinnerStatusNone)).Comment("首充领取状态"),
		field.Int64("sc_fav_amount").Default(0).Comment("首充领取金额"),
		field.Int64("sc_need_amount").Default(0).Comment("首充领取所需流水"),
		field.Int64("sc_curr_amount").Default(0).Comment("首充领取当前流水"),
		// 返水
		field.Int64("fs_value").Default(0).Comment("返利值"),
		field.Int64("fs_pts").Default(0).Comment("积分"),
		field.Int64("fs_times").Default(0).Comment("次数"),
		field.Int32("fs_ymd").Default(0).Comment("返利刷新日期"),
		field.JSON("fs_recv_quest", []string{}).Default([]string{}).Comment("每日已领取积分的任务"),
		field.Int64("log_game_id").Default(0).Comment("上次游戏日志"),
		field.Int64("forbidden_time").Default(0).Comment("封禁过期时间"),
		field.Int64("freeze_time").Default(0).Comment("冻结过期时间"),
		field.Bool("is_internal_test").Default(false).Comment("内测账号"),
		//首次充值
		field.Int64("sccz_amount").Default(0).Comment("第一次买-充值金额"),
		field.Int64("sccz_first_amount").Default(0).Comment("第一次买-第1次领取金额"),
		field.Int64("sccz_second_amount").Default(0).Comment("第一次买-第2次领取金额"),
		field.Time("sccz_second_time").Annotations(entsql.Annotation{Default: "CURRENT_TIMESTAMP"}).Default(time.Now).Comment("第一次买-第2次可领取时间"),
		field.Bool("sccz_status").Default(false).Comment("第一次买-是否完成"),
		field.Int64("sccz_amount2").Default(0).Comment("第二次买-充值金额"),
		field.Int64("sccz_first_amount2").Default(0).Comment("第二次买-第1次领取金额"),
		field.Int64("sccz_second_amount2").Default(0).Comment("第二次买-第2次领取金额"),
		field.Time("sccz_second_time2").Annotations(entsql.Annotation{Default: "CURRENT_TIMESTAMP"}).Default(time.Now).Comment("第二次买-第2次可领取时间"),
		field.Bool("sccz_status2").Default(false).Comment("第二次买-是否完成"),
		field.Int64("sccz_amount3").Default(0).Comment("第三次买-充值金额"),
		field.Int64("sccz_first_amount3").Default(0).Comment("第三次买-第1次领取金额"),
		field.Int64("sccz_second_amount3").Default(0).Comment("第三次买-第2次领取金额"),
		field.Time("sccz_second_time3").Annotations(entsql.Annotation{Default: "CURRENT_TIMESTAMP"}).Default(time.Now).Comment("第三次买-第2次可领取时间"),
		field.Bool("sccz_status3").Default(false).Comment("第三次买-是否完成"),
		//小额提现
		field.Int64("xetx_amount").Default(0).Comment("已提次数"),
		field.Bool("xetx_status").Default(false).Comment("是否完成"),
		field.Int64("last_update_pwd_time").Default(0).Comment("上次修改密码时间"),
		//风险用户
		field.Bool("risk_user").Default(false).StructTag("excel:\"是否风险用户\"").Comment("是否风险用户"),
		field.Int64("risk_withdraw_time").Default(0).StructTag("excel:\"允许提现时间\"").Comment("允许提现时间"),
		field.Int64("risk_google_recharge").Default(0).Comment("google充值总金额"),
		//版本更新补偿
		field.Int64("gxbc_amount").Default(0).Comment("补充金额"),
		//谷歌好评
		field.Int64("last_good_time").Default(0).Comment("上次弹出时间"),
		field.Int32("good_times").Default(0).Comment("弹出次数"),
		field.Int32("good_status").Default(0).Comment("弹出状态"),
		//签到
		field.Time("qd_first_time").Optional().Comment("首次领取时间"),
		field.Int64("qd_amount1").Default(0).Comment("第1次签到金额"),
		field.Int64("qd_amount2").Default(0).Comment("第2次领取金额"),
		field.Int64("qd_amount3").Default(0).Comment("第3次领取金额"),
		field.Bool("qd_status").Default(false).Comment("签到完成"),
		//官方包
		field.Time("official_login_time").Optional().Comment("首次登录官方包时间"),
		field.String("official_pkg").Optional().Comment("首次登录官方包名"), //可能有多个官方包名
		//风控
		field.Bool("is_play_risk").Default(false).Comment("是否玩过风控游戏"),                                 //为风控预留
		field.Bool("disable_withdraw").Default(false).StructTag("excel:\"是否禁止提现\"").Comment("是否禁止提现"), //禁止提现
		//锦标赛
		// field.JSON("champion", ftype.ChampionConfigDefault).Default(ftype.ChampionConfigDefault).Comment("锦标赛"),
		// field.Int64("ksfl_ymd").Optional().Comment("亏损返利申请日期"),
		// field.Int64("total_settled_rebate_amount").Default(0).Comment("总已结算返利金额"),
		//破产礼包
		field.Bool("pclb_status").Default(false).Comment("破产礼包-是否完成"),
		field.JSON("pclb_prizes", ftype.PclbPrizeOptsDefaultValue).Default(ftype.PclbPrizeOptsDefaultValue).Optional().Comment("破产礼包已领取"),
		//手机绑定活动
		field.Int64("bind_time").Default(0).Comment("手机绑定活动-绑定时间"), //0是为了把老账号都处理为已领取
		field.Int64("bind_amount1").Default(0).Comment("手机绑定活动-1日奖励"),
		field.Int64("bind_amount2").Default(0).Comment("手机绑定活动-2日奖励"),
		field.Int64("bind_amount3").Default(0).Comment("手机绑定活动-3日奖励"),
		field.Int64("bind_email_amount").Default(0).Comment("绑定邮箱奖励"),
		//金库系统
		field.Int64("gold_id").Default(0).Comment("金库最新ID"),                               //产生一笔金库存款/提款后修改此值
		field.Int64("gold_amount").Default(0).StructTag("excel:\"金库金额\"").Comment("金库金额"), //产生一笔金库存款/提款后修改此值，用于方便显示总资产
		field.Time("gold_withdraw_time").Annotations(entsql.Annotation{Default: "CURRENT_TIMESTAMP"}).Default(time.Now).Comment("上次提款时间"),
		field.Int64("gold_infav_amount").Default(0).Comment("计算利息金额"),
		field.Int64("gold_outfav_amount").Default(0).Comment("不计算利息金额金额"),
		field.Int64("gold_fav_rate").Default(0).Comment("金库利息利率"),
		field.Time("gold_fav_time").Optional().Comment("第一次充值时间点"),
		field.Time("gold_last_fav_time").Optional().Comment("上次计算利息时间"),
		//关键时间
		field.Time("last_recharge_time").Optional().StructTag("excel:\"上次充值时间\"").Comment("上次充值时间"),
		field.Time("last_withdraw_time").Optional().StructTag("excel:\"上次提现时间\"").Comment("上次提现时间"),
		//破产礼包2
		field.Bool("pclb2_join").Default(false).Comment("破产礼包2-是否参加"),
		field.Time("pclb2_exp_time").Optional().Comment("破产礼包2-充值有效期"),
		field.Time("pclb2_join_time").Optional().Comment("破产礼包2-充值时间"),
		field.Int64("pclb2_join_amount").Default(0).Comment("破产礼包2-充值金额"),
		field.Int64("pclb2_fav").Default(0).Comment("破产礼包2-优惠总金额"),
		field.Int64("pclb2_fav1").Default(0).Comment("破产礼包2-第1天已领金额"),
		field.Int64("pclb2_fav2").Default(0).Comment("破产礼包2-第2天已领金额"),
		field.Int64("pclb2_fav3").Default(0).Comment("破产礼包2-第3天已领金额"),
		field.JSON("fixed_recharge", ftype.FixedRechargeDefault).Default(ftype.FixedRechargeDefault).Optional().Comment("固定充值礼包"),
		//连续充值活动
		field.Int64("lxcz_exp_time").Default(0).Comment("连续充值-充值有效期"),
		field.Int32("lxcz_last_recharge_day").Default(0).Comment("连续充值-上次充值的天数"),
		field.Int64("lxcz_last_recharge_time").Default(0).Comment("连续充值上次-充值时间"),
		// field.String("lxcz_receive").Optional().Comment("连续充值-领取了哪几天的赠品"),
		// field.Int64("lxcz_round").Default(0).Comment("连续充值-活动轮数"),
		// field.String("lxcz_code").Optional().Comment("连续充值-活动期号"),
		// 是否用过兑换码
		field.Bool("use_cdk").Default(false).Comment("兑换码-是否参加"),

		field.Int64("gift_center_received_amount").Default(0).Comment("奖励中心-总计领取"),
		field.Int64("gift_center_total_transactions").Default(0).Comment("奖励中心-总交易数"),
		//循环活动-幸运翻牌
		field.Int64("lucky_code").Default(0).Comment("循环活动-当前期号"),
		field.Int64("lucky_a_round").Default(0).Comment("循环活动-A当前轮数"),
		field.Int64("lucky_a_point").Default(0).Comment("循环活动-A当前节点"),
		field.Int64("lucky_a_play").Default(0).Comment("循环活动-A剩余次数"),
		field.Int64("lucky_b_round").Default(0).Comment("循环活动-B当前轮数"),
		field.Int64("lucky_b_point").Default(0).Comment("循环活动-B当前节点"),
		field.Int64("lucky_b_play").Default(0).Comment("循环活动-B剩余次数"),
		field.Int64("lucky_vip_day").Default(0).Comment("循环活动-VIP领取日期"), //20240928
		field.Int64("lucky_vip_point").Default(0).Comment("循环活动-VIP登录领取等级"),
		//VIP每次抽奖活动
		field.Int64("mrcj_vip_day").Default(0).Comment("每次抽奖-VIP领取日期"), //20240928
		field.Int64("mrcj_vip_amount").Default(0).Comment("每次抽奖-个人积分"), //
		field.Int64("mrcj_vip_point").Default(0).Comment("每次抽奖-VIP领取等级"),
		field.Int64("mrcj_free_draw").Default(0).Comment("每次抽奖-免费次数"), //1
		field.Int64("mrcj_vip_draw").Default(0).Comment("每次抽奖-奖励次数"),  //1
		//优惠券充值
		field.JSON("coupon_recharge", ftype.CouponRecharge{}).Default(ftype.CouponRecharge{}).Comment("优惠券充值"),
		//累计充值
		field.JSON("leiji_recharge", ftype.LiejiRecharge{}).Default(ftype.LiejiRecharge{}).Comment("累计充值"),
		//订阅
		field.JSON("dingyue", ftype.Dingyue{}).Default(ftype.Dingyue{}).Comment("订阅"),
		//总购买
		field.Int64("total_buy").Default(0).Comment("总购买"),
		//拼多多
		field.JSON("pdd", ftype.Pdd{}).Default(ftype.Pdd{}).Comment("拼多多"),
		//落地页参数
		field.JSON("lpparams", ftype.SSKeyValue{}).Default(ftype.SSKeyValue{}).Comment("落地页参数"),
		//来源
		field.Int("app_type").Default(0).Comment("app来源0-apk,1-h5"),
	}
}

// Edges of the Account.
func (Account) Edges() []ent.Edge {
	return []ent.Edge{
		edge.To("accountdailydatas", AccountDailyData.Type),
	}
}

func (Account) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}

func (Account) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("mobile"),
		index.Fields("username"),
		index.Fields("device", "source", "created_at", "mobile"),
		index.Fields("ip", "created_at"),
		index.Fields("email"),
	}
}
