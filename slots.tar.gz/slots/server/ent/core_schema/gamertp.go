package core_schema

import (
	"server/ent/schema/mixin"

	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// GameRtp holds the schema definition for the GameRtp entity.
type GameRtp struct {
	ent.Schema
}

// Fields of the GameRtp.
func (GameRtp) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("id").Unique().Annotations(entsql.Annotation{
			Incremental: &incrementalEnabled,
		}),
		field.Int64("game_id").Comment("游戏ID"),
		field.Int64("company_id").Comment("游戏商ID"),
		field.Int64("rtp").Default(0).Comment("rtb值"),
	}
}

// Edges of the GameRtp.
func (GameRtp) Edges() []ent.Edge {
	return []ent.Edge{
		edge.From("game", Game.Type).Ref("rtpgames").Field("game_id").Required().Unique(),
	}
}

func (GameRtp) Mixin() []ent.Mixin {
	return []ent.Mixin{
		mixin.Time{},
	}
}

func (GameRtp) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("company_id", "game_id").Unique(),
	}
}
