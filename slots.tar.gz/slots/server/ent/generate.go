package ent

//go:generate go run -mod=mod entgo.io/ent/cmd/ent generate --target ./core_db --feature privacy,entql,schema/snapshot,sql/execquery,sql/lock,sql/modifier,sql/upsert ./core_schema
//go:generate go run -mod=mod entgo.io/ent/cmd/ent generate --target ./request_db --feature privacy,entql,schema/snapshot,sql/execquery,sql/lock,sql/modifier,sql/upsert ./request_schema
