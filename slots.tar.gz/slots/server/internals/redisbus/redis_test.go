package redisbus

import "testing"

func TestIdToCompleteBucket(t *testing.T) {

	a := idToCompleteBucket("lock_nft", "111102130-0")
	_ = len(a)

	type args struct {
		topic string
		id    string
	}
	tests := []struct {
		name string
		args args
		want string
	}{}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := idToCompleteBucket(tt.args.topic, tt.args.id); got != tt.want {
				t.Errorf("IdToCompleteBucket() = %v, want %v", got, tt.want)
			}
		})
	}
}
