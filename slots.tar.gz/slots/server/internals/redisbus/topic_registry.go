package redisbus

import (
	"server/internals/core/chann"
	"server/internals/localstate"
	"server/internals/logger"
	"server/internals/utils/ujson"

	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

type ITopicRegistry interface {
	Topic() string
	Update()
	Push(string, []byte)
	Index() int
	SetIndex(int)
}

type TopicItem[T proto.Message] struct {
	Id  string
	Val T
}

type TopicRegistry[T any, PT interface {
	*T
	proto.Message
}] struct {
	index   int
	topic   string
	events  *chann.Chann[*TopicItem[PT]]
	handler func(*TopicItem[PT], func())
}

func (tr *TopicRegistry[T, PT]) Topic() string {
	return tr.topic
}

func (tr *TopicRegistry[T, PT]) Index() int {
	return tr.index
}

func (tr *TopicRegistry[T, PT]) SetIndex(idx int) {
	tr.index = idx
}

func (tr *TopicRegistry[T, PT]) Update() {
	for len(tr.events.Out()) > 0 {
		evt := <-tr.events.Out()
		tr.handler(evt, func() {
			e1 := localstate.Put(idToCompleteBucket(tr.topic, evt.Id), evt.Id, "ok")
			e2 := localstate.Put(fetchedBucket(), tr.topic, evt.Id)
			logger.Debugf("TopicRegistry:Update: %v %v %v %v ", idToCompleteBucket(tr.topic, evt.Id), evt.Id, e1, e2)
		})
	}
}

func (tr *TopicRegistry[T, PT]) Push(id string, data []byte) {

	if localstate.Exists(idToCompleteBucket(tr.topic, id), id) {
		logger.Debugf("local state: old message: %v", id)
		return
	}

	d := eventArgsCreator[T, PT]()
	err := protojson.Unmarshal(data, d)
	if err != nil {
		logger.Errorf("TopicRegistry.Push topic: %v, proto.Unmarshal Failed: id:%#v, %#v", tr.topic, id, err)
		return
	}
	logger.Debugf("TopicRegistry.Push: topic: %v, evtId: %v, push: %v", tr.topic, id, ujson.ProtoBufToJsonString(d))

	tr.events.In() <- &TopicItem[PT]{
		Id:  id,
		Val: d,
	}
}
