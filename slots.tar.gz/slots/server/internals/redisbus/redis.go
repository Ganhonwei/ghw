package redisbus

import (
	"context"
	"fmt"
	"server/internals/core/chann"
	"server/internals/localstate"
	"server/internals/logger"
	"server/internals/utils/utypes"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	redis "github.com/go-redis/redis/v9"
	"github.com/samber/lo"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

var rdb *redis.Client
var registries = map[string]ITopicRegistry{}
var keys = []string{}
var wg = sync.WaitGroup{}
var closeCh = make(chan struct{})
var prefix = ""

const (
	KeyValue          = "val"
	MilliSecondsInDay = 60 * 60 * 24 * 1000
	XReadBatchSize    = 100
	StreamMaxSize     = 1000
)

func fetchedBucket() string {
	return "FetchEvents"
}

func idToCompleteBucket(topic, id string) string {
	tsMs, seq := 0, 0
	_, _ = fmt.Sscanf(id, "%d-%d", &tsMs, &seq)
	return fmt.Sprintf("EventCompleted:%05d:%s", tsMs/MilliSecondsInDay, topic)
}

func topicToStreamName(topic string) string {
	return fmt.Sprintf("%s:%s", prefix, topic)
}

func streamNameToTopic(stream string) string {
	return strings.TrimPrefix(strings.TrimPrefix(stream, prefix), ":")
}

func Open(url string, prefixRedis string) {
	opt, err := redis.ParseURL(url)
	if err != nil {
		logger.Errorf("redis.ParseURL Failed: %+v\n", err)
		panic("redis.ParseURL Failed")
	}

	rdb = redis.NewClient(opt)
	prefix = prefixRedis

	for {
		e := rdb.Ping(context.Background()).Err()
		if e == nil {
			break
		}
		logger.Errorf("Connect To Redis Failed: %+v\n", e)
		time.Sleep(time.Second)
	}

	logger.Infoln("Connected to Redis Success")
}

func StartWatcher() {

	wg.Add(1)
	go func() {
		defer wg.Done()

		registryLen := len(registries)
		idOffset := len(registries)
		streams := make([]string, registryLen*2) // key 1, key N, ..., Id 1, Id N, ...
		for _, r := range registries {
			streams[r.Index()] = topicToStreamName(r.Topic())

			id := localstate.Get(fetchedBucket(), r.Topic())
			if len(id) < 1 {
				id = "0-0"
			}

			streams[idOffset+r.Index()] = id
		}

		for {
			select {
			case <-closeCh:
				return
			default:

				// logger.Debugf("try read  from redis: %v", ujson.MarshalToString2(streams))

				val, err := rdb.XRead(context.Background(), &redis.XReadArgs{
					Streams: streams,
					Count:   XReadBatchSize,
					Block:   time.Second,
				}).Result()

				if err != nil {
					if err != redis.Nil {
						logger.Errorf("Fetch RedisStream Failed: %#v %#v\n", streams, err)
					}

					time.Sleep(time.Second)
					continue
				}

				for _, s := range val {
					topic := streamNameToTopic(s.Stream)
					r := registries[topic]
					for _, m := range s.Messages {
						// logger.Debugf("received message from redis: %v", ujson.MarshalToString2(m))
						r.Push(m.ID, utypes.StringToBytes(m.Values[KeyValue].(string)))
						streams[idOffset+r.Index()] = m.ID
					}
				}
			}
		}

	}()

}

func UpdateInMainLoop() {

	for _, k := range keys {
		r := registries[k]
		r.Update()
	}
}

func Close() {
	close(closeCh)
	wg.Wait()
	rdb.Close()
	rdb = nil
}

func eventArgsCreator[T any, PT interface {
	*T
	proto.Message
}]() PT {
	return PT(new(T))
}

func RegisterHandler[T any, PT interface {
	*T
	proto.Message
}](topic string, h func(arg *TopicItem[PT], completer func())) {

	if _, found := registries[topic]; found {
		panic("RegisterHanlder Registry Duplicated")
	}

	registries[topic] = &TopicRegistry[T, PT]{
		index:   len(registries),
		topic:   topic,
		handler: h,
		events:  chann.New[*TopicItem[PT]](chann.Cap(-1)),
	}

	keys = lo.Keys(registries)
	sort.SliceStable(keys, func(i, j int) bool { return strings.Compare(keys[i], keys[j]) < 0 })
}

func PublishTopic[T proto.Message](topic string, arg T) error {

	argData, _ := protojson.Marshal(arg)
	// logger.Debugf("PublishTopic: %v: %v", topic, string(argData))
	return rdb.XAdd(context.Background(), &redis.XAddArgs{
		Stream: topicToStreamName(topic),
		MaxLen: StreamMaxSize,
		Approx: true,
		ID:     "*",
		Values: []string{KeyValue, utypes.BytesToString(argData)},
	}).Err()
}

func Set(key string, value interface{}, sec time.Duration) {
	exp := sec * time.Second
	rdb.Set(rdb.Context(), key, value, exp)
}

func Del(key string) {
	rdb.Del(rdb.Context(), key)
}

func Get(key string) interface{} {
	result, err := rdb.Get(rdb.Context(), key).Result()
	if err != nil {
		return nil
	}
	return result
}

func Exists(key string) bool {
	cmd := rdb.Exists(rdb.Context(), key)
	return cmd.Val() > 0
}

func GetInt64(key string) int64 {
	result, err := rdb.Get(rdb.Context(), key).Result()
	if err != nil {
		return 0
	}
	r, err := strconv.ParseInt(result, 10, 64)
	if err != nil {
		return 0
	}
	return r
}

func AddSet(key string, value string) {
	rdb.SAdd(rdb.Context(), key, value)
}

func RedisDb() *redis.Client {
	return rdb
}

func RemoveSet(key string, value string) {
	rdb.SRem(rdb.Context(), key, value)
}

func MembersSet(key string) []string {
	result, _ := rdb.SMembers(rdb.Context(), key).Result()
	return result
}

func MatchKeys(key string) []string {
	result, _ := rdb.Keys(rdb.Context(), key).Result()
	return result
}

func ZAdd(key string, member redis.Z) {
	rdb.ZAdd(rdb.Context(), key, member)
}

func ZRem(key string, member redis.Z) {
	rdb.ZRem(rdb.Context(), key, member)
}

func ZRemRangeByRank(key string, start, end int64) {
	rdb.ZRemRangeByRank(rdb.Context(), key, start, end)
}

func ZRang(key string, start, end int64) *redis.StringSliceCmd {
	list := rdb.ZRange(rdb.Context(), key, start, end)
	return list
}

func ZRevRank(key, member string) *redis.IntCmd {
	return rdb.ZRevRank(rdb.Context(), key, member)
}

func ZRevRange(key string, start, end int64) *redis.StringSliceCmd {
	list := rdb.ZRevRange(rdb.Context(), key, start, end)
	return list
}

func ZRangeByScore(key string, opt *redis.ZRangeBy) *redis.StringSliceCmd {
	return rdb.ZRangeByScore(rdb.Context(), key, opt)
}

func ZCard(key string) *redis.IntCmd {
	return rdb.ZCard(rdb.Context(), key)
}

func ZRevRangeWithScores(key string, start, end int64) *redis.ZSliceCmd {
	return rdb.ZRevRangeWithScores(rdb.Context(), key, start, end)
	// return rdb.ZRevRangeByScoreWithScores(rdb.Context(), key, opt)
}

func HMGet(key string, fields ...string) *redis.SliceCmd {
	return rdb.HMGet(rdb.Context(), key, fields...)
}

func HSet(key string, fields ...any) *redis.IntCmd {
	return rdb.HSet(rdb.Context(), key, fields...)
}
