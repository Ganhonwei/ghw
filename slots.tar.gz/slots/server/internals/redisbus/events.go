package redisbus

const (
	TopicCleanupCache          = "cleanup_cache"
	TopicReloadLoggerLevels    = "reload_logger_level"
	TopicCleanupPlatAuthCache  = "cleanup_cache_plat_auth"
	TopicReloadGoogleIapConfig = "reload_google_iap_config"
)
