package cmdexec

import "server/internals/core/chann"

type Cmd func()

var (
	cmds = chann.New[Cmd](chann.Cap(-1))
)

func PushCmd(cmd Cmd) {
	cmds.In() <- cmd
}

func BatchExecute(size int) bool {
	// && cmds.Len() > 0
	for i := 0; i < size && len(cmds.Out()) > 0; i++ {
		cmd := <-cmds.Out()
		cmd()
	}
	return cmds.Len() > 0
}
