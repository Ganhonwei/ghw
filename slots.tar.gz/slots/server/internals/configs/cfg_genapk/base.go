package cfg_genapk

import (
	"io/ioutil"
	"server/internals/logger"

	"gopkg.in/yaml.v3"
)

type BaseConfig struct {
	Mode                string `json:"mode" yaml:"mode"`
	Dsn                 string `json:"dsn" yaml:"dsn"`
	DsnRead             string `json:"dsn_read" yaml:"dsn_read"`
	DatabasePoolMaxIdle int    `json:"database_pool_max_idle" yaml:"database_pool_max_idle"`
	DatabasePoolMaxOpen int    `json:"database_pool_max_open" yaml:"database_pool_max_open"`
}

var Config = &BaseConfig{}

func LoadConfig(path string) error {
	logger.Debugf("Load Config: %s", path)
	yamlFile, err := ioutil.ReadFile(path)
	if err != nil {
		return err
	}

	return yaml.Unmarshal(yamlFile, Config)
}
