package cfg_plat

import (
	"time"

	"server/internals/configs/cfg"
	"server/internals/logger"
	"server/internals/utils/ufile"
	"server/internals/utils/utypes"

	"gopkg.in/yaml.v3"
)

type PlatConfig struct {
	Mode                 string             `json:"mode" yaml:"mode"`
	AllowPprof           bool               `json:"allow_pprof" yaml:"allow_pprof"`
	ClientBind           string             `json:"client_bind" yaml:"client_bind"`
	ConfDir              string             `json:"conf_dir" yaml:"conf_dir"`
	CoreDB               *cfg.DatabaseCfg   `json:"core_db" yaml:"core_db"`
	RequestDB            *cfg.DatabaseCfg   `json:"request_db" yaml:"request_db"`
	JwtKey               string             `json:"jwt_key" yaml:"jwt_key"`
	RedisUrl             string             `json:"redis_url" yaml:"redis_url"`
	RedisPrefix          string             `json:"redis_prefix" yaml:"redis_prefix"`
	CountryCode          string             `json:"country_code" yaml:"country_code"`
	SupportedLangs       []string           `json:"supported_langs" yaml:"supported_langs"`
	DefaultLang          string             `json:"default_lang" yaml:"default_lang"`
	PearPay              *cfg.PearPayConfig `json:"pearpay" yaml:"pearpay"`
	TenaPay              *cfg.TenaPayConfig `json:"tenapay" yaml:"tenapay"`
	HkPay                *cfg.HkPayConfig   `json:"hkpay" yaml:"hkpay"`
	IPGeoUrl             string             `json:"ip_geo_url" yaml:"ip_geo_url"`
	LocalSatePath        string             `json:"local_state_path" yaml:"local_state_path"`
	ThirdPrefix          string             `json:"third_prefix" yaml:"third_prefix"`
	ForceCheckSessionKey bool               `json:"force_check_session_key" yaml:"force_check_session_key"`

	JwtKeyBytes      []byte                 `json:"jwt_key_bytes" yaml:"jwt_key_bytes"`
	WorldJwtKeyBytes []byte                 `json:"-" yaml:"-"`
	GmJwtKeyBytes    []byte                 `json:"-" yaml:"-"`
	Appsflyer        []*cfg.AppsflyerConfig `json:"appsflyer" yaml:"appsflyer"`
	AdJust           []*cfg.AdJustConfig    `json:"ad_just" yaml:"ad_just"`
	Email            *cfg.Email             `json:"email" yaml:"email"`
}

var Plat = &PlatConfig{
	ClientBind: "0.0.0.0:5000",
}

func (cfg *PlatConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		cfg.JwtKeyBytes = utypes.StringToBytes(cfg.JwtKey)
		break
	}
}
