package cfg_task

import (
	"os"

	"server/internals/configs/cfg"
	"server/internals/logger"

	"gopkg.in/yaml.v3"
)

type BaseConfig struct {
	Mode string `json:"mode" yaml:"mode"`

	CoreDB    *cfg.DatabaseCfg `json:"core_db" yaml:"core_db"`
	RequestDB *cfg.DatabaseCfg `json:"request_db" yaml:"request_db"`

	RedisUrl    string `json:"redis_url" yaml:"redis_url"`
	RedisPrefix string `json:"redis_prefix" yaml:"redis_prefix"`

	BoltDb        string             `json:"bolt_db" yaml:"bolt_db"`
	LocalSatePath string             `json:"local_state_path" yaml:"local_state_path"`
	Bind          string             `json:"bind" yaml:"bind"`
	ThirdPrefix   string             `json:"third_prefix" yaml:"third_prefix"`
	ConfDir       string             `json:"conf_dir" yaml:"conf_dir"`
	PearPay       *cfg.PearPayConfig `json:"pearpay" yaml:"pearpay"`
	TenaPay       *cfg.TenaPayConfig `json:"tenapay" yaml:"tenapay"`
	HkPay         *cfg.HkPayConfig   `json:"hkpay" yaml:"hkpay"`
}

type PearPayConfig struct {
	Enabled       bool   `json:"enabled" yaml:"enabled"`
	MchId         int    `json:"mch_id" yaml:"mch_id"`
	PartnerKey    string `json:"partner_key" yaml:"partner_key"`
	Token         string `json:"token" yaml:"token"`
	AesKey        string `json:"aes_key" yaml:"aes_key"`
	PayAppId      int    `json:"pay_app_id" yaml:"pay_app_id"`
	RechargeAppId int    `json:"recharge_app_id" yaml:"recharge_app_id"`
	BaseUrl       string `json:"base_url" yaml:"base_url"`
	RedirectUrl   string `json:"redirect_url" yaml:"redirect_url"`
}

type TenaPayConfig struct {
	Enabled     bool   `json:"enabled" yaml:"enabled"`
	MchId       string `json:"mch_id" yaml:"mch_id"`
	ProductId   int    `json:"product_id" yaml:"product_id"`
	Key         string `json:"key" yaml:"key"`
	BaseUrl     string `json:"base_url" yaml:"base_url"`
	CallbackUrl string `json:"callback_url" yaml:"callback_url"`
}

type HkPayConfig struct {
	Enabled     bool   `json:"enabled" yaml:"enabled"`
	MchId       string `json:"mch_id" yaml:"mch_id"`
	Md5Key      string `json:"md5_key" yaml:"md5_key"`
	ShaKey      string `json:"sha_key" yaml:"sha_key"`
	BaseUrl     string `json:"base_url" yaml:"base_url"`
	CallbackUrl string `json:"callback_url" yaml:"callback_url"`
}

var Config = &BaseConfig{}

func LoadConfig(path string) error {
	logger.Debugf("Load Config: %s", path)
	yamlFile, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	return yaml.Unmarshal(yamlFile, Config)
}
