package game_confs

type HbGameInfo struct {
	KeyName    string `json:"keyname,omitempty"`
	GameName   string `json:"gamename,omitempty"`
	GameNameCn string `json:"gamenamecn,omitempty"`
	GameType   string `json:"gametype,omitempty"`
	GameLogo   string `json:"gamelogo,omitempty"`
}

var HbGameInfoArray []*HbGameInfo
var HbGameInfos map[string]*HbGameInfo

func init() {
	addBindDataInitFunc(
		2,
		"hbgame.json",
		&HbGameInfoArray,
		&HbGameInfos,
		func(i int) interface{} { return HbGameInfoArray[i].KeyName },
		func() error {
			return nil
		},
	)
}
