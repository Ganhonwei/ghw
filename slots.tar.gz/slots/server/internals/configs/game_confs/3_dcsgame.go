package game_confs

type DcsLogo struct {
	Code string `json:"code,omitempty"`
	Logo string `json:"logo,omitempty"`
}

var DcsGameInfoArray []*DcsLogo
var DcsGameInfos map[string]*DcsLogo

func init() {
	addBindDataInitFunc(
		3,
		"dcsgame.json",
		&DcsGameInfoArray,
		&DcsGameInfos,
		func(i int) interface{} { return DcsGameInfoArray[i].Code },
		func() error {
			return nil
		},
	)
}
