package game_confs

type OneApiLogo struct {
	Code string `json:"code,omitempty"`
	Logo string `json:"logo,omitempty"`
}

var OneApiGameInfoArray []OneApiLogo
var OneApiGameInfos map[string]*OneApiLogo

func init() {
	addBindDataInitFunc(
		1,
		"oneapigame.json",
		&OneApiGameInfoArray,
		&OneApiGameInfos,
		func(i int) interface{} { return OneApiGameInfoArray[i] },
		func() error {
			return nil
		},
	)
}
