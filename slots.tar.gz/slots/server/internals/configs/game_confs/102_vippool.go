package game_confs

import (
	"server/internals/utils/umoney"
	"server/internals/utils/uslice"
)

type VipAmountConfig struct {
	Code      int64 `json:"code,omitempty"`       //档次编号
	BetAmount int64 `json:"bet_amount,omitempty"` //总打码量
	MinRate   int64 `json:"min_rate,omitempty"`   //最低奖金比例
	MaxRate   int64 `json:"max_rate,omitempty"`   //最高奖金比例
	Level     bool  `json:"level,omitempty"`      //级别
	MaxAmount int64 `json:"max_amount,omitempty"` //奖金上限

	BetAmountFen int64 `json:"-" excel:"ignore"` //总打码量 分
	MaxAmountFen int64 `json:"-" excel:"ignore"` //奖金上限 分
}

var VipAmountConfigArray []*VipAmountConfig
var VipAmountConfigs map[int64]*VipAmountConfig

type VipBetConfig struct {
	Code      int64 `json:"code,omitempty"`       //档次编号
	BetAmount int64 `json:"bet_amount,omitempty"` //要求打码量
	BetRate   int64 `json:"bet_rate,omitempty"`   //中奖概率
	Status    bool  `json:"status,omitempty"`     //是否触发

	BetAmountFen int64 `json:"-" excel:"ignore"` // 要求打码量 分
}

var VipBetConfigArray []*VipBetConfig
var VipBetConfigs map[int64]*VipBetConfig

type VipLossConfig struct {
	Code      int64 `json:"code,omitempty"`       //档次编号
	BetAmount int64 `json:"bet_amount,omitempty"` //亏损金额
	WinRate   int64 `json:"win_rate,omitempty"`   //盈概率
	LossRate  int64 `json:"loss_rate,omitempty"`  //亏概率
	Status    bool  `json:"status,omitempty"`     //是否触发

	BetAmountFen int64 `json:"-" excel:"ignore"` // 亏损金额 分
}

var VipLossConfigArray []*VipLossConfig
var VipLossConfigs map[int64]*VipLossConfig

type VipPoolConfig struct {
	Code   int64 `json:"code,omitempty"`   // 档次编号
	Amount int64 `json:"amount,omitempty"` // 累计金额
	Level  int32 `json:"level,omitempty"`  // VIP等级及以上
	Cd     int64 `json:"cd,omitempty"`     // 中奖CD(小时)
	Rate   int64 `json:"rate,omitempty"`   // 中奖概率
	Count  int32 `json:"count,omitempty"`  // 中奖数量

	AmountFen int64 `json:"-" excel:"ignore"` // 累计金额 分
}

var VipPoolConfigArray []*VipPoolConfig
var VipPoolConfigs map[int64]*VipPoolConfig

func init() {
	addBindDataInitFunc(
		102,
		"vipamount.json",
		&VipAmountConfigArray,
		&VipAmountConfigs,
		func(i int) interface{} { return VipAmountConfigArray[i].Code },
		func() error {
			uslice.Forech(VipAmountConfigArray, func(cfg *VipAmountConfig) {
				cfg.BetAmountFen = umoney.Yuan2IntFen(cfg.BetAmount)
				cfg.MaxAmountFen = umoney.Yuan2IntFen(cfg.MaxAmount)
			})
			return nil
		},
	)
	addBindDataInitFunc(
		102,
		"vipbet.json",
		&VipBetConfigArray,
		&VipBetConfigs,
		func(i int) interface{} { return VipBetConfigArray[i].Code },
		func() error {
			uslice.Forech(VipBetConfigArray, func(cfg *VipBetConfig) {
				cfg.BetAmountFen = umoney.Yuan2IntFen(cfg.BetAmount)
			})
			return nil
		},
	)
	addBindDataInitFunc(
		102,
		"viploss.json",
		&VipLossConfigArray,
		&VipLossConfigs,
		func(i int) interface{} { return VipLossConfigArray[i].Code },
		func() error {
			uslice.Forech(VipLossConfigArray, func(cfg *VipLossConfig) {
				cfg.BetAmountFen = umoney.Yuan2IntFen(cfg.BetAmount)
			})
			return nil
		},
	)
	addBindDataInitFunc(
		102,
		"vippool.json",
		&VipPoolConfigArray,
		&VipPoolConfigs,
		func(i int) interface{} { return VipPoolConfigArray[i].Code },
		func() error {
			uslice.Forech(VipPoolConfigArray, func(cfg *VipPoolConfig) {
				cfg.AmountFen = umoney.Yuan2IntFen(cfg.Amount)
			})
			return nil
		},
	)
}
