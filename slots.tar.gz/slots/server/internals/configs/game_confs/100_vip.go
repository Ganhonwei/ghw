package game_confs

import (
	"server/internals/utils/umoney"
	"server/internals/utils/uslice"
)

type VipMonthlyReward struct {
	Day         int32 `json:"day,omitempty"`
	Amount      int64 `json:"amount,omitempty"`
	WithDrawBet int64 `json:"with_draw_bet,omitempty"` //打码倍数

	AmountFen int64 `json:"-" excel:"ignore"` //最大提现限额 单位: 分
}

// Vip
type VipGrowupConfig struct {
	Level                   int32               `json:"level,omitempty"`                       //等级
	Exp                     int64               `json:"exp,omitempty"`                         //升级积分
	LevelTotalBet           int64               `json:"level_total_bet,omitempty"`             //保级每月需要的打码量
	BetExpRate              int64               `json:"bet_exp_rate,omitempty"`                //下注积分比例
	WithdrawTimes           int32               `json:"withdraw_times,omitempty"`              //当日提现次数
	WithdrawTotalAmount     int64               `json:"withdraw_total_amount,omitempty"`       //提现总金额
	WithdrawRate            int64               `json:"withdraw_rate,omitempty"`               //提现手续费率
	WithdrawRateAmount      int64               `json:"withdraw_rate_amount,omitempty"`        //提现最低手续费  单位:
	WithdrawMinAmount       int64               `json:"withdraw_min_amount,omitempty"`         //最小提现限额
	WithdrawMaxAmount       int64               `json:"withdraw_max_amount,omitempty"`         //最大提现限额 ==> 前端专用, 提现总额
	WithdrawMaxAmountReal   int64               `json:"withdraw_max_amount_real,omitempty"`    //最大提现限额
	HasService              bool                `json:"has_service,omitempty"`                 //专属客服
	DelVipExp               int64               `json:"un_login_exp,omitempty"`                //未达保级应扣除的经验值
	VipUpgradeReward        int64               `json:"vip_upgrade_reward,omitempty"`          //升级奖金
	FanshuiRatio            int64               `json:"fanshui_ratio,omitempty"`               //反水比例
	FanshuiAmountMax        int64               `json:"fanshui_amount_max,omitempty"`          //每日返水上限
	WithDrawBetRate         int64               `json:"withdraw_bet_rate,omitempty"`           //提现打码倍率
	Phase                   int32               `json:"phase,omitempty"`                       //vip阶段
	VipUpgradeRewardBetRate int64               `json:"vip_upgrade_reward_bet_rate,omitempty"` //升级奖金打码量
	VipMonthlyReward        []*VipMonthlyReward `json:"vip_monthly_reward,omitempty"`          //派红奖金
	WithdrawDayAmount       int64               `json:"withdraw_day_amount,omitempty"`         //每日提现限额

	VipUpgradeRewardFen      int64 `json:"-" excel:"ignore"` // 升级奖金 单位: 分
	WithdrawRateAmountFen    int64 `json:"-" excel:"ignore"` // 提现最低手续费 单位: 分
	WithdrawMinAmountFen     int64 `json:"-" excel:"ignore"` // 最小提现限额 单位: 分
	WithdrawMaxAmountFen     int64 `json:"-" excel:"ignore"` // 最大提现限额 ==> 前端专用, 提现总额 单位: 分
	WithdrawMaxAmountRealFen int64 `json:"-" excel:"ignore"` // 最大提现限额Real 单位: 分
	WithdrawTotalAmountFen   int64 `json:"-" excel:"ignore"` // 提现总金额 单位: 分
	LevelTotaBetFen          int64 `json:"-" excel:"ignore"` // 保级每月打码量 单位: 分
	FanshuiAmountMaxFen      int64 `json:"-" excel:"ignore"` // 每日返水上限 单位: 分
	WithdrawDayAmountFen     int64 `json:"-" excel:"ignore"` // 每日提现限额 单位: 分
}

var VipGrowupConfigArray []*VipGrowupConfig
var VipGrowupConfigs map[int32]*VipGrowupConfig

func init() {
	addBindDataInitFunc(
		100,
		"vip.json",
		&VipGrowupConfigArray,
		&VipGrowupConfigs,
		func(i int) interface{} { return VipGrowupConfigArray[i].Level },
		func() error {

			uslice.Forech(VipGrowupConfigArray, func(cfg *VipGrowupConfig) {
				cfg.VipUpgradeRewardFen = umoney.Yuan2IntFen(cfg.VipUpgradeReward)
				cfg.WithdrawMaxAmountRealFen = umoney.Yuan2IntFen(cfg.WithdrawMaxAmountReal)
				cfg.WithdrawMaxAmountFen = umoney.Yuan2IntFen(cfg.WithdrawMaxAmount)
				cfg.WithdrawMinAmountFen = umoney.Yuan2IntFen(cfg.WithdrawMinAmount)
				cfg.WithdrawRateAmountFen = umoney.Yuan2IntFen(cfg.WithdrawRateAmount)
				cfg.WithdrawTotalAmountFen = umoney.Yuan2IntFen(cfg.WithdrawTotalAmount)
				cfg.LevelTotaBetFen = umoney.Yuan2IntFen(cfg.LevelTotalBet)
				cfg.FanshuiAmountMaxFen = umoney.Yuan2IntFen(cfg.FanshuiAmountMax)
				cfg.WithdrawDayAmountFen = umoney.Yuan2IntFen(cfg.WithdrawDayAmount)

				uslice.Forech(cfg.VipMonthlyReward, func(cfg *VipMonthlyReward) {
					cfg.AmountFen = umoney.Yuan2IntFen(cfg.Amount)
				})

			})
			return nil
		},
	)
}
