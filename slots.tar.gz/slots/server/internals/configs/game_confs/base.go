package game_confs

import (
	"errors"
	"path"
	"reflect"
	"sort"
	"sync/atomic"

	"server/internals/logger"
	"server/internals/utils/ufile"
	"server/internals/utils/ufunc"
)

var initFuncList = map[int][]func() error{}
var afterCreatedFuncList = map[int][]func() error{}

var baseDir string
var seq64 = int64(1)

func Init(dir string, afterAllCreated func() error) error {
	logger.Infoln("GameConfigs is loading...")
	baseDir = dir

	var indexList []int
	for index := range initFuncList {
		indexList = append(indexList, index)
	}

	sort.Ints(indexList)

	for _, index := range indexList {
		if err := ufunc.RunParallel(initFuncList[index]...); err != nil {
			return err
		}
	}

	for _, index := range indexList {
		if err := ufunc.RunParallel(afterCreatedFuncList[index]...); err != nil {
			return err
		}
	}

	if afterAllCreated != nil {
		if err := afterAllCreated(); err != nil {
			return err
		}
	}

	return nil
}

func addInitFunc(index int, initFunc func() error, afterCreatedFunc func() error) {
	initFuncList[index] = append(initFuncList[index], initFunc)
	if afterCreatedFunc != nil {
		afterCreatedFuncList[index] = append(afterCreatedFuncList[index], afterCreatedFunc)
	}
}

func addBindDataInitFunc(order int, relativeJsonPath string, dataListPtr interface{}, dataMapPtr interface{}, keyFunc func(i int) interface{}, afterCreatedFunc func() error) {
	addInitFunc(
		order,
		func() error {

			defer func() {
				if r := recover(); r != nil {
					logger.Infoln("    Loading Failed: ", relativeJsonPath)
					logger.Infoln("    Loading Failed: ", relativeJsonPath)
					logger.Infoln("    Loading Failed: ", relativeJsonPath)
				}
			}()

			e := func() error {
				logger.Infoln("    Loading: ", relativeJsonPath)
				if dataListPtr == nil {
					return errors.New("dataListPtr can not be nil")
				}

				listPtrType := reflect.TypeOf(dataListPtr)
				if listPtrType.Kind() != reflect.Ptr || listPtrType.Elem().Kind() != reflect.Slice {
					return errors.New("dataListPtr can only be ptr of slice type")
				}

				err := ufile.UnmarshalFileToJson(path.Join(baseDir, relativeJsonPath), dataListPtr)
				if err != nil {
					return err
				}

				if dataMapPtr == nil {
					return nil
				}

				mapPtrType := reflect.TypeOf(dataMapPtr)
				if mapPtrType.Kind() != reflect.Ptr || mapPtrType.Elem().Kind() != reflect.Map {
					return errors.New("dataMapPtr can only be ptr of map type")
				}

				if dataMapPtr != nil && keyFunc == nil {
					return errors.New("keyFunc is mandatory when dataMapPtr is not nil")
				}

				mapType := mapPtrType.Elem()
				dataMapValue := reflect.MakeMapWithSize(mapType, 0)
				dataMapPtrValue := reflect.ValueOf(dataMapPtr)
				dataMapPtrValue.Elem().Set(dataMapValue)

				dataListPtrValue := reflect.ValueOf(dataListPtr)
				dataListValue := dataListPtrValue.Elem()
				for i := 0; i < dataListValue.Len(); i++ {
					dataListItem := dataListValue.Index(i)
					key := keyFunc(i)
					dataMapValue.SetMapIndex(reflect.ValueOf(key), dataListItem)
				}

				return nil
			}()

			if e != nil {
				logger.Infoln("    Loading Failed: ", relativeJsonPath)
				logger.Infoln("    Loading Failed: ", relativeJsonPath)
				logger.Infoln("    Loading Failed: ", relativeJsonPath)
			}
			return e
		},

		func() error {

			if afterCreatedFunc == nil {
				return nil
			}

			defer func() {
				if r := recover(); r != nil {
					logger.Infoln("    Loading Failed: afterCreatedFunc ", relativeJsonPath)
					logger.Errorln(r)
				}
			}()
			e := afterCreatedFunc()
			if e != nil {
				logger.Infoln("    Loading Failed: afterCreatedFunc ", relativeJsonPath)
				logger.Infoln("    Loading Failed: afterCreatedFunc ", relativeJsonPath)
				logger.Infoln("    Loading Failed: afterCreatedFunc ", relativeJsonPath)
			}
			return e

		},
	)
}

func nextSeq64() int64 {
	return atomic.AddInt64(&seq64, 1)
}
