package game_confs

type TemplateLang struct {
	Title string `json:"title,omitempty"`
	Key   string `json:"key,omitempty"`
	Val   string `json:"val,omitempty"`
}

// Template
type TemplateConfig struct {
	Code         string          `json:"code,omitempty"`          //模板编号
	Name         string          `json:"name,omitempty"`          //模板名称
	TemplateLang []*TemplateLang `json:"template_lang,omitempty"` //语言内容
}

var TemplateConfigArray []*TemplateConfig
var TemplateConfigs map[string]*TemplateConfig

func init() {
	addBindDataInitFunc(
		101,
		"template.json",
		&TemplateConfigArray,
		&TemplateConfigs,
		func(i int) interface{} { return TemplateConfigArray[i].Code },
		nil,
	)
}
