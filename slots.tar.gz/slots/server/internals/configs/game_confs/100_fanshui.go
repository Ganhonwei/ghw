package game_confs

import (
	"fmt"
	"server/internals/generated/core"
	"server/internals/generated/webapi/plat/platactivity"
	"server/internals/utils/umoney"
	"server/internals/utils/uslice"
)

// FanShuiVip
type FanShuiVipConfig struct {
	VipLevel  int32 `json:"vip_level,omitempty" yaml:"vip_level"`
	Scale     int64 `json:"scale,omitempty" yaml:"scale"`
	HighScale int64 `json:"high_scale,omitempty" yaml:"high_scale"`
}

var FanShuiVipConfigArray []*FanShuiVipConfig
var FanShuiVipConfigs map[int32]*FanShuiVipConfig

type FanShuiRangConfig struct {
	LowValue  int64 `json:"low_value,omitempty" yaml:"low_value"`
	HighValue int64 `json:"high_value,omitempty" yaml:"high_value"`
	NProbId   int32 `json:"n_prob_id,omitempty" yaml:"n_prob_id"`
	LProbId   int32 `json:"l_prob_id,omitempty" yaml:"l_prob_id"`

	LowValueFen  int64 `json:"-" excel:"ignore"`
	HighValueFen int64 `json:"-" excel:"ignore"`

	NProb []*FanShuiProbConfig `json:"-" excel:"ignore"`
	LProb []*FanShuiProbConfig `json:"-" excel:"ignore"`
}

func GetFanShuiRange(fsval int64) *FanShuiRangConfig {
	for _, cfg := range FanShuiRangConfigArray {
		if cfg.HighValueFen <= 0 && cfg.LowValueFen <= fsval {
			return cfg
		}

		if cfg.LowValueFen <= fsval && fsval <= cfg.HighValueFen {
			return cfg
		}
	}

	return nil
}

var FanShuiRangConfigArray []*FanShuiRangConfig

type FanShuiProbConfig struct {
	ProbId int32 `json:"prob_id,omitempty"`
	Weight int32 `json:"weight,omitempty"`
	Bonus  int64 `json:"bonus,omitempty"`

	BonusFen int64 `json:"-" excel:"ignore"`
}

var FanShuiProbConfigArray []*FanShuiProbConfig
var FanShuiProbConfigs = map[int32][]*FanShuiProbConfig{}

type FanShuiOptConfig struct {
	Bonus  int64                `json:"bonus,omitempty"`
	BgImg  string               `json:"bg_img,omitempty"`
	ResLoc core.ResLocationType `json:"res_loc,omitempty"`

	BonusFen int64 `json:"-" excel:"ignore"`
}

var FanShuiOptConfigArray []*FanShuiOptConfig
var FanShuiOptsForPkg []*platactivity.FanShuiOpts

func init() {
	addBindDataInitFunc(
		100,
		"fanshui_vip_rate.json",
		&FanShuiVipConfigArray,
		&FanShuiVipConfigs,
		func(i int) interface{} { return FanShuiVipConfigArray[i].VipLevel },
		nil,
	)

	addBindDataInitFunc(
		100,
		"fanshui_opts.json",
		&FanShuiOptConfigArray,
		nil,
		nil,
		func() error {
			uslice.Forech(FanShuiOptConfigArray, func(cfg *FanShuiOptConfig) { cfg.BonusFen = umoney.Yuan2IntFen(cfg.Bonus) })

			FanShuiOptsForPkg = uslice.Map(FanShuiOptConfigArray, func(cfg *FanShuiOptConfig) *platactivity.FanShuiOpts {
				return &platactivity.FanShuiOpts{
					Bonus:  cfg.BonusFen,
					BgImg:  cfg.BgImg,
					ResLoc: cfg.ResLoc,
				}
			})

			return nil
		},
	)

	addBindDataInitFunc(
		100,
		"fanshui_prob.json",
		&FanShuiProbConfigArray,
		nil,
		nil,
		func() error {
			for _, cfg := range FanShuiProbConfigArray {
				FanShuiProbConfigs[cfg.ProbId] = append(FanShuiProbConfigs[cfg.ProbId], cfg)
				cfg.BonusFen = umoney.Yuan2IntFen(cfg.Bonus)
			}

			return nil
		},
	)

	addBindDataInitFunc(
		101,
		"fanshui_range.json",
		&FanShuiRangConfigArray,
		nil,
		nil,
		func() error {

			for _, cfg := range FanShuiRangConfigArray {
				cfg.LProb = FanShuiProbConfigs[cfg.LProbId]
				cfg.NProb = FanShuiProbConfigs[cfg.NProbId]

				cfg.LowValueFen = umoney.Yuan2IntFen(cfg.LowValue)
				cfg.HighValueFen = umoney.Yuan2IntFen(cfg.HighValue)

				if cfg.LProb == nil || cfg.NProb == nil {
					return fmt.Errorf("Laod fanshui_range.json failed: %#v", cfg)
				}
			}

			return nil
		},
	)

}
