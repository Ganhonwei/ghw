package game_confs

type TranslatedGameNameData struct {
	Code  string `json:"code"`
	Value string `json:"value"`
}
type PlatformsData struct {
	Platform string `json:"platform"`
}
type LanguagesData struct {
	Code  string `json:"code"`
	Level string `json:"level"`
}

type MgGameInfo struct {
	GameLogo            string                    `json:"gameLogo,omitempty"`
	GameName            string                    `json:"gameName,omitempty"`
	GameCode            string                    `json:"gameCode,omitempty"`
	TranslatedGameName  []*TranslatedGameNameData `json:"translatedGameName,omitempty"`
	ChannelCode         string                    `json:"channelCode,omitempty"`
	ChannelName         string                    `json:"channelName,omitempty"`
	GameCategoryCode    string                    `json:"gameCategoryCode,omitempty"`
	GameCategoryName    string                    `json:"gameCategoryName,omitempty"`
	GameSubcategoryCode string                    `json:"gameSubcategoryCode,omitempty"`
	GameSubcategoryName string                    `json:"gameSubcategoryName,omitempty"`
	ReleaseDateUTC      string                    `json:"releaseDateUTC,omitempty"`
	Platform            string                    `json:"platform,omitempty"`
	Platforms           []*PlatformsData          `json:"platforms,omitempty"`
	IsDemoEnabled       bool                      `json:"isDemoEnabled,omitempty"`
	Languages           []*LanguagesData          `json:"languages,omitempty"`
	Rtp                 *float64                  `json:"rtp,omitempty"`
	GameFeatures        []*string                 `json:"gameFeatures,omitempty"`
}

var MgGameInfoArray []*MgGameInfo
var MgGameInfos map[string]*MgGameInfo

func init() {
	addBindDataInitFunc(
		4,
		"mggame.json",
		&MgGameInfoArray,
		&MgGameInfos,
		func(i int) interface{} { return MgGameInfoArray[i].GameName },
		func() error {
			return nil
		},
	)
}
