package game_confs

import (
	"fmt"
	"server/internals/utils/umoney"
	"server/internals/utils/uslice"
	"strings"

	"golang.org/x/exp/slices"
)

type JackPotBonusDrawsConfig struct {
	ProbId    int32 `json:"prob_id,omitempty"`    // 奖池ID
	DrawCount int32 `json:"draw_count,omitempty"` // 奖励次数
	ValidBet  int64 `json:"valid_bet,omitempty"`  // 奖励门槛（有效投注）
}

var JackPotBonusDrawsConfigArray []*JackPotBonusDrawsConfig
var JackPotBonusDrawsConfigs = map[int32][]*JackPotBonusDrawsConfig{}

type JackPotOrdinaryPoolConfig struct {
	ProbId      int32 `json:"prob_id,omitempty"`       // 奖池ID
	Weight      int32 `json:"weight,omitempty"`        // 权重
	BonusMin    int64 `json:"bonus_min,omitempty"`     // 最小奖金
	BonusMax    int64 `json:"bonus_max,omitempty"`     // 最大奖金
	BonusMinFen int64 `json:"bonus_min_fen,omitempty"` // 最小奖金(fen)
	BonusMaxFen int64 `json:"bonus_max_fen,omitempty"` // 最大奖金(fen)
}

var JackPotOrdinaryPoolConfigArray []*JackPotOrdinaryPoolConfig
var JackPotOrdinaryPoolConfigs = map[int32][]*JackPotOrdinaryPoolConfig{}

type JackPotUnusualPoolConfig struct {
	ProbId       int32 `json:"prob_id,omitempty"`       // 奖池ID
	Weight       int32 `json:"weight,omitempty"`        // 权重
	Count        int32 `json:"count,omitempty"`         // 含7数量
	JackpotRatio int32 `json:"jackpot_ratio,omitempty"` // 瓜分奖池比例
}

var JackPotUnusualPoolConfigArray []*JackPotUnusualPoolConfig
var JackPotUnusualPoolConfigs = map[int32][]*JackPotUnusualPoolConfig{}

type JackPotVipConfig struct {
	VipLevel            int32                        `json:"vip_level,omitempty"`              // Vip等级
	OrdinaryPrizePoolId int32                        `json:"ordinary_prize_pool_id,omitempty"` // 普通奖池ID
	UnusualPrizePoolId  int32                        `json:"unusual_prize_pool_id,omitempty"`  // 特殊奖池ID
	BonusDrawsId        int32                        `json:"bonus_draws_id,omitempty"`         // 奖励机制ID
	OrdinaryPrizePool   []*JackPotOrdinaryPoolConfig `json:"ordinary_prize_pool,omitempty"`    // 普通奖池
	UnusualPrizePool    []*JackPotUnusualPoolConfig  `json:"unusual_prize_pool,omitempty"`     // 特殊奖池
	BonusDraws          []*JackPotBonusDrawsConfig   `json:"bonus_draws,omitempty"`            // 奖励机制
}

var JackPotVipConfigArray []*JackPotVipConfig
var JackPotVipConfigs map[int32]*JackPotVipConfig

var SevenPools map[string][]int64 // 21-0:111-0   21-1:111-0   21-0:111-1   21-1:111-1

func init() {

	addBindDataInitFunc(
		103,
		"bonus_draws_config.json",
		&JackPotBonusDrawsConfigArray,
		nil,
		nil,
		func() error {
			for _, cfg := range JackPotBonusDrawsConfigArray {
				cfg.ValidBet = umoney.Yuan2IntFen(cfg.ValidBet)
				if _, ok := JackPotBonusDrawsConfigs[cfg.ProbId]; !ok {
					JackPotBonusDrawsConfigs[cfg.ProbId] = []*JackPotBonusDrawsConfig{}
				}
				JackPotBonusDrawsConfigs[cfg.ProbId] = append(JackPotBonusDrawsConfigs[cfg.ProbId], cfg)
			}
			for _, v := range JackPotBonusDrawsConfigs {
				slices.SortFunc(v, func(a, b *JackPotBonusDrawsConfig) bool {
					return a.ValidBet < b.ValidBet
				})
			}
			return nil
		},
	)
	addBindDataInitFunc(
		103,
		"ordinary_prize_pool_config.json",
		&JackPotOrdinaryPoolConfigArray,
		nil,
		nil,
		func() error {
			uslice.Forech(JackPotOrdinaryPoolConfigArray, func(cfg *JackPotOrdinaryPoolConfig) {
				cfg.BonusMinFen = umoney.Yuan2IntFen(cfg.BonusMin)
				cfg.BonusMaxFen = umoney.Yuan2IntFen(cfg.BonusMax)
				if _, ok := JackPotOrdinaryPoolConfigs[cfg.ProbId]; !ok {
					JackPotOrdinaryPoolConfigs[cfg.ProbId] = []*JackPotOrdinaryPoolConfig{}
				}
				JackPotOrdinaryPoolConfigs[cfg.ProbId] = append(JackPotOrdinaryPoolConfigs[cfg.ProbId], cfg)
			})
			for _, v := range JackPotOrdinaryPoolConfigs {
				slices.SortFunc(v, func(a, b *JackPotOrdinaryPoolConfig) bool {
					return a.BonusMinFen < b.BonusMinFen
				})
			}

			return nil
		},
	)
	addBindDataInitFunc(
		103,
		"unusual_prize_pool_config.json",
		&JackPotUnusualPoolConfigArray,
		nil,
		nil,
		func() error {
			for _, cfg := range JackPotUnusualPoolConfigArray {
				if _, ok := JackPotUnusualPoolConfigs[cfg.ProbId]; !ok {
					JackPotUnusualPoolConfigs[cfg.ProbId] = []*JackPotUnusualPoolConfig{}
				}
				JackPotUnusualPoolConfigs[cfg.ProbId] = append(JackPotUnusualPoolConfigs[cfg.ProbId], cfg)
			}
			for _, v := range JackPotUnusualPoolConfigs {
				slices.SortFunc(v, func(a, b *JackPotUnusualPoolConfig) bool {
					return a.Count < b.Count
				})
			}

			return nil
		},
	)
	addBindDataInitFunc(
		104,
		"vip_config.json",
		&JackPotVipConfigArray,
		&JackPotVipConfigs,
		func(i int) interface{} { return JackPotVipConfigArray[i].VipLevel },
		func() error {
			uslice.Forech(JackPotVipConfigArray, func(cfg *JackPotVipConfig) {
				cfg.OrdinaryPrizePool = JackPotOrdinaryPoolConfigs[cfg.OrdinaryPrizePoolId]
				cfg.UnusualPrizePool = JackPotUnusualPoolConfigs[cfg.UnusualPrizePoolId]
				cfg.BonusDraws = JackPotBonusDrawsConfigs[cfg.BonusDrawsId]
			})

			SevenPools = make(map[string][]int64)

			for _, config := range JackPotVipConfigArray {
				for o := 0; o < len(config.OrdinaryPrizePool); o++ {
					for u := 0; u < len(config.UnusualPrizePool); u++ {
						if config.UnusualPrizePool[u].Count == 0 {
							continue
						}
						name := fmt.Sprintf("%v-%v:%v-%v", config.OrdinaryPrizePoolId, o, config.UnusualPrizePoolId, u)
						if _, ok := SevenPools[name]; !ok {
							SevenPools[name] = []int64{}
							for i := config.OrdinaryPrizePool[o].BonusMin; i < config.OrdinaryPrizePool[o].BonusMax; i++ {
								iString := fmt.Sprintf("%v", i)
								if strings.Count(iString, "7") == int(config.UnusualPrizePool[u].Count) {
									SevenPools[name] = append(SevenPools[name], i)
								}
							}
						}
					}
				}
			}
			return nil
		},
	)
}
