package cfg_google_iap

import (
	"server/internals/configs/cfg"
	"server/internals/logger"
	"server/internals/utils/ufile"
	"time"

	"gopkg.in/yaml.v3"
)

type GoogleIAPConfig struct {
	Mode       string           `json:"mode" yaml:"mode"`
	AllowPprof bool             `json:"allow_pprof" yaml:"allow_pprof"`
	Bind       string           `json:"bind" yaml:"bind"`
	CoreDB     *cfg.DatabaseCfg `json:"core_db" yaml:"core_db"`
}

var GoogleIAP = &GoogleIAPConfig{
	Bind: "0.0.0.0:6699",
}

func (cfg *GoogleIAPConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load GoogleIAPConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse GoogleIAPConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		// init
		break
	}
}
