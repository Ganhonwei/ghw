package cfg_gm

import (
	"time"

	"server/internals/configs/cfg"
	"server/internals/logger"
	"server/internals/utils/ufile"
	"server/internals/utils/utypes"

	"gopkg.in/yaml.v3"
)

type GmConfig struct {
	Mode           string              `json:"mode" yaml:"mode"`
	AllowPprof     bool                `json:"allow_pprof" yaml:"allow_pprof"`
	GmBind         string              `json:"gm_bind" yaml:"gm_bind"`
	ConfDir        string              `json:"conf_dir" yaml:"conf_dir"`
	UploadDir      string              `json:"upload_dir" yaml:"upload_dir"`
	CoreDB         *cfg.DatabaseCfg    `json:"core_db" yaml:"core_db"`
	RequestDB      *cfg.DatabaseCfg    `json:"request_db" yaml:"request_db"`
	GmJwtKey       string              `json:"gm_jwt_key" yaml:"gm_jwt_key"`
	RedisUrl       string              `json:"redis_url" yaml:"redis_url"`
	RedisPrefix    string              `json:"redis_prefix" yaml:"redis_prefix"`
	DisableTotp    bool                `json:"disable_totp" yaml:"disable_totp"`
	CountryCode    string              `json:"country_code" yaml:"country_code"` // 2字节编码
	GmLangCode     string              `json:"gm_lang_code" yaml:"gm_lang_code"` // 2字节 https://zh.wikipedia.org/wiki/ISO_639-1%E4%BB%A3%E7%A0%81%E8%A1%A8
	SupportedLangs []string            `json:"supported_langs" yaml:"supported_langs"`
	DefaultLang    string              `json:"default_lang" yaml:"default_lang"`
	ThirdPrefix    string              `json:"third_prefix" yaml:"third_prefix"`
	PearPay        *cfg.PearPayConfig  `json:"pearpay" yaml:"pearpay"`
	TenaPay        *cfg.TenaPayConfig  `json:"tenapay" yaml:"tenapay"`
	HkPay          *cfg.HkPayConfig    `json:"hkpay" yaml:"hkpay"`
	AdJust         []*cfg.AdJustConfig `json:"ad_just" yaml:"ad_just"`

	GmJwtKeyBytes []byte `json:"-" yaml:"-"`
}

var Gm = &GmConfig{
	GmBind: "0.0.0.0:6699",
}

func (cfg *GmConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		cfg.GmJwtKeyBytes = utypes.StringToBytes(cfg.GmJwtKey)
		break
	}
}
