package cfg

type DatabaseCfg struct {
	Dsn         string `json:"dsn" yaml:"dsn"`
	DsnRead     string `json:"dsn_read" yaml:"dsn_read"`
	PoolMaxIdle int    `json:"pool_max_idle" yaml:"pool_max_idle"`
	PoolMaxOpen int    `json:"pool_max_open" yaml:"pool_max_open"`
	UseLogger   bool   `json:"use_logger" yaml:"use_logger"`
	Debugging   bool   `json:"debugging" yaml:"debugging"`
}

type GoogleApi struct {
	Pkg string `json:"pkg" yaml:"pkg"`
	Api string `json:"api" yaml:"api"`
}

type PearPayConfig struct {
	Enabled       bool   `json:"enabled" yaml:"enabled"`
	MchId         int    `json:"mch_id" yaml:"mch_id"`
	PartnerKey    string `json:"partner_key" yaml:"partner_key"`
	Token         string `json:"token" yaml:"token"`
	AesKey        string `json:"aes_key" yaml:"aes_key"`
	PayAppId      int    `json:"pay_app_id" yaml:"pay_app_id"`
	RechargeAppId int    `json:"recharge_app_id" yaml:"recharge_app_id"`
	BaseUrl       string `json:"base_url" yaml:"base_url"`
	RedirectUrl   string `json:"redirect_url" yaml:"redirect_url"`
}

type TenaPayConfig struct {
	Enabled     bool   `json:"enabled" yaml:"enabled"`
	MchId       string `json:"mch_id" yaml:"mch_id"`
	ProductId   int    `json:"product_id" yaml:"product_id"`
	Key         string `json:"key" yaml:"key"`
	BaseUrl     string `json:"base_url" yaml:"base_url"`
	CallbackUrl string `json:"callback_url" yaml:"callback_url"`
}

type HkPayConfig struct {
	Enabled     bool   `json:"enabled" yaml:"enabled"`
	MchId       string `json:"mch_id" yaml:"mch_id"`
	Md5Key      string `json:"md5_key" yaml:"md5_key"`
	ShaKey      string `json:"sha_key" yaml:"sha_key"`
	BaseUrl     string `json:"base_url" yaml:"base_url"`
	CallbackUrl string `json:"callback_url" yaml:"callback_url"`
}

type AppsflyerConfig struct {
	Pkg    string `json:"pkg" yaml:"pkg"`
	ApiUrl string `json:"api_url" yaml:"api_url"`
	ApiKey string `json:"api_key" yaml:"api_key"`
}

type AdJustConfig struct {
	Pkg            string `json:"pkg" yaml:"pkg"`
	AdLogin        string `json:"ad_login" yaml:"ad_login"`
	AdRegister     string `json:"ad_register" yaml:"ad_register"`
	AdFirstDeposit string `json:"ad_first_deposit" yaml:"ad_first_deposit"`
	AdDeposit      string `json:"ad_deposit" yaml:"ad_deposit"`
	AdReDeposit    string `json:"ad_re_deposit" yaml:"ad_re_deposit"`
	AddWithdraw    string `json:"ad_withdraw" yaml:"ad_withdraw"`
}

type Email struct {
	Sender             string `json:"sender" yaml:"sender"`
	Region             string `json:"region" yaml:"region"`
	AwsAccessKeyID     string `json:"aws_access_key_id" yaml:"aws_access_key_id"`
	AwsSecretAccessKey string `json:"aws_secret_access_key" yaml:"aws_secret_access_key"`
	ConfigSetName      string `json:"config_set" yaml:"config_set"`
	TagName            string `json:"tag_name" yaml:"tag_name"`
}
