package g

import (
	"time"
)

const (
	PlatformWebJwtAliveSec          = 60 * 60 * 24 * 30 // Web Jwt 有效时间秒、
	PlatformGameJwtAliveSec         = 60 * 60 * 24 * 30 // Game Jwt 有效时间秒、
	PlatformCacheAuthInfoSec        = 15 * 60           // AuthInfo 缓存时间
	PlatformContentCacheLevelLong   = 72 * time.Hour    // 需要长时间缓存的内容 72小时
	PlatformContentCacheLevelAes    = 24 * time.Hour    // 需要长时间缓存的内容 24小时
	PlatformContentCacheLevelHigh   = 15 * time.Minute  // 需要长时间缓存的内容 15分钟
	PlatformContentCacheLevelNormal = 5 * time.Minute   // 缓存中等时间 5分钟
	PlatformContentCacheLevelLow    = 3 * time.Second   // 缓存很少的时间  3s
	Hour24Sec                       = 24 * 3600         // 24小时秒
	YzmTime                         = 300               // 验证码有效时间(秒)

	MessageMaxCount = 50 //繁荣消息数量

	GamePageSize = 40 //每页游戏数

	BotAccountIdEnd         = 10000
	NormalAccountIdBegin    = 10000000
	NormalAccountCountBegin = 20000

	MainLoopCostTimeLimitHotMs = 20 * time.Millisecond
	MainLoopFrameTimeMs        = 50 * time.Millisecond // 帧时间，必须大等于 HotMs
	MainLoopBatchExecuteSize   = 1000                  // 每帧执行Cmd数量

	RateDivisor = int64(10000) //比例除数

	CSReadTimeout          = 30 * time.Second
	CSReadTimeout_NoBattle = 5 * time.Second
	SSReadTimeout          = 15 * time.Second

	CtxRequestId     = "RequestIdKey"
	CtxMainApk       = "X-MAINAPK"     // 维护APK
	CtxChanKey       = "X-CHANNEL"     // 渠道号
	CtxPkgKey        = "X-PKGNAME"     // 包名
	CtxSessionKey    = "X-KEY"         // 客户端单次上线的唯一标识
	CtxSessionKeyNew = "X-REQUEST-ID"  // （新）客户端单次上线的唯一标识
	CtxLangKey       = "LangKey"       // RequestCtx上下文 Langauge 的key
	CtxAuthInfoKey   = "AuthInfoKey"   // RequestCtx上下文 AuthInfo 的key
	CtxAuthPlayerKey = "AuthPlayerKey" // Request上下文中player的key
	JwtSubjectWeb    = "web"           // web域
	JwtSubjectGame   = "game"          // 自我进入游戏
	JwtSubjectGmWeb  = "gm_web"
	OnlineUserKey    = "online_user"     //在线用户redis key前缀
	OnlineVipUserKey = "online_vip_user" //在线VIP用户redis key前缀
	MgAccessToken    = "mg_access_token" //MG AccessToken前缀
	MgAccessTokenExp = 3000              //MG AccessToken 有效期

	SmsCodeKeepAlive = 5 * time.Minute //验证码有效时间

	GameHtmlKeepAlive = 7 * 24 * time.Hour //PG进入游戏HTML有效时间

	AccountCompanyInfoCacheTime = 15 * time.Minute

	ForeverTime = 1704038400 //此时间2024-01-01 00:00:00之前 (秒)，代表永久

	// GameBackHomeUrl   = "https://callnative-name-exit"        // 返回大厅
	// GameOpenCasherUrl = "https://callnative-name-open_casher" // 打开 充值页面
	GameBackHomeUrl   = "https://cp.tigerjp88.com/exit-pp.html"     // 返回大厅
	GameOpenCasherUrl = "https://cp.tigerjp88.com/open-casher.html" // 打开 充值页面

	RegisterMobile   = "mobile"   // 手机注册
	RegisterFacebook = "facebook" // 脸书注册
	RegisterVisitor  = "visitor"  // 游客注册
	RegisterAccount  = "account"  // 账号注册
	RegisterEmail    = "email"    // 邮箱注册

	DomainVpnVersion = "domain_vpn_version" //域名桥连的全局版本号

	// 支付方式
	PAY_WAY_GOOGLE    = "GOOGLE"    // Google
	PAY_WAY_OVO       = "OVO"       // OVO
	PAY_WAY_DANA      = "DANA"      // DANA
	PAY_WAY_LINKAJA   = "LINKAJA"   // LINKAJA
	PAY_WAY_GOPAY     = "GOPAY"     // GOPAY
	PAY_WAY_DOKU      = "DOKU"      // DOKU
	PAY_WAY_SHOPEEPAY = "SHOPEEPAY" // SHOPEEPAY
	PAY_WAY_BANK      = "BANK"      // BANK //银行支付，前端需要选择银行
	PAY_WAY_OTC       = "OTC"       // OTC //银行支付，前端需要选择银行
	PAY_WAY_QRIS      = "QRIS"      // QRIS

)

const (
	StatKeyAccountAmountToOnceGame = "stat_account_amount_to_once_game" // 根据流水合并游戏记录 的进度点
)
