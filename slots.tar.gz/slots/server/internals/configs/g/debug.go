package g

var (
	DumpLogicCacheLog = false
)
