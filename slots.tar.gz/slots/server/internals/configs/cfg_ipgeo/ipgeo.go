package cfg_ipgeo

import (
	"server/internals/logger"
	"server/internals/utils/ufile"
	"time"

	"gopkg.in/yaml.v3"
)

type IPGeoConfig struct {
	Mode       string `json:"mode" yaml:"mode"`
	AllowPprof bool   `json:"allow_pprof" yaml:"allow_pprof"`
	Bind       string `json:"bind" yaml:"bind"`
	DataDir    string `json:"data_dir" yaml:"data_dir"`
}

var IPGeo = &IPGeoConfig{
	Bind: "0.0.0.0:6697",
}

func (cfg *IPGeoConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load IPGeoConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		break
	}
}
