package cfg_proxy

import (
	"server/internals/logger"
	"server/internals/utils/ufile"
	"time"

	"gopkg.in/yaml.v3"
)

type ProxyConfig struct {
	Mode       string `json:"mode" yaml:"mode"`
	AllowPprof bool   `json:"allow_pprof" yaml:"allow_pprof"`
	ProxyBind  string `json:"proxy_bind" yaml:"proxy_bind"`
	ClientBind string `json:"client_bind" yaml:"client_bind"`
	ApiKey     string `json:"api_key" yaml:"api_key"`
}

var Proxy = &ProxyConfig{
	ClientBind: "0.0.0.0:60110",
	ProxyBind:  "0.0.0.0:60120",
}

func (cfg *ProxyConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load ProxyConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse ProxyConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}
		break
	}
}
