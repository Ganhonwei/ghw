package cfg_imgcache

import (
	"server/internals/logger"
	"server/internals/utils/ufile"
	"time"

	"gopkg.in/yaml.v3"
)

type ImgCacheConfig struct {
	Mode       string `json:"mode" yaml:"mode"`
	AllowPprof bool   `json:"allow_pprof" yaml:"allow_pprof"`
	Bind       string `json:"bind" yaml:"bind"`
	DataPath   string `json:"data_path" yaml:"data_path"`
	CacheDir   string `json:"cache_dir" yaml:"cache_dir"`
}

var Config = &ImgCacheConfig{
	Bind: "0.0.0.0:6697",
}

func (cfg *ImgCacheConfig) LoadConfig(url string) {
	for {
		data, err := ufile.LoadFileData(url)
		if err != nil {
			logger.Warnln("Load IPGeoConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		err = yaml.Unmarshal(data, cfg)
		if err != nil {
			logger.Warnln("Parse PlatConfig Failed: ", err)
			logger.Infoln("Sleep 5 seconds, retry.")
			time.Sleep(5 * time.Second)
			continue
		}

		break
	}
}
