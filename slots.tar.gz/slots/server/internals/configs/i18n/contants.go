package i18n

const (
	Recharge                = "充值"              // 充值
	RechargeA               = "A面充值"            // A面充值
	RechargeRepair          = "充值补单"            // 充值补单
	RechargeSubTitle        = "实充%s,手续费%s,到账%s" // 充值副标题
	Withdraw                = "提现"              // 提现
	WithdrawRefund          = "提现(退回)"          // 提现(退回)
	Favorable               = "优惠"              // 优惠
	FavorableBindMobile     = "绑定手机赠送"          // 绑定手机赠送
	FavorableLv             = "Lv%d"            // 升级奖金
	FavorableVippool        = "彩金池奖金"           // 彩金池奖金
	FavorableNo1            = "7号派红奖金"          // 7号派红奖金
	FavorableNo10           = "17号派红奖金"         // 17号派红奖金
	FavorableNo20           = "27号派红奖金"         // 27号派红奖金
	FavorableShouChong      = "首充活动"            // 首充活动
	FavorableFanShui        = "返水活动"            // 返水活动
	FavorableTeDingChongZhi = "特定充值活动"          // 特定充值活动
	FavorableShouCiChongZhi = "SCCZHD"          // 首次充值活动
	FavorableGengXinBuChang = "版本更新补偿"          // 版本更新补偿
	FavorableQianDao        = "签到"              // 签到
	FavorableChongZhiLiBao  = "充值礼包-%v"         // 充值礼包-礼包1
	FavorableHongBaoYu      = "红包雨"             // 红包雨-2024.03.18 13:00
	FavorableEmail          = "YJJL"            //邮件奖励
	FavorableCheckIn        = "七日签到"            // 七日签到
	FavorableJinBiaoSai     = "锦标赛"             // 锦标赛
	FavorableJackPot        = "JackPot"         // JackPot
	FavorableJackPotTen     = "JackPot十连"       // JackPotTen
	FavorableFanLiBet       = "打码返利"            // 打码返利
	FavorableFanLiLoss      = "KSFL"            // 亏损返利
	FavorablePoChanLiBao    = "破产礼包"            // 破产礼包
	FavorablePoChanLiBao2   = "破产礼包2"           // 破产礼包2
	FavorableJinKu          = "金库"              // 金库
	FavorableFavCode        = "奖励码"             // 奖励码-兑换编码
	FavorableFixedRecharge  = "固定充值"            // 固定充值
	FavorableLianXuChongZhi = "连续充值活动"          // 连续充值
	FavorableGiftCenter     = "JLZX-%v"         // 奖励中心
	FavorableLucky          = "幸运翻牌"            // 幸运翻牌
	FavorableMeiRiChouJiang = "每日抽奖"            // 每日抽奖
	FavorableWelfaresTask   = "福利中心-%v"         // 福利中心任务
	FavorableTuiguangReward = "推广奖励"            // 推广奖励
	FavorableBindEmail      = "绑定邮箱赠送"          // 绑定邮箱赠送
	FavorableCoupon         = "优惠券"             // 优惠券
	FavorableLeijiChongZhi  = "累计充值活动"          // 累计充值
	FavorableRank           = "排行榜活动-%v"        // 排行榜活动
	FavorableDingyue        = "订阅活动-%v"         // 订阅
	FavorableAgent          = "推广提取"            // 推广提取钱包

	BalanceCheck    = "余额核算"      // 余额核算
	WalletAdd       = "钱包加款"      // 钱包加款
	WalletAddFav    = "钱包加款-活动%v" // 钱包加款-活动ID
	WalletSub       = "钱包扣款"      // 钱包扣款
	WalletSubRefund = "钱包扣款(退回)"  // 钱包扣款(退回)
	GameRecharge    = "游戏内充值"     // 游戏内充值
	GameWithdraw    = "游戏内提现"     // 游戏内提现

	TransferOut          = "转出"    // 转出
	TransferBankDepost   = "保险柜存款" // 保险柜存款
	TransferIn           = "转入"    // 转入
	TransferBankWithdraw = "保险柜取款" // 保险柜取款
	GoldDeposit          = "金库存款"  // 金库存款
	GoldWithdraw         = "金库提款"  // 金库提款
	GoldDepositFav       = "金库利息"  // 金库利息

	VipFanshui = "vip返水" //vip返水

	MonthCheckIn      = "YQD"     //月签到
	MonthCheckInQuick = "YQDYJQD" //月签到

	VipQuanyiHighGift = "Vip权益-%v级高级礼包"

	DingyueBuy         = "购买订阅"
	DingyueBuySubTitle = "购买订阅id:%v,花费:%v"

	PddWithdraw    = "拼多多提现"
	AgentTurntable = "代理转盘提现"
)
