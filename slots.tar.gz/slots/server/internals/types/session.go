package types

type ISession interface {
	SessionID() int64
	OwnerID() int64
	// Init()
	Kick()
	Update() (rtv bool)
}

// type ISessionMgr[ST any] interface {
// 	Alloc(sessionId int64, ownerId int64, conn *fastws.Conn)
// 	Free(ST)
// }

type IServerSession interface {
	ServerID() int64
	SessionID() int64
}
