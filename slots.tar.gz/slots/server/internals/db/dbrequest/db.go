package dbrequest

import (
	"context"
	"fmt"
	"time"

	"server/ent/request_db"
	"server/ent/request_db/migrate"
	_ "server/ent/request_db/runtime"
	"server/internals/configs/cfg"
	"server/internals/logger"

	"entgo.io/ent/dialect"
	"entgo.io/ent/dialect/sql"
	_ "github.com/go-sql-driver/mysql"
)

var Cli *request_db.Client
var CliRd *request_db.Client

func Open(conf *cfg.DatabaseCfg) {
	openImpl(conf.Dsn, conf.DsnRead, conf.Debugging, conf.UseLogger, conf.PoolMaxIdle, conf.PoolMaxOpen)
}

func openImpl(dsn string, dsnRead string, debug, useLogger bool, maxIdle, maxOpen int) {
	Cli = dbOpen(dsn, debug, useLogger, maxIdle, maxOpen)
	if len(dsnRead) != 0 { //plat可能不使用只读链接
		CliRd = dbOpen(dsnRead, debug, useLogger, maxIdle, maxOpen)
	}
}

func dbOpen(dsn string, debug, useLogger bool, maxIdle, maxOpen int) *request_db.Client {
	for {
		logger.Infof("Connectting RequestDB...")

		drv, err := sql.Open(dialect.MySQL, dsn)
		if err != nil {
			logger.Errorf("Connect to RequestDB failed: %+v\n", err)
			logger.Infoln("Sleep 5s retry connect to RequestDB...")
			<-time.After(5 * time.Second)
			continue
		}

		// Get the underlying sql.DB object of the driver.
		db := drv.DB()
		db.SetMaxIdleConns(maxIdle)
		db.SetMaxOpenConns(maxOpen)
		db.SetConnMaxLifetime(time.Hour)

		logger.Infof("Connecting RequestDB: MaxIdle: %v, MaxOpen: %v", maxIdle, maxOpen)

		opts := []request_db.Option{request_db.Driver(drv)}
		if debug {
			opts = append(opts, request_db.Debug())
		}
		if useLogger {
			opts = append(opts, request_db.Log(logger.Debugln))
		}

		return request_db.NewClient(opts...)
	}
}

func Close() {
	if Cli != nil {
		Cli.Close()
	}
	if CliRd != nil {
		CliRd.Close()
	}
}

func MigrateDB() error {
	if Cli == nil {
		return fmt.Errorf("No Database Instance")
	}

	return Cli.Schema.Create(context.Background(),
		// schema.WithAtlas(true),
		migrate.WithDropColumn(true),
		// migrate.WithFixture(true),
		migrate.WithDropIndex(true))
}
