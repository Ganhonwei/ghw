package dbrequest

import (
	"context"
	"runtime/debug"

	"server/ent/request_db"
	"server/internals/logger"
	"github.com/pkg/errors"
)

func WithTx(ctx context.Context, fn func(ctx context.Context, tx *request_db.Tx) error) error {
	return withTx(ctx, Cli, fn, false)
}

func WithTxDebug(ctx context.Context, fn func(ctx context.Context, tx *request_db.Tx) error) error {
	return withTx(ctx, Cli, fn, true)
}

func withTx(ctx context.Context, client *request_db.Client, fn func(ctx context.Context, tx *request_db.Tx) error, isDebug bool) error {

	c := client
	if isDebug {
		c = c.Debug()
	}

	tx, err := c.Tx(ctx)
	if err != nil {
		return err
	}
	defer func() {
		if v := recover(); v != nil {
			tx.Rollback()
			debug.PrintStack()
			logger.Errorf("RequestDB.WithTx: %v\n", v)
		}
	}()
	if err := fn(ctx, tx); err != nil {
		if rerr := tx.Rollback(); rerr != nil {
			err = errors.Wrapf(err, "rolling back transaction: %v", rerr)
		}
		return err
	}
	if err := tx.Commit(); err != nil {
		return errors.Wrapf(err, "committing transaction: %v", err)
	}
	return nil
}
