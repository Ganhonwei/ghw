package dbcore

import (
	"context"
	"fmt"
	"time"

	"server/ent/core_db"
	"server/ent/core_db/migrate"
	_ "server/ent/core_db/runtime"
	"server/internals/configs/cfg"
	"server/internals/logger"

	"entgo.io/ent/dialect"
	"entgo.io/ent/dialect/sql"
	_ "github.com/go-sql-driver/mysql"
)

var Cli *core_db.Client
var CliRd *core_db.Client

func Open(conf *cfg.DatabaseCfg) {
	openImpl(conf.Dsn, conf.DsnRead, conf.Debugging, conf.UseLogger, conf.PoolMaxIdle, conf.PoolMaxOpen)
}

func openImpl(dsn string, dsnRead string, debug, useLogger bool, maxIdle, maxOpen int) {
	Cli = dbOpen(dsn, debug, useLogger, maxIdle, maxOpen)
	if len(dsnRead) != 0 { //plat可能不使用只读链接
		CliRd = dbOpen(dsnRead, debug, useLogger, maxIdle, maxOpen)
	}
}

func dbOpen(dsn string, debug, useLogger bool, maxIdle, maxOpen int) *core_db.Client {
	for {
		logger.Infof("Connectting Database...")

		drv, err := sql.Open(dialect.MySQL, dsn)
		if err != nil {
			logger.Errorf("Connect to database failed: %+v\n", err)
			logger.Infoln("Sleep 5s retry connect to database...")
			<-time.After(5 * time.Second)
			continue
		}

		// Get the underlying sql.DB object of the driver.
		db := drv.DB()
		db.SetMaxIdleConns(maxIdle)
		db.SetMaxOpenConns(maxOpen)
		db.SetConnMaxLifetime(time.Hour)

		logger.Infof("Connecting Database: MaxIdle: %v, MaxOpen: %v", maxIdle, maxOpen)

		opts := []core_db.Option{core_db.Driver(drv)}
		if debug {
			opts = append(opts, core_db.Debug())
		}
		if useLogger {
			opts = append(opts, core_db.Log(logger.Debugln))
		}

		return core_db.NewClient(opts...)
	}
}

func Close() {
	if Cli != nil {
		Cli.Close()
	}
	if CliRd != nil {
		CliRd.Close()
	}
}

func MigrateDB() error {
	if Cli == nil {
		return fmt.Errorf("No Database Instance")
	}

	return Cli.Schema.Create(context.Background(),
		// schema.WithAtlas(true),
		migrate.WithDropColumn(true),
		// migrate.WithFixture(true),
		migrate.WithDropIndex(true))
}
