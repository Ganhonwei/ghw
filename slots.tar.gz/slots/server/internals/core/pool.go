package core

import "sync"

type Reseter interface {
	Reset()
}

type ObjectPool[T Reseter] struct {
	pool sync.Pool
}

func NewObjectPool[T Reseter](creator func() T) *ObjectPool[T] {
	return &ObjectPool[T]{
		pool: sync.Pool{
			New: func() any { return creator() },
		},
	}
}

func (p *ObjectPool[T]) Alloc() T {
	return p.pool.Get().(T)
}

func (p *ObjectPool[T]) Free(obj T) {
	obj.Reset()
	p.pool.Put(obj)
}
