package container

// Visitor is a function use to visit a data structure
type Visitor[T any] func(value T) bool

// KvVisitor is a function use to visit a key-value type data structure
type KvVisitor[KT any, VT any] func(key KT, value VT) bool
