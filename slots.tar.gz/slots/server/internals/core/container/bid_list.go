package container

import "fmt"

// BidListNode is a bid_list node
type BidListNode[T any] struct {
	prev  *BidListNode[T]
	next  *BidListNode[T]
	list  *BidList[T]
	Value T
}

// Next returns the next list node or nil.
func (n *BidListNode[T]) Next() *BidListNode[T] {
	if n.list == nil {
		return nil
	}
	if n.next == n.list.head {
		return nil
	}
	return n.next
}

// Prev returns the previous list node or nil.
func (n *BidListNode[T]) Prev() *BidListNode[T] {
	if n.list == nil {
		return nil
	}
	if n == n.list.head {
		return nil
	}
	return n.prev
}

// List represents a bidirectional list:
//
//   head -> node1 -- node2 --  node3
//            |                   |
//           node6 -- node5 --  node4
//
type BidList[T any] struct {
	head *BidListNode[T] // point to the front Node
	len  int             // current list length
}

// New creates a list
func NewBidList[T any]() *BidList[T] {
	list := &BidList[T]{}
	return list
}

// Len returns the amount of list nodes.
func (l *BidList[T]) Len() int {
	return l.len
}

// Size returns the amount of list nodes.
func (l *BidList[T]) Size() int {
	return l.len
}

// Empty returns true if the list is empty
func (l *BidList[T]) Empty() bool {
	return l.len == 0
}

// FrontNode returns the front node of the list or nil if the list is empty
func (l *BidList[T]) FrontNode() *BidListNode[T] {
	return l.head
}

// BackNode returns the last node of the list or nil if the list is empty
func (l *BidList[T]) BackNode() *BidListNode[T] {
	if l.head == nil {
		return nil
	}
	return l.head.prev
}

// Front returns the value of the front node
func (l *BidList[T]) Front() T {
	if l.len == 0 {
		var dv T
		return dv
	}
	return l.head.Value
}

// Back returns the value of the last node
func (l *BidList[T]) Back() T {
	if l.len == 0 {
		var dv T
		return dv
	}
	return l.head.prev.Value
}

// PushBack inserts a new node n with value v at the back of the list
func (l *BidList[T]) PushBack(v T) {
	l.PushNodeBack(v)
}

// PushBack inserts a new node n with value v at the back of the list and returns n.
func (l *BidList[T]) PushNodeBack(v T) *BidListNode[T] {
	n := &BidListNode[T]{Value: v, list: l}
	if l.len == 0 {
		n.prev = n
		n.next = n
		l.head = n
		l.len++
		return n
	}
	return l.insertAfter(n, l.head.prev)
}

// PushFront inserts a new node n with value v at the front of the list.
func (l *BidList[T]) PushFront(v T) {
	n := l.PushNodeBack(v)
	l.head = n
}

// InsertAfter inserts a new node n with value v immediately after mark and returns n.
// If mark is not a node of l list, the list is not modified.
// The mark must not be nil.
func (l *BidList[T]) InsertAfter(v T, mark *BidListNode[T]) *BidListNode[T] {
	if mark.list != l {
		return nil
	}
	return l.insertAfter(&BidListNode[T]{Value: v, list: l}, mark)
}

// InsertBefore inserts a new node n with value v immediately before mark and returns n.
// If mark is not a node of l list, the list is not modified.
// The mark must not be nil.
func (l *BidList[T]) InsertBefore(v T, mark *BidListNode[T]) *BidListNode[T] {
	if mark.list != l {
		return nil
	}
	n := l.insertAfter(&BidListNode[T]{Value: v, list: l}, mark.prev)
	if l.head == mark {
		l.head = n
	}
	return n
}

func (l *BidList[T]) insertAfter(n, at *BidListNode[T]) *BidListNode[T] {
	n.next = at.next
	n.prev = at
	at.next.prev = n
	at.next = n
	l.len++
	return n
}

// Remove removes n from l list if n is a node of l list.
// It returns the n value n.Value.
// The node must not be nil.
func (l *BidList[T]) Remove(n *BidListNode[T]) T {
	if n.list == l {
		l.remove(n)
	}
	return n.Value
}

func (l *BidList[T]) remove(n *BidListNode[T]) *BidListNode[T] {
	if n == l.head {
		l.head = l.head.next
	}
	n.prev.next = n.next
	n.next.prev = n.prev
	n.next = nil // avoid memory leaks
	n.prev = nil // avoid memory leaks
	n.list = nil
	l.len--
	if l.len == 0 {
		l.head = nil
	}
	return n
}

// Clear removes all nodes
func (l *BidList[T]) Clear() {
	l.head = nil
	l.len = 0
}

// PopBack removes the last node in the list and returns its value
func (l *BidList[T]) PopBack() T {
	n := l.BackNode()
	if n != nil {
		return l.Remove(n)
	}
	var dv T
	return dv
}

// PopFront removes the first node in the list and returns its value
func (l *BidList[T]) PopFront() T {
	n := l.FrontNode()
	if n != nil {
		return l.Remove(n)
	}
	var dv T
	return dv
}

// MoveToFront moves node n to the front of the list.
// If n is not a node of the list, the list is not modified.
// The n must not be nil.
func (l *BidList[T]) MoveToFront(n *BidListNode[T]) {
	if n.list != l {
		return
	}
	if l.head != n {
		l.moveToAfter(n, l.head.prev)
		l.head = n
	}
}

// MoveToBack moves node  n to the back of the list.
// If e is not a node of the list, the list is not modified.
// The node must not be nil.
func (l *BidList[T]) MoveToBack(n *BidListNode[T]) {
	if n.list != l {
		return
	}
	if l.head.prev != n {
		l.moveToAfter(n, l.head.prev)
	}
}

// MoveAfter moves node n to its new position after mark.
// If n or mark is not a node of the list, or n == mark, the list is not modified.
// The node and mark must not be nil.
func (l *BidList[T]) MoveAfter(n, mark *BidListNode[T]) {
	if n.list != l || n == mark || mark.list != l {
		return
	}
	l.moveToAfter(n, mark)
}

func (l *BidList[T]) moveToAfter(n, at *BidListNode[T]) {
	if n == at.next {
		return
	}
	if n == l.head {
		l.head = n.next
	}
	n.prev.next = n.next
	n.next.prev = n.prev
	n.next = at.next
	n.prev = at
	at.next.prev = n
	at.next = n
}

// PushBackList inserts a copy of an other list at the back of the list.
// The list and other may be the same. They must not be nil.
func (l *BidList[T]) PushBackList(other *BidList[T]) {
	for i, n := other.Len(), other.FrontNode(); i > 0; i, n = i-1, n.Next() {
		l.InsertAfter(n.Value, l.head.prev)
	}
}

// PushFrontList inserts a copy of an other list at the front of the list.
// The list and other may be the same. They must not be nil.
func (l *BidList[T]) PushFrontList(other *BidList[T]) {
	for i, e := other.Len(), other.BackNode(); i > 0; i, e = i-1, e.Prev() {
		l.InsertBefore(e.Value, l.head)
	}
}

// String returns a string representation of the list
func (l *BidList[T]) String() string {
	str := "["
	for n := l.FrontNode(); n != nil; n = n.Next() {
		if str != "[" {
			str += " "
		}
		str += fmt.Sprintf("%v", n.Value)
	}
	str += "]"
	return str
}

// Traversal traversals elements in the list, it will not stop until to the end of the list or the visitor returns false
func (l *BidList[T]) Traversal(visitor Visitor[T]) {
	for node := l.FrontNode(); node != nil; node = node.Next() {
		if !visitor(node.Value) {
			break
		}
	}
}

func (l *BidList[T]) TraversalNode(visitor func(*BidListNode[T]) bool) {
	for node := l.FrontNode(); node != nil; node = node.Next() {
		if !visitor(node) {
			break
		}
	}
}
