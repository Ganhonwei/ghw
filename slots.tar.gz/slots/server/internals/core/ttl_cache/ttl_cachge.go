package ttl_cache

import (
	"time"

	"github.com/puzpuzpuz/xsync"
)

// TtlCache stores arbitrary data with expiration time.
type TtlCache[V any] struct {
	items *xsync.MapOf[item[V]]
	close chan struct{}
}

// An item represents arbitrary data with expiration time.
type item[V any] struct {
	data    V
	expires int64
}

// New creates a new cache that asynchronously cleans
// expired entries after the given time passes.
func NewTtlCache[V any](cleaningInterval time.Duration) *TtlCache[V] {
	cache := &TtlCache[V]{
		items: xsync.NewMapOf[item[V]](),
		close: make(chan struct{}),
	}

	go func() {
		ticker := time.NewTicker(cleaningInterval)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				now := time.Now().UnixNano()

				cache.items.Range(func(key string, value item[V]) bool {
					if value.expires > 0 && now > value.expires {
						cache.items.Delete(key)
					}
					return true
				})

			case <-cache.close:
				return
			}
		}
	}()

	return cache
}

// Get gets the value for the given key.
func (cache *TtlCache[V]) Get(key string) (val V, loaded bool) {
	item, exists := cache.items.Load(key)

	if !exists {
		return val, false
	}

	if item.expires > 0 && time.Now().UnixNano() > item.expires {
		return val, false
	}

	return item.data, true
}

// Set sets a value for the given key with an expiration duration.
// If the duration is 0 or less, it will be stored forever.
func (cache *TtlCache[V]) Set(key string, value V, duration time.Duration) {
	var expires int64

	if duration > 0 {
		expires = time.Now().Add(duration).UnixNano()
	}

	cache.items.Store(key, item[V]{
		data:    value,
		expires: expires,
	})
}

// Range calls f sequentially for each key and value present in the cache.
// If f returns false, range stops the iteration.
func (cache *TtlCache[V]) Range(f func(key string, value V) bool) {
	now := time.Now().UnixNano()
	cache.items.Range(func(key string, item item[V]) bool {
		if item.expires > 0 && now > item.expires {
			return true
		}
		return f(key, item.data)
	})
}

// Delete deletes the key and its value from the cache.
func (cache *TtlCache[V]) Delete(key string) {
	cache.items.Delete(key)
}

// Close closes the cache and frees up resources.
func (cache *TtlCache[V]) Close() {
	cache.close <- struct{}{}
	cache.items = nil
}

func (cache *TtlCache[V]) Clean() {
	cache.items.Range(func(key string, value item[V]) bool {
		cache.items.Delete(key)
		return true
	})
}
