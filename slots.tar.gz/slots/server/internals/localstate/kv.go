package localstate

import (
	"fmt"
	"server/internals/utils/utypes"
	"sync"
	"time"

	bolt "go.etcd.io/bbolt"
)

var boltDB *bolt.DB //, err := bolt.Open(path, 0666, nil)

// var db *bitcask.Bitcask
// var wg = sync.WaitGroup{}
// var closeCh = make(chan struct{})
var lck = sync.Mutex{}

func Open(path string) {
	lck.Lock()
	defer lck.Unlock()

	db2, err := bolt.Open(path, 0666, &bolt.Options{
		Timeout: time.Second * 10, // file lock hangs
	})
	if err != nil {
		panic(fmt.Errorf("open LocalState Failed: %+v", err))
	}

	boltDB = db2
}

// func Update(f func(tx *bolt.Tx) error) error {
// 	return dbcore.Update(f)
// }

// func Batch(f func(tx *bolt.Tx) error) error {
// 	return dbcore.Batch(f)
// }

func Put(bucket, key, val string) error {
	lck.Lock()
	defer lck.Unlock()
	return boltDB.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucketIfNotExists(utypes.StringToBytes(bucket))
		if err != nil {
			return err
		}

		return b.Put(utypes.StringToBytes(key), utypes.StringToBytes(val))
	})
}

func Exists(bucket, key string) bool {
	lck.Lock()
	defer lck.Unlock()
	rtv := false
	_ = boltDB.View(func(tx *bolt.Tx) error {
		b := tx.Bucket(utypes.StringToBytes(bucket))
		if b == nil {
			return nil
		}

		rtv = b.Get(utypes.StringToBytes(key)) != nil

		return nil
	})
	return rtv
}

func Get(bucket, key string) string {
	lck.Lock()
	defer lck.Unlock()

	rtv := []byte{}

	_ = boltDB.View(func(tx *bolt.Tx) error {
		b := tx.Bucket(utypes.StringToBytes(bucket))
		if b == nil {
			return nil
		}

		data := b.Get(utypes.StringToBytes(key))
		if data != nil {
			rtv = append(rtv, data...)
		}

		return nil
	})

	return utypes.BytesToString(rtv)
}

func Close() {
	lck.Lock()
	defer lck.Unlock()

	if boltDB == nil {
		return
	}

	boltDB.Close()
	boltDB = nil
}
