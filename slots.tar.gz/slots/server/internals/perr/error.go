package perr

import (
	"fmt"
	"server/internals/generated/core/errcode"
)

type webApiCodeError struct {
	code    errcode.ErrCode
	message string
}

func (e webApiCodeError) GetCode() errcode.ErrCode {
	return e.code
}

func (e webApiCodeError) Error() string {
	return e.message
}

func GetCode(e error) (errcode.ErrCode, bool) {
	ne, ok := e.(*webApiCodeError)
	if !ok {
		return errcode.ErrCode_Failed, false
	}

	return ne.code, true
}

func IsCode(e error, ec errcode.ErrCode) bool {
	ne, ok := e.(*webApiCodeError)
	if !ok {
		return false
	}

	return ne.code == ec
}

func IsOk(e error) bool {
	return IsCode(e, errcode.ErrCode_Ok)
}

func IsWaitComplete(e error) bool {
	return IsCode(e, errcode.ErrCode_WaitComplete)
}

func IsOkOrWait(e error) bool {
	if c, ok := GetCode(e); ok {
		return c == errcode.ErrCode_WaitComplete || c == errcode.ErrCode_Ok
	}
	return false
}

func NewCodeError(code errcode.ErrCode) error {
	return &webApiCodeError{
		code:    code,
		message: code.String(),
	}
}

func NewCodeMessageError(code errcode.ErrCode, format string, arg ...any) error {
	return &webApiCodeError{
		code:    code,
		message: fmt.Sprintf(format, arg...),
	}
}

func NewFailedError(format string, arg ...any) error {
	return NewCodeMessageError(errcode.ErrCode_Failed, fmt.Sprintf(format, arg...))
}

func NewUnknownError(format string, arg ...any) error {
	return NewCodeMessageError(errcode.ErrCode_UnknownError, fmt.Sprintf(format, arg...))
}

var (
	ErrNoUser           = NewCodeMessageError(errcode.ErrCode_UserNotFound, "user not found")
	ErrDbFailed         = NewCodeMessageError(errcode.ErrCode_DBFailed, "db failed")
	ErrDebugFailed100   = NewCodeMessageError(errcode.ErrCode_DebugFailed100, "debug 100")
	ErrFailed           = NewCodeMessageError(errcode.ErrCode_Failed, "failed")
	ErrPermissionDenied = NewCodeMessageError(errcode.ErrCode_PermissionDenied, "permission denied")
)
