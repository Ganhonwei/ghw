package logger

import (
	"github.com/sirupsen/logrus"
)

var (
	loggers         = map[string]*logrus.Logger{}
	defLogger       = newLogger("def", DebugLevel)
	Sys             = newLogger("Sys", DebugLevel)
	CpTemplate      = newLogger("CP-Template", DebugLevel)
	CpRp            = newLogger("CP-RP", DebugLevel)
	CpPragmaticPlay = newLogger("CP-PragmaticPlay", DebugLevel)
	CpPgSoft        = newLogger("CP-PgSoft", DebugLevel)
	CpHabanero      = newLogger("CP-Habanero", DebugLevel)
	CpMgplus        = newLogger("CP-MGPlus", DebugLevel)
	CpJoker         = newLogger("CP-Joker", DebugLevel)
	CpBalakPlay     = newLogger("CP-BalakPlay", DebugLevel)
	CpWhiteCliff    = newLogger("CP-WhiteCliff", DebugLevel)
	CpPlaynGo       = newLogger("CP-PlaynGo", DebugLevel)
	CpNolimitCity   = newLogger("CP-NolimitCity", DebugLevel)
	CpYggdrasil     = newLogger("CP-Yggdrasil", DebugLevel)
	CpPush          = newLogger("CP-Push", DebugLevel)
	CpWcNolimitCity = newLogger("CP-Wc-NolimitCity", DebugLevel)
	CpOneapi        = newLogger("CP-Oneapi", DebugLevel)
	CpOneapiPgSoft  = newLogger("CP-Oneapi-PgSoft", DebugLevel)
	CpOneapiPlaynGo = newLogger("CP-Oneapi-PlaynGo", DebugLevel)

	CpOneapiCQ9             = newLogger("CP-Oneapi-CQ9", DebugLevel)
	CpOneapiJili            = newLogger("CP-Oneapi-Jili", DebugLevel)
	CpOneapiFaChai          = newLogger("CP-Oneapi-FaChai", DebugLevel)
	CpOneapiSpinix          = newLogger("CP-Oneapi-Spinix", DebugLevel)
	CpOneapiSpadeGaming     = newLogger("CP-Oneapi-SpadeGaming", DebugLevel)
	CpOneapiJDB             = newLogger("CP-Oneapi-JDB", DebugLevel)
	CpOneapiQMKingMidas     = newLogger("CP-Oneapi-QMKingMidas", DebugLevel)
	CpOneapiEvolutionNetent = newLogger("CP-Oneapi-EvolutionNetent", DebugLevel)
	CpOneapiEvolutionLive   = newLogger("CP-Oneapi-EvolutionLive", DebugLevel)
	CpOneapiJDBGTF          = newLogger("CP-Oneapi-JDBGTF", DebugLevel)
	CpOneapiDCRelaxGaming   = newLogger("CP-Oneapi-DCRelaxGaming", DebugLevel)
	CpOneapiALIZE           = newLogger("CP-Oneapi-ALIZE", DebugLevel)
	CpOneapiEvoplay         = newLogger("CP-Oneapi-Evoplay", DebugLevel)
	CpOneapiBNG             = newLogger("CP-Oneapi-BNG", DebugLevel)
	CpOneapiBgaming         = newLogger("CP-Oneapi-Bgaming", DebugLevel)
	CpOneapiEzugi           = newLogger("CP-Oneapi-Ezugi", DebugLevel)
	CpOneapiWinfinity       = newLogger("CP-Oneapi-Winfinity", DebugLevel)
	CpOneapiEvolutionBTG    = newLogger("CP-Oneapi-EvolutionBTG", DebugLevel)
	CpOneapiEvolutionRT     = newLogger("CP-Oneapi-EvolutionRT", DebugLevel)
	CpOneapiYellowBat       = newLogger("CP-Oneapi-YellowBat", DebugLevel)
	CpOneapiSpribe          = newLogger("CP-Oneapi-Spribe", DebugLevel)
	CpOneapiILoveU          = newLogger("CP-Oneapi-ILoveU", DebugLevel)
	CpOneapiAPEnglish       = newLogger("CP-Oneapi-APEnglish", DebugLevel)
	CpOneapiYeeBet          = newLogger("CP-Oneapi-YeeBet", DebugLevel)
	CpOneapiHacksaw         = newLogger("CP-Oneapi-Hacksaw", DebugLevel)
	CpNines                 = newLogger("CP-Nines", DebugLevel)
	CpPgone                 = newLogger("CP-PGONE", DebugLevel)

	PayHkPay    = newLogger("Pay-HkPay", DebugLevel)
	PayPearPay  = newLogger("Pay-PearPay", DebugLevel)
	PayTenaPay  = newLogger("Pay-TenaPay", DebugLevel)
	PayBestPay  = newLogger("Pay-BestPay", DebugLevel)
	PayJayaPay  = newLogger("Pay-JayaPay", DebugLevel)
	GooglePay   = newLogger("Pay-GooglePay", DebugLevel)
	PayLoongPay = newLogger("Pay-LoongPay", DebugLevel)
	PayKiliPay  = newLogger("Pay-KiliPay", DebugLevel)
	PayNBPay    = newLogger("Pay-NBPay", DebugLevel)
	PayBePay    = newLogger("Pay-BePay", DebugLevel)
	PayKakaPay  = newLogger("Pay-KakaPay", DebugLevel)
	Sms         = newLogger("Sms", DebugLevel)
	SmsKmi      = newLogger("Sms-KmiCloud", DebugLevel)
	SmsOnduka   = newLogger("Sms-Onbuka", DebugLevel)
	SmsWorlds   = newLogger("Sms-Worlds", DebugLevel)
	Web         = newLogger("Web", DebugLevel)
	WebDebug    = newLogger("WebDebug", DebugLevel)
	AppsFlyer   = newLogger("AppsFlyer", DebugLevel)
	AdJust      = newLogger("AdJust", DebugLevel)
	FireBase    = newLogger("FireBase", DebugLevel)

	//按Service包名中相似的单词划分
	Account     = newLogger("Account", DebugLevel)
	Activity    = newLogger("Activity", DebugLevel)
	Content     = newLogger("Content", DebugLevel)
	Game        = newLogger("Game", DebugLevel)
	Log         = newLogger("Log", DebugLevel)
	Mail        = newLogger("Mail", DebugLevel)
	Order       = newLogger("Order", DebugLevel)
	Stat        = newLogger("Stat", DebugLevel)
	Task        = newLogger("Task", DebugLevel)
	SysWarn     = newLogger("SysWarn", DebugLevel)
	Google      = newLogger("Google", DebugLevel)
	Withdraw    = newLogger("Withdraw", DebugLevel)
	TaskFanYong = newLogger("FanYongTask", DebugLevel)
	WelfareTask = newLogger("WelfareTask", DebugLevel)

	RngService = newLogger("RngService", DebugLevel)
)

type LogLevel uint32

const (
	ErrorLevel LogLevel = iota
	WarnLevel
	InfoLevel
	DebugLevel
)

func IsValidLogLevel(ll LogLevel) bool {
	switch ll {
	case ErrorLevel, WarnLevel, InfoLevel, DebugLevel:
		return true
	}
	return false
}

func logLevelToLogrus(lv LogLevel) logrus.Level {

	switch lv {
	case ErrorLevel:
		return logrus.ErrorLevel
	case WarnLevel:
		return logrus.WarnLevel
	case InfoLevel:
		return logrus.InfoLevel
	case DebugLevel:
		return logrus.DebugLevel
	}

	return logrus.DebugLevel
}

func logrusToLogLevel(lv logrus.Level) LogLevel {

	switch lv {
	case logrus.ErrorLevel, logrus.FatalLevel, logrus.PanicLevel:
		return ErrorLevel
	case logrus.WarnLevel:
		return WarnLevel
	case logrus.InfoLevel:
		return InfoLevel
	case logrus.DebugLevel, logrus.TraceLevel:
		return DebugLevel
	}

	return DebugLevel
}

type Logger interface {
	// Printf must have the same semantics as log.Printf.
	Errorf(format string, args ...any)
	Warnf(format string, args ...any)
	Infof(format string, args ...any)
	Debugf(format string, args ...any)
	Printf(format string, args ...any)

	Error(args ...any)
	Warn(args ...any)
	Info(args ...any)
	Debug(args ...any)
	Print(args ...any)

	Errorln(args ...any)
	Warnln(args ...any)
	Infoln(args ...any)
	Debugln(args ...any)
	Println(args ...any)
}

func DefaultLogger() Logger {
	return defLogger
}

type CategoryHook struct {
	Cate string
}

func (h *CategoryHook) Levels() []logrus.Level {
	return logrus.AllLevels
}

func (h *CategoryHook) Fire(e *logrus.Entry) error {
	e.Data["cate"] = h.Cate
	return nil
}

func NewLogger(cate string) Logger {
	return newLogger(cate, DebugLevel)
}

func newLogger(cate string, lv LogLevel) Logger {
	l := logrus.New()
	l.AddHook(&CategoryHook{Cate: cate})
	l.SetFormatter(&logrus.TextFormatter{
		FullTimestamp:   true,
		TimestampFormat: "2006-01-02 15:04:05",
		PadLevelText:    true,
	})
	l.SetLevel(logLevelToLogrus(lv))
	l.SetReportCaller(true)

	if _, found := loggers[cate]; found {
		panic("newLogger, cate is dupli")
	}

	loggers[cate] = l

	return l
}

func LoggerLevels() map[string]LogLevel {

	rtv := map[string]LogLevel{}
	for k, l := range loggers {
		rtv[k] = logrusToLogLevel(l.Level)
	}

	return rtv
}

func SetLoggerLevel(key string, lv LogLevel) {

	if lv < ErrorLevel || lv > DebugLevel {
		return
	}

	l, ok := loggers[key]
	if ok {
		l.SetLevel(logLevelToLogrus(lv))
	}
}

// Print logs a message at level Info on the default compatibleLogger.
func Print(args ...interface{}) {
	defLogger.Print(args...)
}

// Println logs a message at level Info on the default compatibleLogger.
func Println(args ...interface{}) {
	defLogger.Print(args...)
}

// Printf logs a message at level Info on the default compatibleLogger.
func Printf(format string, args ...interface{}) {
	defLogger.Printf(format, args...)
}

// Debug logs a message at level Debug on the default compatibleLogger.
func Debug(args ...interface{}) {
	defLogger.Debug(args...)
}

// Debugln logs a message at level Debug on the default compatibleLogger.
func Debugln(args ...interface{}) {
	defLogger.Debug(args...)
}

// Debugf logs a message at level Debug on the default compatibleLogger.
func Debugf(format string, args ...interface{}) {
	defLogger.Debugf(format, args...)
}

// Info logs a message at level Info on the default compatibleLogger.
func Info(args ...interface{}) {
	defLogger.Info(args...)
}

// Infoln logs a message at level Info on the default compatibleLogger.
func Infoln(args ...interface{}) {
	defLogger.Info(args...)
}

// Infof logs a message at level Info on the default compatibleLogger.
func Infof(format string, args ...interface{}) {
	defLogger.Infof(format, args...)
}

// Warn logs a message at level Warn on the default compatibleLogger.
func Warn(args ...interface{}) {
	defLogger.Warn(args...)
}

// Warnln logs a message at level Warn on the default compatibleLogger.
func Warnln(args ...interface{}) {
	defLogger.Warn(args...)
}

// Warnf logs a message at level Warn on the default compatibleLogger.
func Warnf(format string, args ...interface{}) {
	defLogger.Warnf(format, args...)
}

// Error logs a message at level Error on the default compatibleLogger.
func Error(args ...interface{}) {
	defLogger.Error(args...)
}

// Errorln logs a message at level Error on the default compatibleLogger.
func Errorln(args ...interface{}) {
	defLogger.Error(args...)
}

// Errorf logs a message at level Error on the default compatibleLogger.
func Errorf(format string, args ...interface{}) {
	defLogger.Errorf(format, args...)
}
