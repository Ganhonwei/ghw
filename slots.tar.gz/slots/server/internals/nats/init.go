package mq

import (
	"context"
	"log"
	"time"

	"github.com/nats-io/nats.go"
)

type JetStreamClient struct {
	nc *nats.Conn

	js nats.JetStreamContext
}

func NewJetStream(url string) (*JetStreamClient, error) {
	options := nats.Options{
		Url: url,
		// 断线重连配置
		RetryOnFailedConnect: true,
		AllowReconnect:       true,
		MaxReconnect:         -1,
		ReconnectWait:        time.Second * 2,
		ReconnectBufSize:     10 * 1024 * 1024, // 10M
	}

	nc, err := options.Connect()

	if err != nil {
		return nil, err
	}

	js, err := nc.JetStream()

	if err != nil {
		return nil, err
	}

	return &JetStreamClient{
		nc: nc,
		js: js,
	}, nil
}

func (c *JetStreamClient) InitStream(ctx context.Context) {
	for _, ss := range initialStream {
		if len(ss) < 2 {
			log.Fatalf("initial jetstream %v config error", ss)
		}
		_, err :=
			c.js.AddStream(
				&nats.StreamConfig{
					Name:              ss[0],
					Storage:           nats.FileStorage,
					Subjects:          ss[1:],         // 要绑定的topics
					Replicas:          1,              // 消息副本数量
					MaxAge:            time.Hour * 24, // 流中任何消息的最大年龄
					MaxBytes:          -1,             // 存储的所有消息最大字节数 -1无限制
					MaxMsgs:           -1,             // 流中存储的所有消息最大消息数
					MaxMsgSize:        -1,             // 单个消息最大字节数
					MaxConsumers:      -1,             // Stream 定义的最大消费者数量
					NoAck:             false,
					Retention:         nats.LimitsPolicy, // 声明流的保留策略
					Discard:           nats.DiscardOld,   // stream消息数量达到limit处理策略
					MaxMsgsPerSubject: -1,                // stream保留每个主题最大消息数
					Duplicates:        time.Minute * 2,   // 跟踪重复消息的窗口
					AllowRollup:       false,             // 允许使用标题Nats-Rollup将流的所有内容或流中的主题替换为单个新消息
					DenyDelete:        true,              // 不允许删除消息
					DenyPurge:         true,              // 不允许清空消息
				},
			)
		if err != nil {
			log.Fatalf("initial jetstream %v config error", ss)
		}
	}
}
