package suploadfile

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"mime"
	"net/http"
	"os"
	"path"
	"server/ent/core_db"
	"server/ent/core_db/predicate"
	"server/ent/core_db/uploadfile"
	"server/internals/db/dbcore"
	"server/internals/endpoint/router_builder"
	"server/internals/generated/core/errcode"
	"server/internals/generated/webapi/gm/pbcontent"
	"server/internals/generated/webapi/pbbase"
	"server/internals/logger"
	"server/internals/perr"
	"server/internals/services/saws"
	"server/internals/utils/ucommon"
	"server/internals/utils/ufile"
	"server/internals/utils/uhash"
	"server/internals/utils/urand"
	"server/internals/utils/uslice"
	"server/internals/utils/utime"
	"strings"

	"github.com/h2non/filetype"
)

var baseUploadPath = "/home/smith/projs/server/upload_assets"

func SetDefaultUploadDir(dir string) {
	baseUploadPath = dir
}

func GetDefaultUploadDir() string {
	return baseUploadPath
}

// FileModuleNone         = 0;
// FileModuleTagIcon      = 1;  // 游戏标签图标
// FileModuleGameLogo     = 2;  // 游戏logo
// FileModuleAvatar       = 3;  // 账号头像
// FileModuleAd           = 4;  // 广告
// FileModuleRechargeIcon = 5;  // 充值渠道图标

func UploadFile(ctx *router_builder.RequestCtx) string {
	frm, err := ctx.Request.MultipartForm()
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	mc := len(frm.Value["module"])
	if mc == 0 {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_UploadModuleErr))
		ctx.Abort()
		return ""
	}
	module := frm.Value["module"][0]
	file := frm.File["file"]
	fc := len(file)
	if fc == 0 || fc > 1 {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_OnlyUploadImg))
		ctx.Abort()
		return ""
	}
	v1 := file[0]
	entity := &core_db.UploadFile{}
	entity.Module = module
	entity.Size = v1.Size
	f, err := v1.Open()
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	defer f.Close()

	//验证文件类型必须是图片
	head := make([]byte, 261)
	n, err := f.Read(head)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	if !filetype.IsImage(head[:n]) {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_NotImageFile))
		ctx.Abort()
		return ""
	}

	_, err = f.Seek(0, io.SeekStart)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	hash := uhash.AllowMD5()
	defer uhash.FreeMD5(hash)

	ff := io.TeeReader(f, hash)

	//临时文件
	tmpDir := path.Join(baseUploadPath, "upload_tmp")
	ufile.EnsureDir(tmpDir)
	tmpPath := path.Join(tmpDir, fmt.Sprintf("%v_%v", utime.UnixMs(), urand.LowerStrings(8)))
	fout, err := os.OpenFile(tmpPath, os.O_APPEND|os.O_CREATE|os.O_RDWR, os.ModePerm)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	defer fout.Close()

	//将文件保存到临时文件文件夹 及 算MD5sum
	_, err = io.Copy(fout, ff)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	// 得到 最终md5
	hashHex := hex.EncodeToString(hash.Sum(nil))
	entity.Md5 = hashHex

	// 计算最终文件路径
	newName := hashHex + path.Ext(strings.ToLower(v1.Filename))

	//正式文件
	dbDir := path.Join(module, hashHex[0:2], hashHex[2:4])
	tarDir := path.Join(baseUploadPath, dbDir)
	tarPath := path.Join(baseUploadPath, dbDir, newName)
	dbPath := path.Join(dbDir, newName)
	ufile.EnsureDir(tarDir)

	// 移动临时文件 到 最终文件路径处
	err = os.Rename(tmpPath, tarPath)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	//上传到存储桶
	err = saws.UploadFile(dbPath, baseUploadPath, dbPath)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	entity.Path = dbPath

	//保存文件记录
	err = dbcore.Cli.UploadFile.
		Create().
		SetModule(entity.Module).
		SetMd5(entity.Md5).
		SetSize(entity.Size).
		SetPath(entity.Path).
		SetClientDir(entity.ClientDir).
		OnConflictColumns(uploadfile.FieldModule, uploadfile.FieldMd5, uploadfile.FieldClientDir).
		UpdateNewValues().Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	id, err := dbcore.Cli.UploadFile.Query().
		Where(uploadfile.Module(entity.Module),
			uploadfile.Md5(entity.Md5),
			uploadfile.ClientDir(entity.ClientDir)).
		OnlyID(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	ctx.DoProtobuf(&pbcontent.UploadFileResp{
		Id:   id,
		Path: entity.Path,
	}, "")
	return entity.Path
}

// 上传带目录的图片
// FileModuleNone         = 0;
// FileModuleTagIcon      = 1;  // 游戏标签图标
// FileModuleGameLogo     = 2;  // 游戏logo
// FileModuleAvatar       = 3;  // 账号头像
// FileModuleAd           = 4;  // 广告
// FileModuleRechargeIcon = 5;  // 充值渠道图标
func UploadFileWithDir(ctx *router_builder.RequestCtx) string {
	frm, err := ctx.Request.MultipartForm()
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	mc := len(frm.Value["module"])
	if mc == 0 {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_UploadModuleErr))
		ctx.Abort()
		return ""
	}
	d := len(frm.Value["dir"])
	if d == 0 {
		ctx.DoError(errors.New("must dir"))
		ctx.Abort()
		return ""
	}
	clientDir := frm.Value["dir"][0]
	module := frm.Value["module"][0]
	file := frm.File["file"]
	fc := len(file)
	if fc == 0 || fc > 1 {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_OnlyUploadImg))
		ctx.Abort()
		return ""
	}
	v1 := file[0]
	entity := &core_db.UploadFile{}
	entity.Module = module
	entity.ClientDir = clientDir
	entity.Size = v1.Size
	f, err := v1.Open()
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	defer f.Close()

	//验证文件类型必须是图片
	head := make([]byte, 261)
	n, err := f.Read(head)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	if !filetype.IsImage(head[:n]) {
		ctx.DoError(perr.NewCodeError(errcode.ErrCode_NotImageFile))
		ctx.Abort()
		return ""
	}

	_, err = f.Seek(0, io.SeekStart)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	hash := uhash.AllowMD5()
	defer uhash.FreeMD5(hash)

	ff := io.TeeReader(f, hash)

	//临时文件
	tmpDir := path.Join(baseUploadPath, "upload_tmp")
	ufile.EnsureDir(tmpDir)
	tmpPath := path.Join(tmpDir, fmt.Sprintf("%v_%v", utime.UnixMs(), urand.LowerStrings(8)))
	fout, err := os.OpenFile(tmpPath, os.O_APPEND|os.O_CREATE|os.O_RDWR, os.ModePerm)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	defer fout.Close()

	//将文件保存到临时文件文件夹 及 算MD5sum
	_, err = io.Copy(fout, ff)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	// 得到 最终md5
	hashHex := hex.EncodeToString(hash.Sum(nil))
	entity.Md5 = hashHex

	// 计算最终文件路径
	newName := hashHex + path.Ext(strings.ToLower(v1.Filename))

	//正式文件
	dbDir := path.Join(module, hashHex[0:2], hashHex[2:4])
	tarDir := path.Join(baseUploadPath, dbDir)
	tarPath := path.Join(baseUploadPath, dbDir, newName)
	dbPath := path.Join(dbDir, newName)
	ufile.EnsureDir(tarDir)

	// 移动临时文件 到 最终文件路径处
	err = os.Rename(tmpPath, tarPath)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	//上传到存储桶
	err = saws.UploadFile(dbPath, baseUploadPath, dbPath)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	entity.Path = dbPath

	//保存文件记录
	err = dbcore.Cli.UploadFile.
		Create().
		SetModule(entity.Module).
		SetMd5(entity.Md5).
		SetSize(entity.Size).
		SetPath(entity.Path).
		SetClientDir(entity.ClientDir).
		OnConflictColumns(uploadfile.FieldModule, uploadfile.FieldMd5, entity.ClientDir).
		UpdateNewValues().Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}

	id, err := dbcore.Cli.UploadFile.Query().
		Where(uploadfile.Module(entity.Module),
			uploadfile.Md5(entity.Md5),
			uploadfile.ClientDir(entity.ClientDir)).
		FirstID(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		ctx.DoError(err)
		ctx.Abort()
		return ""
	}
	ctx.DoProtobuf(&pbcontent.UploadFileResp{
		Id:   id,
		Path: entity.Path,
	}, "")
	return entity.Path
}

// DownloadImgFile 下载图片并存储，返回文件的 ID 和路径
func DownloadImgFile(ctx context.Context, module, url string) (string, error) {
	// 1. 获取图片内容
	resp, err := http.Get(url)
	if err != nil {
		logger.Web.Errorf("failed to download image from %s: %v", url, err)
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err := fmt.Errorf("non-OK HTTP status: %s", resp.Status)
		logger.Web.Errorf("failed to download image from %s: %v", url, err)
		return "", err
	}

	if strings.HasSuffix(url, ".rng") {
		logger.Web.Errorf("test")
	}

	// 2. 计算 MD5 并同时读取内容
	hasher := uhash.AllowMD5()
	defer uhash.FreeMD5(hasher)
	content, err := io.ReadAll(io.TeeReader(resp.Body, hasher))
	if err != nil {
		logger.Web.Errorf("failed to read image content from %s: %v", url, err)
		return "", err
	}
	md5Sum := hex.EncodeToString(hasher.Sum(nil))

	// 3. 确定文件扩展名
	ct := resp.Header.Get("Content-Type")
	extensions, err := mime.ExtensionsByType(ct)
	if err != nil {
		logger.Web.Errorf("failed to read image content from %s: %v", url, err)
		return "", err
	}
	ext := ""
	if len(extensions) == 0 {
		// 根据 URL 后缀推断
		lurl := strings.ToLower(url)
		ext = path.Ext(lurl)

	} else {
		ext = extensions[0]
	}
	if ext != ".jpg" && ext != ".png" && ext != ".jpeg" {
		err := fmt.Errorf("unable to determine file extension for %s with content type %s", url, ct)
		logger.Web.Errorf(err.Error())
		return "", err
	}
	if strings.HasSuffix(ext, ".xml") {
		logger.Web.Errorf("test")
	}

	// 4. 计算存储路径
	newName := md5Sum + ext
	dbDir := path.Join(module, md5Sum[:2], md5Sum[2:4])
	tarDir := path.Join(baseUploadPath, dbDir)
	tarPath := path.Join(tarDir, newName)
	dbPath := path.Join(dbDir, newName)

	// 5. 检查文件是否已存在
	fileExists := false
	if _, err := os.Stat(tarPath); err == nil {
		fileExists = true
	} else if !errors.Is(err, os.ErrNotExist) {
		logger.Web.Errorf("error checking file existence %s: %v", tarPath, err)
		return "", err
	}

	if fileExists {
		// 文件和数据库记录都存在
		return dbPath, nil
	}

	// 7. 确保目录存在
	ufile.EnsureDir(tarDir)

	// 8. 如果文件不存在，则保存文件
	if !fileExists {
		if err := os.WriteFile(tarPath, content, 0644); err != nil {
			logger.Web.Errorf("failed to save file to %s: %v", tarPath, err)
			return "", err
		}
	}
	return dbPath, nil
}

func entGmToProtobuf(v *core_db.UploadFile) *pbcontent.UploadFileVo {
	return &pbcontent.UploadFileVo{
		Id:   v.ID,
		Path: v.Path,
		Dir:  v.ClientDir,
	}
}

func DeleteFile(ctx context.Context, id int64) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.UploadFile.
		DeleteOneID(id).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbbase.EmptyResp{}, nil
}

// @ListUploadFile only for gm-readonly
func ListUploadFile(ctx context.Context, req *pbcontent.ListUploadFilePageReq) (*pbcontent.ListUploadFilePageResp, error) {
	conds := []predicate.UploadFile{}
	conds = append(conds, uploadfile.Module(req.Module))
	if req.ClientDir != "" {
		conds = append(conds, uploadfile.ClientDir(req.ClientDir))
	}

	offset, limit := ucommon.PageToOffset2(int(req.PageNo), int(req.PageSize))
	order := core_db.Desc(uploadfile.FieldID)
	result, err := dbcore.CliRd.UploadFile.
		Query().
		Where(conds...).
		Order(order).
		Limit(limit).
		Offset(offset).
		All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbcontent.ListUploadFilePageResp{
		List: uslice.Map(result, entGmToProtobuf),
		Sum:  int64(0),
	}, nil
}

func ListImageMd5(ctx context.Context, req *pbcontent.ListImageMd5Req) (*pbcontent.ListImageMd5Resp, error) {
	reslut, err := dbcore.CliRd.UploadFile.Query().
		Where(uploadfile.Module(req.Module)).
		All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}

	resp := new(pbcontent.ListImageMd5Resp)
	for _, r := range reslut {
		resp.Md5 = append(resp.Md5, r.ClientDir+r.Md5)
	}

	return resp, nil
}

// 下注网络图片
func DownLoad(url, tempDir, newName string) error {
	tarDir := path.Join(baseUploadPath, tempDir)
	ufile.EnsureDir(tarDir)
	pic := path.Join(tarDir, newName)
	v, err := http.Get(url)
	if err != nil {
		logger.Sys.Errorf("Http get [%v] failed! %v", url, err)
		return err
	}
	defer v.Body.Close()
	content, err := ioutil.ReadAll(v.Body)
	if err != nil {
		logger.Sys.Errorf("Read http response failed! %v", err)
		return err
	}
	err = ioutil.WriteFile(pic, content, 0666)
	if err != nil {
		logger.Sys.Errorf("Save to file failed! %v", err)
		return err
	}
	return nil
}
