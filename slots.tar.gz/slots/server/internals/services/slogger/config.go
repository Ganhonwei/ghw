package slogger

import (
	"context"
	"server/ent/core_db"
	"server/ent/core_db/loggerconfig"
	"server/internals/db/dbcore"
	"server/internals/generated/event_bus/evtbase"
	"server/internals/generated/webapi/gm/pbsys"
	"server/internals/logger"
	"server/internals/perr"
	"server/internals/redisbus"
	"server/internals/utils/uslice"
)

func InitDatabaseLogLevels() {
	configs, err := dbcore.Cli.LoggerConfig.Query().All(context.Background())
	if err != nil {
		logger.Sys.Errorln(err)
		panic(err)
	}

	allLevels := logger.LoggerLevels()

	for k, lv := range allLevels {
		if !uslice.Any(configs, func(e *core_db.LoggerConfig) bool {
			return e.Key == k
		}) {
			_, err = dbcore.Cli.LoggerConfig.Create().
				SetKey(k).
				SetLogLevel(lv).
				Save(context.Background())
			if err != nil {
				logger.Sys.Errorln(err)
				if core_db.IsConstraintError(err) {
					continue
				}
				panic(err)
			}
		}
	}
}

func ReloadLogLevels() {
	configs, err := dbcore.Cli.LoggerConfig.Query().All(context.Background())
	if err != nil {
		logger.Sys.Errorf("ReloadLogLevels Failed: %#v", err)
		return
	}

	for _, cfg := range configs {
		logger.SetLoggerLevel(cfg.Key, cfg.LogLevel)
	}
}

// @GetLoggerConfigs only for gm-readonly
func GetLoggerConfigs(ctx context.Context) (*pbsys.GetLoggerConfigsResp, error) {
	configs, err := dbcore.CliRd.LoggerConfig.Query().All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}

	resp := &pbsys.GetLoggerConfigsResp{}
	for _, cfg := range configs {
		resp.Loggers = append(resp.Loggers, &pbsys.LoggerLevel{
			Key:   cfg.Key,
			Level: uint32(cfg.LogLevel),
		})
	}
	return resp, nil
}

func UpdateLoggerConfig(ctx context.Context, key string, lv uint32) error {

	if !logger.IsValidLogLevel(logger.LogLevel(lv)) {
		return perr.ErrDebugFailed100
	}

	_, err := dbcore.Cli.LoggerConfig.Update().
		Where(loggerconfig.Key(key)).
		SetLogLevel(logger.LogLevel(lv)).
		Save(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return err
	}

	return nil
}

func PublishReloadLogLevels() error {
	return redisbus.PublishTopic(redisbus.TopicReloadLoggerLevels,
		&evtbase.EmptyEvent{})
}
