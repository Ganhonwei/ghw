package sseq

import (
	"fmt"
	"server/internals/utils/utime"
)

var (
	thirdprefix = "dev"
)

func SetThirdprefix(p string) {
	thirdprefix = p
}

// 生成订单号 10位时间戳(秒)+2订单类型+4随机数
func GenOrderNo(orderType int32) string {
	t := utime.UnixSec()
	return fmt.Sprintf("%d%02d%04d", t, orderType, OrdreNoSeqGen.Next()%10000)
}

// 生成支付单号 前缀+10位时间戳(秒)+6随机数
func GenPayNo() string {
	t := utime.UnixSec()
	return fmt.Sprintf("%v%d%06d", thirdprefix, t, OrdreNoSeqGen.Next()%1000000)
}
