package sseq

import (
	"context"
	"fmt"
	"server/internals/utils/urand"
	"testing"
)

func init() {
	// dbcore.Open("root:123456789qwerty@tcp(192.168.66.99:3306)/lion?charset=utf8mb4&parseTime=True&loc=Local", "",
	// 	false, false, 100, 100)
	Init(context.Background())
}

func TestGenPayNo(t *testing.T) {

	// for i := 0; i < 10000; i++ {
	// 	logger.Debugln("GenPayNo: ", GenPayNo())
	// }

	// logger.Debugln("ok")
	users := []int64{11, 22, 33, 44, 55, 66, 77, 88, 99, 1010}
	// wins := urand.RandUserIds(users, 7)

	winCount := 7
	urand.Shuffle(users)
	wins := users
	if winCount < len(users) {
		wins = users[:winCount]
	}

	winUserCount := len(wins)
	winAmount := int64(3000)
	amted := int64(0)        //已发金额
	for i, v := range wins { //未每个中奖者随机中奖金额
		maxAmt := winAmount - int64(winUserCount*88) - amted //最大发金额=总发-总已发
		amt := int64(88)
		if maxAmt > 0 {
			amt = urand.RandRange(int64(88), maxAmt)
		}
		if i == winUserCount-1 { //最后一个中奖金额
			amt = winAmount - amted
		}
		amted += amt
		fmt.Printf("用户%v 中奖%v\n", v, amt)
	}
}
