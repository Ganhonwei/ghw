package sseq

import (
	"context"
	"fmt"
	"server/ent/core_db"
	"server/ent/core_db/seqkeeper"
	"server/internals/configs/g"
	"server/internals/db/dbcore"
	"server/internals/utils/uaff/optimus"
	"server/internals/utils/uent"
	"sync"
	"time"
)

type Gen struct {
	Key         string
	idQ         chan int64
	startPos    int64
	batch       int
	min         int64
	disabledObf bool
}

func (g *Gen) Next() int64 {
	return <-g.idQ
}

func (g *Gen) start(ctx context.Context) {
	dbcore.Cli.SeqKeeper.Create().
		SetKey(g.Key).
		SetSeq(g.startPos).
		OnConflict().
		Ignore().
		ExecX(ctx)

	go func() {
		sseq := int64(0)
		eseq := int64(0)
		for {
			e := uent.WithTx(ctx, func(ctx context.Context, tx *core_db.Tx) error {
				x, e := tx.SeqKeeper.Query().
					Where(seqkeeper.Key(g.Key)).ForUpdate().First(ctx)
				if e != nil {
					return e
				}

				sseq = x.Seq
				eseq = x.Seq + int64(g.batch)

				n, e := tx.SeqKeeper.Update().
					Where(
						seqkeeper.ID(x.ID),
						seqkeeper.Seq(sseq),
					).
					SetSeq(eseq).
					Save(ctx)
				if e != nil || n != 1 {
					return e
				}

				return nil
			})
			if e != nil {
				time.Sleep(50 * time.Millisecond)
				continue
			}

			for i := sseq; i < eseq; i++ {

				id := int64(i)
				if !g.disabledObf {
					id = int64(opt.Encode(uint64(id))) + g.min
				}

				g.idQ <- id + g.min
			}

		}
	}()
}

var (
	AccountGen = newGenerator("account", 1, g.NormalAccountIdBegin, 10, false)
	gens       = map[string]*Gen{}
	opt        = optimus.NewCalculated(87178291199, 170220101)
	initOnce   = sync.Once{}

	AccountNameSeqtGen = newGenerator("accountNameSeq", 1, g.NormalAccountCountBegin, 10, true)
	OrdreNoSeqGen      = newGenerator("orderNoSeq", 1, 1, 100, true)
)

func newGenerator(key string, start, mv int64, batch int, disabled bool) *Gen {
	if _, ok := gens[key]; ok {
		panic(fmt.Sprintf("Generator is key dupli: %s", key))
	}

	g := &Gen{
		Key:         key,
		idQ:         make(chan int64, batch-1),
		startPos:    start,
		batch:       batch,
		min:         mv,
		disabledObf: disabled,
	}
	gens[key] = g
	return g
}

func Init(ctx context.Context) {
	initOnce.Do(func() {
		for _, g := range gens {
			g.start(ctx)
		}
	})
}
