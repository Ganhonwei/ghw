package swarnconfig

import (
	"context"
	"fmt"
	"server/cmd/gm/services/sgm/srbac"
	"server/ent/core_db"
	"server/ent/core_db/predicate"
	"server/ent/core_db/sysconfig"
	"server/internals/configs/g"
	"server/internals/db/dbcore"
	"server/internals/generated/core"
	"server/internals/generated/webapi/gm/pbsys"
	"server/internals/generated/webapi/pbbase"
	"server/internals/logger"
	"server/internals/perr"
	"server/internals/utils/ucache"
	"server/internals/utils/ucommon"
	"server/internals/utils/ufile"
	"server/internals/utils/ujson"
	"server/internals/utils/uslice"
	"os"
	"reflect"
	"strconv"
	"strings"
)

type WarnConfig struct {
	//开关-用来控制每个功能·
	SwitchOnline2m         bool `json:"switch_online2m,omitempty" yaml:"switch_online2m"`                 // 开关-每2分钟在线
	SwitchOnlinelogin      bool `json:"switch_onlinelogin,omitempty" yaml:"switch_onlinelogin"`           // 开关-登录预警
	SwitchOnlineloginwarn  bool `json:"switch_onlineloginwarn,omitempty" yaml:"switch_onlineloginwarn"`   // 开关-登录报错预警
	SwitchOnlinegame       bool `json:"switch_onlinegame,omitempty" yaml:"switch_onlinegame"`             // 开关-游戏预警
	SwitchRwrechargefail   bool `json:"switch_rwrechargefail,omitempty" yaml:"switch_rwrechargefail"`     // 开关-充值失败预警
	SwitchRwrechargeway    bool `json:"switch_rwrechargeway,omitempty" yaml:"switch_rwrechargeway"`       // 开关-充值方式异常预警
	SwitchRwrechargeamount bool `json:"switch_rwrechargeamount,omitempty" yaml:"switch_rwrechargeamount"` // 开关-充值相同金额预警
	SwitchRwwithdrawfail   bool `json:"switch_rwwithdrawfail,omitempty" yaml:"switch_rwwithdrawfail"`     // 开关-提现失败预警
	SwitchRwwithdrawip     bool `json:"switch_rwwithdrawip,omitempty" yaml:"switch_rwwithdrawip"`         // 开关-提现防刷预警-IP
	SwitchRwwithdrawdevice bool `json:"switch_rwwithdrawdevice,omitempty" yaml:"switch_rwwithdrawdevice"` // 开关-提现防刷预警-设备
	SwitchRwwithdrawamount bool `json:"switch_rwwithdrawamount,omitempty" yaml:"switch_rwwithdrawamount"` // 开关-提现防刷池预警
	SwitchGamewin          bool `json:"switch_gamewin,omitempty" yaml:"switch_gamewin"`                   // 开关-输赢结余预警
	SwitchGamertp          bool `json:"switch_gamertp,omitempty" yaml:"switch_gamertp"`                   // 开关-RTP预警
	SwitchAcctip           bool `json:"switch_acctip,omitempty" yaml:"switch_acctip"`                     // 开关-IP预警
	SwitchAcctdevice       bool `json:"switch_acctdevice,omitempty" yaml:"switch_acctdevice"`             // 开关-设备预警
	SwitchBet              bool `json:"switch_bet,omitempty" yaml:"switch_bet"`                           // 开关-某个源发放筹码量预警
	SwitchBetuser          bool `json:"switch_betuser,omitempty" yaml:"switch_betuser"`                   // 开关-玩家获取筹码预警
	SwitchCpbet            bool `json:"switch_cpbet,omitempty" yaml:"switch_cpbet"`                       // 开关-厂商用户预警
	SwitchGameDomain       bool `json:"switch_gamedomain,omitempty" yaml:"switch_gamedomain"`             // 开关-游戏域名预警
	SwitchPayWay           bool `json:"switch_payway,omitempty" yaml:"switch_payway"`                     // 开关-支付方式预警
	SwitchAutoAudit        bool `json:"switch_autoaudit,omitempty" yaml:"switch_autoaudit"`               // 开关-自动提现预警
	SwitchWithdrawStatus   bool `json:"switch_withdrawstatus,omitempty" yaml:"switch_withdrawstatus"`     // 开关-提现卡单预警

	//在线
	Online2mUpWarn              int64 `json:"online_2m_up_warn,omitempty" yaml:"online_2m_up_warn"`                             //每2分钟在线较于同期同时段上涨预警值
	Online2mDownWarn            int64 `json:"online_2m_down_warn,omitempty" yaml:"online_2m_down_warn"`                         //每2分钟在线较于同期同时段下降预警值
	Online2mBeforeUpWarn        int64 `json:"online_2m_before_up_warn,omitempty" yaml:"online_2m_before_up_warn"`               //每2分钟在线较于前5分钟上涨预警值
	Online2mBeforeDownWarn      int64 `json:"online_2m_before_down_warn,omitempty" yaml:"online_2m_before_down_warn"`           //每2分钟在线较于前5分钟下降预警值
	OnlineNoLoginedPlayerMinute int64 `json:"online_no_logined_player_minute,omitempty" yaml:"online_no_logined_player_minute"` //登录预警x分钟内无登录玩家(分钟)
	OnlineLoginWarnMinute       int64 `json:"online_login_warn_minute,omitempty" yaml:"online_login_warn_minute"`               //登录报错预警x分钟内有登录报错量(分钟)
	OnlineLoginWarnCount        int64 `json:"online_login_warn_count,omitempty" yaml:"online_login_warn_count"`                 //登录报错预警x分钟内登录报错量大于预警值
	OnlineNoGameRecordMinute    int64 `json:"online_no_game_record_minute,omitempty" yaml:"online_no_game_record_minute"`       //游戏预警x分钟内没有注单信息(分钟)
	//充提
	RwRechargeNoSuccMinute int64 `json:"rw_recharge_no_succ_minute,omitempty" yaml:"rw_recharge_no_succ_minute"` // 充值失败预警X分钟内无完成订单(分钟)
	RwRechargeWayAmtUp     int64 `json:"rw_recharge_way_amt_up,omitempty" yaml:"rw_recharge_way_amt_up"`         // 充值方式异常预警较前一天金额上涨预警值
	RwRechargeWayAmtDown   int64 `json:"rw_recharge_way_amt_down,omitempty" yaml:"rw_recharge_way_amt_down"`     // 充值方式异常预警较前一天金额下降预警值
	RwRechargeWayUserUp    int64 `json:"rw_recharge_way_user_up,omitempty" yaml:"rw_recharge_way_user_up"`       // 充值方式异常预警较前一天人数上涨预警值
	RwRechargeWayUserDown  int64 `json:"rw_recharge_way_user_down,omitempty" yaml:"rw_recharge_way_user_down"`   // 充值方式异常预警较前一天人数下降预警值
	RwRechargeAmtMinute    int64 `json:"rw_recharge_amt_minute,omitempty" yaml:"rw_recharge_amt_minute"`         // 充值相同金额预警X分钟内(分钟)
	RwRechargeAmtCount     int64 `json:"rw_recharge_amt_count,omitempty" yaml:"rw_recharge_amt_count"`           // 充值相同金额预警X分钟内某个计费点充值数量预警值
	RwWithdrawNoSuccMinute int64 `json:"rw_withdraw_no_succ_minute,omitempty" yaml:"rw_withdraw_no_succ_minute"` // 提现失败预警X分钟内无完成订单(分钟)
	RwWithdrawIpMinute     int64 `json:"rw_withdraw_ip_minute,omitempty" yaml:"rw_withdraw_ip_minute"`           // 提现防刷预警x分钟内同IP提现(分钟)
	RwWithdrawIpCount      int64 `json:"rw_withdraw_ip_count,omitempty" yaml:"rw_withdraw_ip_count"`             // 提现防刷预警x分钟内同IP的ID数预警值
	RwWithdrawDeviceMinute int64 `json:"rw_withdraw_device_minute,omitempty" yaml:"rw_withdraw_device_minute"`   // 提现防刷预警x分钟内同设备提现(分钟)
	RwWithdrawDeviceCount  int64 `json:"rw_withdraw_device_count,omitempty" yaml:"rw_withdraw_device_count"`     // 提现防刷预警x分钟内同设备的ID数预警值
	RwWithdrawMinute       int64 `json:"rw_withdraw_minute,omitempty" yaml:"rw_withdraw_minute"`                 // 提现防刷池预警x分钟内(分钟)
	RwWithdrawAmount       int64 `json:"rw_withdraw_amount,omitempty" yaml:"rw_withdraw_amount"`                 // 提现防刷池预警x分钟内提现金额预警值
	//子游戏监控
	GameWinMinute int64 `json:"game_win_minute,omitempty" yaml:"game_win_minute"` // 输赢结余预警x分钟内(分钟)
	GameWinAmount int64 `json:"game_win_amount,omitempty" yaml:"game_win_amount"` // 输赢结余预警游戏结余预警值
	GameRtpMinute int64 `json:"game_rtp_minute,omitempty" yaml:"game_rtp_minute"` // RTP预警x分钟内(分钟)
	GameRtpRate   int64 `json:"game_rtp_rate,omitempty" yaml:"game_rtp_rate"`     // RTP预警RTP预警值
	//小号
	AcctIpCount     int64 `json:"acct_ip_count,omitempty" yaml:"acct_ip_count"`         // IP预警当日同IP登录账号预警值
	AcctDeviceCount int64 `json:"acct_device_count,omitempty" yaml:"acct_device_count"` // 设备预警当日同设备登录账号预警值
	//筹码生态
	BetRecharge         int64 `json:"bet_recharge,omitempty" yaml:"bet_recharge"`                     // 某个源发放筹码量预警-充值
	BetGm               int64 `json:"bet_gm,omitempty" yaml:"bet_gm"`                                 // 某个源发放筹码量预警-Gm发放
	BetSingleWallet     int64 `json:"bet_single_wallet,omitempty" yaml:"bet_single_wallet"`           // 某个源发放筹码量预警-单一钱包
	BetActBdsj          int64 `json:"bet_act_bdsj,omitempty" yaml:"bet_act_bdsj"`                     // 某个源发放筹码量预警-绑定手机
	BetActSjjj          int64 `json:"bet_act_sjjj,omitempty" yaml:"bet_act_sjjj"`                     // 某个源发放筹码量预警-升级奖金
	BetActPhjj          int64 `json:"bet_act_phjj,omitempty" yaml:"bet_act_phjj"`                     // 某个源发放筹码量预警-派红奖金
	BetActCjc           int64 `json:"bet_act_cjc,omitempty" yaml:"bet_act_cjc"`                       // 某个源发放筹码量预警-彩金池
	BetActSc            int64 `json:"bet_act_sc,omitempty" yaml:"bet_act_sc"`                         // 某个源发放筹码量预警-首充
	BetActFs            int64 `json:"bet_act_fs,omitempty" yaml:"bet_act_fs"`                         // 某个源发放筹码量预警-返水
	BetActTdcz          int64 `json:"bet_act_tdcz,omitempty" yaml:"bet_act_tdcz"`                     // 某个源发放筹码量预警-特定充值
	BetActSccz          int64 `json:"bet_act_sccz,omitempty" yaml:"bet_act_sccz"`                     // 某个源发放筹码量预警-首次充值
	BetActGxbc          int64 `json:"bet_act_gxbc,omitempty" yaml:"bet_act_gxbc"`                     // 某个源发放筹码量预警-版本更新补偿
	BetUserRecharge     int64 `json:"bet_user_recharge,omitempty" yaml:"bet_user_recharge"`           // 玩家获取筹码预警-充值
	BetUserGm           int64 `json:"bet_user_gm,omitempty" yaml:"bet_user_gm"`                       // 玩家获取筹码预警-Gm发放
	BetUserSingleWallet int64 `json:"bet_user_single_wallet,omitempty" yaml:"bet_user_single_wallet"` // 玩家获取筹码预警-单一钱包
	BetUserActBdsj      int64 `json:"bet_user_act_bdsj,omitempty" yaml:"bet_user_act_bdsj"`           // 玩家获取筹码预警-绑定手机
	BetUserActSjjj      int64 `json:"bet_user_act_sjjj,omitempty" yaml:"bet_user_act_sjjj"`           // 玩家获取筹码预警-升级奖金
	BetUserActPhjj      int64 `json:"bet_user_act_phjj,omitempty" yaml:"bet_user_act_phjj"`           // 玩家获取筹码预警-派红奖金
	BetUserActCjc       int64 `json:"bet_user_act_cjc,omitempty" yaml:"bet_user_act_cjc"`             // 玩家获取筹码预警-彩金池
	BetUserActSc        int64 `json:"bet_user_act_sc,omitempty" yaml:"bet_user_act_sc"`               // 玩家获取筹码预警-首充
	BetUserActFs        int64 `json:"bet_user_act_fs,omitempty" yaml:"bet_user_act_fs"`               // 玩家获取筹码预警-返水
	BetUserActTdcz      int64 `json:"bet_user_act_tdcz,omitempty" yaml:"bet_user_act_tdcz"`           // 玩家获取筹码预警-特定充值
	BetUserActSccz      int64 `json:"bet_user_act_sccz,omitempty" yaml:"bet_user_act_sccz"`           // 玩家获取筹码预警-首次充值
	BetUserActGxbc      int64 `json:"bet_user_act_gxbc,omitempty" yaml:"bet_user_act_gxbc"`           // 玩家获取筹码预警-版本更新补偿

	GameDomainMinute int64 `json:"game_domain_minute,omitempty" yaml:"game_domain_minute"` //游戏域名预警x分钟内(分钟)
	GameDomainCount  int64 `json:"game_domain_count,omitempty" yaml:"game_domain_count"`   //游戏域名预警累计日志

	PayWayMinute       int64 `json:"pay_way_minute,omitempty" yaml:"pay_way_minute"`                 //支付方式预警x分钟内(分钟)
	PayWayReqRate      int64 `json:"pay_way_req_rate,omitempty" yaml:"pay_way_req_rate"`             //支付方式预警-拉起失败率
	PayWayFailRate     int64 `json:"pay_way_fail_rate,omitempty" yaml:"pay_way_fail_rate"`           //支付方式预警-支付失败率
	PayWayFailDownRate int64 `json:"pay_way_fail_down_rate,omitempty" yaml:"pay_way_fail_down_rate"` //支付方式预警-上周期降幅
	PayWayAllowSec     int64 `json:"pay_way_allow_sec,omitempty" yaml:"pay_way_allow_sec"`           //支付方式预警-允许操作时间(秒钟)

	AutoAuditMinute int64 `json:"auto_audit_minute,omitempty" yaml:"auto_audit_minute"` //自动提现预警-x分钟内
	AutoAuditCount  int64 `json:"auto_audit_count,omitempty" yaml:"auto_audit_count"`   //自动提现预警-失败数

	WithdraStatusMinute        int64 `json:"withdraw_status_minute,omitempty" yaml:"withdraw_status_minute"`                 //提现卡单预警-x分钟内
	WithdraStatusFailCount     int64 `json:"withdraw_status_fail_count,omitempty" yaml:"withdraw_status_fail_count"`         //提现卡单预警-提现失败
	WithdraStatusUnauditMinute int64 `json:"withdraw_status_unaudit_minute,omitempty" yaml:"withdraw_status_unaudit_minute"` //提现卡单预警-x分钟一直处于待审核
	WithdraStatusAuditMinute   int64 `json:"withdraw_status_audit_minute,omitempty" yaml:"withdraw_status_audit_minute"`     //提现卡单预警-x分钟一直处于审核中

	WithdrawChannelBalanceThreshold int64 `json:"withdraw_channel_balance_threshold,omitempty" yaml:"withdraw_channel_balance_threshold"` //提现渠道余额预警阀值
}

func tagToKey(v reflect.StructTag) string {
	json := v.Get("json")
	json = strings.ReplaceAll(json, " ", "")
	parts := strings.Split(json, ",")
	return parts[0]
}

func ReadCfg(ctx context.Context) (*WarnConfig, error) {

	return ucache.GetOrUpdateAny(ucache.KeyWarnConfig, func() (*WarnConfig, error) {
		result, err := dbcore.Cli.WarnConfig.Query().All(ctx)
		if err != nil {
			logger.SysWarn.Errorln(err)
			return nil, err
		}

		cfgs := uslice.MakeMap(result, func(c *core_db.WarnConfig) string { return c.Key })

		list := map[string]string{}
		for _, v := range result {
			list[v.Key] = v.Val
		}

		var cfg = &WarnConfig{}

		cfgV := reflect.ValueOf(cfg).Elem()
		cfgT := cfgV.Type()
		for i := 0; i < cfgV.NumField(); i++ {
			fv := cfgV.Field(i)
			ft := cfgT.Field(i)

			key := tagToKey(ft.Tag)
			val, found := cfgs[key]
			if !found {
				if len(key) < 1 {
					continue
				}
				logger.Sys.Debugf("getWarnConfig: no found dbval: %v\n", key)
				continue
			}

			switch fv.Kind() {
			case reflect.Bool:
				v, err := strconv.ParseBool(val.Val)
				if err != nil {
					logger.SysWarn.Errorln(err)
					logger.Sys.Debugf("getWarnConfig: Ft: %v, FieldName: %v, dbVal: %v\n", ft.Type, ft.Name, val.Val)
				} else {
					fv.SetBool(v)
				}
			case reflect.Int64, reflect.Int32:
				v, err := strconv.ParseInt(val.Val, 10, 64)
				if err != nil {
					logger.SysWarn.Errorln(err)
					logger.Sys.Debugf("getWarnConfig: Ft: %v, FieldName: %v, dbVal: %v\n", ft.Type, ft.Name, val.Val)
				} else {
					fv.SetInt(v)
				}
			case reflect.String:
				fv.SetString(val.Val)
			default:
				logger.Sys.Debugf("no impl: getWarnConfig: %v, %v\n", ft.Type, ft.Name)
			}
		}
		return cfg, nil
	}, g.PlatformContentCacheLevelHigh)
}

func entToProtobuf(v *core_db.WarnConfig) *pbsys.WarnConfigDataVo {
	return &pbsys.WarnConfigDataVo{
		Id:      v.ID,
		Name:    v.Name,
		Key:     v.Key,
		Val:     v.Val,
		ValType: v.ValType,
	}
}

func cleanupRemoteCache() {
	ucache.RemoveRemoteCacheExpr(ucache.KeyWarnConfig)
}

// @ListWarnConfig only for gm-readonly
func ListWarnConfig(ctx context.Context, req *pbsys.WarnConfigPageReq) (*pbsys.WarnConfigPageResp, error) {
	conds := []predicate.WarnConfig{}
	offset, limit := ucommon.PageToOffset2(int(req.PageNo), int(req.PageSize))
	order := core_db.Desc(sysconfig.FieldID)
	result, err := dbcore.CliRd.WarnConfig.
		Query().
		Where(conds...).
		Order(order).
		Limit(limit).
		Offset(offset).
		All(ctx)
	if err != nil {
		logger.SysWarn.Errorln(err)
		return nil, perr.ErrDbFailed
	}

	sum := srbac.GetSum(req.PageNo, func(i int32) (int, error) {
		return dbcore.CliRd.WarnConfig.
			Query().
			Where(conds...).
			Count(ctx)
	})
	return &pbsys.WarnConfigPageResp{
		List: uslice.Map(result, entToProtobuf),
		Sum:  sum,
	}, nil
}

func AddWarnConfig(ctx context.Context, req *pbsys.AddWarnConfigReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.WarnConfig.
		Create().
		SetName(req.Name).
		SetKey(req.Key).
		SetVal(req.Val).
		SetValType(req.ValType).
		Exec(ctx)
	if err != nil {
		logger.SysWarn.Errorln(err)
		return nil, perr.ErrDbFailed
	}
	defer cleanupRemoteCache()
	return &pbbase.EmptyResp{}, nil
}

func EditWarnConfig(ctx context.Context, req *pbsys.EditWarnConfigReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.WarnConfig.
		UpdateOneID(req.Id).
		SetName(req.Name).
		SetKey(req.Key).
		SetVal(req.Val).
		SetValType(req.ValType).
		Exec(ctx)
	if err != nil {
		logger.SysWarn.Errorln(err)
		return nil, perr.ErrDbFailed
	}
	defer cleanupRemoteCache()
	return &pbbase.EmptyResp{}, nil
}

func DeleteWarnConfig(ctx context.Context, req *pbbase.IdReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.WarnConfig.
		DeleteOneID(req.Id).
		Exec(ctx)
	if err != nil {
		logger.SysWarn.Errorln(err)
		return nil, perr.ErrDbFailed
	}
	defer cleanupRemoteCache()
	return &pbbase.EmptyResp{}, nil
}

// @GenStaticClientConfigFile only for gm-readonly
func GenStaticClientConfigFile(ctx context.Context) (*pbbase.EmptyResp, error) {

	results, err := dbcore.CliRd.WarnConfig.Query().Where().All(ctx)
	if err != nil {
		logger.SysWarn.Errorln(err)
		return nil, err
	}

	rtv := map[string]any{}
	for _, v := range results {
		switch v.ValType {
		case core.ConfType_confTypeString: // ConfType = 1 //字符串
			rtv[v.Key] = v.Val
		case core.ConfType_confTypeNumber, // ConfType = 2 //数字
			core.ConfType_confTypeAmount, // ConfType = 5 // 金额
			core.ConfType_confTypeRate:   // ConfType = 6 // 百分比
			if vv, err := strconv.ParseInt(v.Val, 10, 64); err == nil {
				rtv[v.Key] = vv
			} else if vv, err := strconv.ParseFloat(v.Val, 64); err == nil {
				rtv[v.Key] = vv
			} else {
				return nil, fmt.Errorf("格式不合法: %#v", v)
			}
		case core.ConfType_confTypeBoolean: // ConfType = 3 //布尔
			if vv, err := strconv.ParseBool(v.Val); err == nil {
				rtv[v.Key] = vv
			} else {
				return nil, fmt.Errorf("格式不合法: %#v", v)
			}
		case core.ConfType_confTypeJson: // ConfType = 4 // JSON
			vv := map[string]any{}
			if err := ujson.UnmarshalFromString(v.Val, &vv); err == nil {
				rtv[v.Key] = vv
			} else {
				return nil, fmt.Errorf("格式不合法: %v, %#v", err, v)
			}
		}
	}

	jStr := ujson.MarshalToString2(rtv)
	ufile.EnsureDir("./public")
	return &pbbase.EmptyResp{},
		os.WriteFile("./public/client.cfg.json", []byte(jStr), os.ModePerm)
}
