package sgameprovideraccesstoken

import (
	"context"
	"fmt"
	"server/internals/db/dbcore"
	"server/internals/logger"
	"server/internals/utils/uhash"
	"server/internals/utils/utime"
)

func NewToken(ctx context.Context, accountId, companyId int64, tokenlen int) (string, error) {

	token := uhash.SumMD5(fmt.Sprintf("token:%v:%v:%v", utime.JakartaTime().UnixNano(), accountId, companyId))

	if tokenlen > 0 {
		token = token[:tokenlen]
	}

	err := dbcore.Cli.GameProviderAccessToken.Create().
		SetAccountID(accountId).
		SetGameCompanyID(companyId).
		SetToken(token).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return "", err
	}

	return token, nil
}
