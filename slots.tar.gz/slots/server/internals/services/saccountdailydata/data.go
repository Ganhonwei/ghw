package saccountdailydata

import (
	"context"
	"server/ent/core_db"
	"server/ent/core_db/accountdailydata"
	"server/internals/db/dbcore"
	"server/internals/utils/utime"
)

func GetTodayData(ctx context.Context, accountId int64) (*core_db.AccountDailyData, error) {
	today := utime.TodayJakarta()

	return dbcore.Cli.AccountDailyData.Query().Where(
		accountdailydata.AccountID(accountId),
		accountdailydata.Date(today),
	).Only(ctx)
}

func GetTodayDataWithTx(ctx context.Context, tx *core_db.Tx, accountId int64) (*core_db.AccountDailyData, error) {
	today := utime.TodayJakarta()

	return tx.AccountDailyData.Query().Where(
		accountdailydata.AccountID(accountId),
		accountdailydata.Date(today),
	).Only(ctx)
}

func UpdateRechargeAmountWithTx(ctx context.Context, tx *core_db.Tx, accountId, channelId, partitionId, rechargeAmount int64) error {
	today := utime.TodayJakarta()
	return tx.AccountDailyData.Create().
		SetAccountID(accountId).
		SetChannelID(channelId).
		SetPartitionID(partitionId).
		SetDate(today).
		SetRechargeAmount(rechargeAmount).
		SetRechargeCount(1).
		OnConflict().
		AddRechargeAmount(rechargeAmount).
		SetUpdatedAt(utime.JakartaTime()).
		AddRechargeCount(1).
		Exec(ctx)
}

func UpdateWithdrawAmountWithTx(ctx context.Context, tx *core_db.Tx, accountId, channelId, partitionId, withdrawAmount int64) error {
	today := utime.TodayJakarta()
	return tx.AccountDailyData.Create().
		SetAccountID(accountId).
		SetChannelID(channelId).
		SetPartitionID(partitionId).
		SetDate(today).
		SetWithdrawAmount(withdrawAmount).
		SetWithdrawCount(1).
		OnConflict().
		AddWithdrawAmount(withdrawAmount).
		SetUpdatedAt(utime.JakartaTime()).
		AddWithdrawCount(1).
		Exec(ctx)
}

func UpdateBetAmountWithTx(ctx context.Context, tx *core_db.Tx, accountId, partitionId, channelId, betAmount, winAmount int64, isValid bool, goldId int64) error {
	today := utime.TodayJakarta()
	addBc := int64(0)
	if betAmount > 0 {
		addBc = int64(1)
	}
	validBetAmount := int64(0)
	if isValid {
		validBetAmount = betAmount
	}
	err := tx.AccountDailyData.Create().
		SetAccountID(accountId).
		SetChannelID(channelId).
		SetPartitionID(partitionId).
		SetDate(today).
		SetValidBetAmount(validBetAmount).
		SetBetAmount(betAmount).
		SetBetWinAmount(winAmount).
		SetBetCount(1).
		OnConflict().
		AddValidBetAmount(validBetAmount).
		AddBetAmount(betAmount).
		AddBetWinAmount(winAmount).
		AddBetCount(addBc).
		SetUpdatedAt(utime.JakartaTime()).
		Exec(ctx)

	//金库活动
	// err = GoldWithTx(ctx, tx, goldId, validBetAmount)
	return err
}

// func GoldWithTx(ctx context.Context, tx *ent.Tx, goldId, amount int64) error {
// 	if goldId > 0 {
// 		return tx.AccountGold.Update().
// 			AddCompBet(amount).
// 			Where(
// 				accountgold.ID(goldId),
// 				// accountgold.ExpTimeGTE(utime.JakartaTime()), //未到期就添加
// 			).
// 			Modify(uent.AddGoldCompBet(amount)). //此处必须用uent.AddWithdrawCompBet,因为它实现了打码量累加超过目标量时，就不累加了
// 			Exec(ctx)
// 	}
// 	return nil
// }
