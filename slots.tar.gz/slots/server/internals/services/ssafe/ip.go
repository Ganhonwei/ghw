package ssafe

import "server/internals/generated/core"

func AddBanIP(ip, desc string, from core.IpBanFromType) {

}
