package saws

import (
	"io/ioutil"
	"os"
	"strings"
	"testing"
)

func TestUploadAndDownload(t *testing.T) {
	// 设置测试参数
	testKeyName := "test/test1226-1.txt" // 测试文件的 S3 Key
	testUploadContent := "This is a test file content."
	//testDownloadPath := "downloaded-test-file.txt"

	// 创建一个临时文件作为上传文件
	tempFile, err := ioutil.TempFile("", "test-upload-*.txt")
	if err != nil {
		t.Fatalf("Failed to create temp file: %v", err)
	}
	defer os.Remove(tempFile.Name()) // 确保测试完成后删除临时文件

	// 写入测试内容到临时文件
	if _, err := tempFile.WriteString(testUploadContent); err != nil {
		t.Fatalf("Failed to write to temp file: %v", err)
	}

	// 测试上传
	keyName := testKeyName
	if err := UploadFile(keyName, "./upload_assets", tempFile.Name()); err != nil {
		t.Fatalf("Failed to upload file: %v", err)
	}

	t.Logf("File uploaded successfully: Bucket=%s, Key=%s", aws_bucket_name, keyName)

	// 测试下载
	if err := DownloadFile(keyName, tempFile.Name()); err != nil {
		t.Fatalf("Failed to download file: %v", err)
	}
	defer os.Remove(tempFile.Name()) // 确保测试完成后删除下载文件

	t.Logf("File downloaded successfully to: %s", tempFile.Name())

	// 验证下载文件内容
	downloadedContent, err := os.ReadFile(tempFile.Name())
	if err != nil {
		t.Fatalf("Failed to read downloaded file: %v", err)
	}

	if strings.TrimSpace(string(downloadedContent)) != strings.TrimSpace(testUploadContent) {
		t.Fatalf("Content mismatch: Expected=%s, Got=%s", testUploadContent, string(downloadedContent))
	}

	t.Log("Upload and download test passed!")
}
