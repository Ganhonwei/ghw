package saws

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	smithyhttp "github.com/aws/smithy-go/transport/http"
)

var (
	// 全局变量：存储桶名称和键
	aws_bucket_name       = "pattaya1226bucket"
	aws_bucket_region     = "ap-southeast-3"
	aws_bucket_max_age    = 31536000
	aws_access_key_id     = "AKIAWN26KB5FPUGFUZMI"
	aws_secret_access_key = "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"
	// 全局 S3 客户端
	bucketClient *s3.Client
)

func init() {
	// 初始化 S3 客户端
	cfg, err := config.LoadDefaultConfig(context.TODO(),
		config.WithRegion(aws_bucket_region),
		config.WithCredentialsProvider(credentials.NewStaticCredentialsProvider(aws_access_key_id, aws_secret_access_key, "")),
	)
	if err != nil {
		panic(fmt.Errorf("failed to load AWS configuration: %w", err))
	}
	bucketClient = s3.NewFromConfig(cfg)
}

// UploadAllFiles uploads all files in the specified directory to AWS S3
func UploadAllFiles(root, childPath string) error {
	if strings.Contains(childPath, ".DS_Store") {
		return nil
	}

	// 构造完整路径
	fullPath := filepath.Join(root, childPath)

	info, err := os.Lstat(fullPath)
	if err != nil {
		return fmt.Errorf("failed to access path %s: %w", fullPath, err)
	}

	// 如果是符号链接，解析为实际路径
	if info.Mode()&os.ModeSymlink != 0 {
		resolvedPath, err := filepath.EvalSymlinks(fullPath)
		if err != nil {
			return fmt.Errorf("failed to resolve symlink %s: %w", fullPath, err)
		}
		fullPath = resolvedPath
		info, err = os.Stat(fullPath)
		if err != nil {
			return fmt.Errorf("failed to access resolved path %s: %w", fullPath, err)
		}
	}

	// 如果是文件，直接上传
	if !info.IsDir() {
		key := strings.TrimPrefix(filepath.ToSlash(childPath), "/") // 生成 S3 对象键
		file, err := os.Open(fullPath)
		if err != nil {
			return fmt.Errorf("failed to open file %s: %w", fullPath, err)
		}
		defer file.Close()

		fmt.Printf("Uploading file: %s -> Key: %s\n", fullPath, key)
		if err := UploadBody(key, file); err != nil {
			return fmt.Errorf("failed to upload file %s: %w", fullPath, err)
		}
		return nil
	}

	// 如果是文件夹，递归处理
	entries, err := os.ReadDir(fullPath)
	if err != nil {
		return fmt.Errorf("failed to read directory %s: %w", fullPath, err)
	}

	for _, entry := range entries {
		entryChildPath := filepath.Join(childPath, entry.Name())
		if err := UploadAllFiles(root, entryChildPath); err != nil {
			return err
		}
	}

	return nil
}

// UploadFile 上传文件到 S3
func UploadFile(key, uploadDir, filePath string) error {
	if key == "" || filePath == "'" {
		return nil
	}
	// 打开文件
	fillFullPath := fmt.Sprintf("%s/%s", uploadDir, key)
	file, err := os.Open(fillFullPath)
	if err != nil {
		return fmt.Errorf("failed to open file %s: %w", filePath, err)
	}
	defer file.Close()
	return UploadBody(key, file)
}

func UploadBody(key string, body io.Reader) error {
	// 设置 Cache-Control header
	// 根据 key 判断是否为 public 开头，如果是，则设置 max-age 为 0，否则使用默认值
	var maxAge int
	var forceUpload bool
	if strings.HasPrefix(key, "public/") {
		maxAge = 0
		forceUpload = true
	} else {
		maxAge = aws_bucket_max_age
		forceUpload = false
	}

	if !forceUpload {
		exit, err := FindBucket(key)
		if err != nil {
			return fmt.Errorf("failed to check key existence: %w", err)
		}
		if exit {
			fmt.Printf("key %s already exists", key)
			return nil
		}
	}

	cacheControl := fmt.Sprintf("max-age=%d", maxAge)
	// 上传文件
	_, err := bucketClient.PutObject(context.TODO(), &s3.PutObjectInput{
		Bucket:       aws.String(aws_bucket_name),
		Key:          aws.String(key),
		Body:         body,
		CacheControl: aws.String(cacheControl), // 设置 max-age
	})
	if err != nil {
		return fmt.Errorf("failed to upload file: %w", err)
	}

	//fmt.Printf("File uploaded successfully to %s/%s\n", aws_bucket_name, filePath)
	return nil
}

// DownloadFile 从 S3 下载文件
func DownloadFile(key, downloadPath string) error {
	// 下载对象
	output, err := bucketClient.GetObject(context.TODO(), &s3.GetObjectInput{
		Bucket: aws.String(aws_bucket_name),
		Key:    aws.String(key),
	})
	if err != nil {
		return fmt.Errorf("failed to download file: %w", err)
	}
	defer output.Body.Close()

	// 创建文件
	file, err := os.Create(downloadPath)
	if err != nil {
		return fmt.Errorf("failed to create file %s: %w", downloadPath, err)
	}
	defer file.Close()

	// 将数据写入文件
	_, err = io.Copy(file, output.Body)
	if err != nil {
		return fmt.Errorf("failed to save file: %w", err)
	}

	//fmt.Printf("File downloaded successfully to %s\n", downloadPath)
	return nil
}

func FindBucket(key string) (bool, error) {
	_, err := bucketClient.HeadObject(context.TODO(), &s3.HeadObjectInput{
		Bucket: aws.String(aws_bucket_name),
		Key:    aws.String(key),
	})

	if err != nil {
		// 检查错误是否为 HTTP 错误
		var httpError *smithyhttp.ResponseError
		if errors.As(err, &httpError) {
			if httpError.HTTPStatusCode() == http.StatusNotFound {
				return false, nil
			}
		}
		// 返回其他错误
		return false, fmt.Errorf("failed to check key existence: %w", err)
	}
	// 如果没有错误，表示对象存在
	return true, nil
}
