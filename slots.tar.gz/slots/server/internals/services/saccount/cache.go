package saccount

import (
	"context"
	"fmt"
	"server/ent/core_db/account"
	"server/internals/configs/g"
	"server/internals/core/ttl_cache"
	"server/internals/db/dbcore"
	"server/internals/logger"
	"sync"
	"time"

	"github.com/patrickmn/go-cache"
)

type AccountCacheInfo struct {
	AccountID int64 `json:"account_id,omitempty"`      // 账号Id
	ChannelID int64 `json:"game_company_id,omitempty"` // 渠道ID
}

var (
	cacheAcctInfoByAid      = ttl_cache.NewTtlCache[*AccountCacheInfo](30 * time.Second)
	cacheAcctInfoByAidMutex = sync.Mutex{}

	smsRegisterCache = cache.New(5*time.Second, 1*time.Minute)
)

func GetInfoByAid(ctx context.Context, aid int64) (*AccountCacheInfo, error) {
	key := fmt.Sprintf("%d", aid)
	item, exist := cacheAcctInfoByAid.Get(key)
	if exist {
		return item, nil
	}
	info, err := dbcore.Cli.Account.Query().
		Where(
			account.ID(aid),
		).Only(ctx)
	if err != nil {
		logger.Account.Errorln("GetInfoByAid", err)
		return nil, err
	}

	cacheAcctInfoByAidMutex.Lock()
	defer cacheAcctInfoByAidMutex.Unlock()
	item, exist = cacheAcctInfoByAid.Get(key)
	if exist {
		return item, nil
	}

	item = &AccountCacheInfo{
		AccountID: info.ID,
		ChannelID: info.ChannelID,
	}

	cacheAcctInfoByAid.Set(key, item, g.PlatformContentCacheLevelLow)

	return item, nil
}
