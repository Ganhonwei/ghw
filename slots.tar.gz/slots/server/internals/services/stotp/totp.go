package stotp

import (
	"fmt"
	"server/internals/configs/cfg_gm"
	"server/internals/core/ttl_cache"
	"server/internals/logger"
	"time"

	"github.com/pquerna/otp/totp"
)

var (
	ttlCache = ttl_cache.NewTtlCache[string](1 * time.Minute)
)

func GenerateSecret(accountName string) string {

	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      fmt.Sprintf("iVipGo-%v", cfg_gm.Gm.Mode),
		AccountName: accountName,
	})
	if err != nil {
		logger.Sys.Errorln(err)
		return ""
	}

	ttlCache.Set(accountName, key.Secret(), 15*time.Minute)

	return key.String()
}

func ValidateBindTotp(accountName, passcode string) (string, bool) {
	secret, found := ttlCache.Get(accountName)
	if !found {
		return "", false
	}

	if !totp.Validate(passcode, secret) {
		return "", false
	}

	return secret, true
}

func ValidateTotp(passcode, secret string) bool {
	return totp.Validate(passcode, secret)
}
