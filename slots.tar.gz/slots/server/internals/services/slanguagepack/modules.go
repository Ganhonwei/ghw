package slanguagepack

import (
	"fmt"
	"server/ent/core_db/game"
	"server/ent/core_db/gametag"
	"strings"
)

const (
	ModuleGame        = game.Label
	ModuleGameTag     = gametag.Label
	ModuleFireBase    = "fire_base"
	ModulePWDQuestion = "pwd_question"
)

var (
	gmDefLang = "ZH"
)

func SetGmDefaultLang(lang string) {
	gmDefLang = lang
}

func GetGmDefaultLang() string {
	return gmDefLang
}

func GenGmLangKey(module string, fieldName string) string {
	return fmt.Sprintf("%s.%s.%s", strings.ToLower(gmDefLang), module, fieldName)
}

func GenKey(lang string, module string, fieldName string, extId int64) string {
	if extId <= 0 {
		return fmt.Sprintf("%s.%s.%s", strings.ToLower(lang), module, fieldName)
	}
	return fmt.Sprintf("%s.%s.%s.%v", strings.ToLower(lang), module, fieldName, extId)
}
