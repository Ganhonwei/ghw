package slanguagepack

import (
	"context"
	"fmt"
	"server/cmd/gm/services/sgm/srbac"
	"server/ent/core_db"
	"server/ent/core_db/languagepack"
	"server/ent/core_db/predicate"
	"server/internals/db/dbcore"
	"server/internals/generated/webapi/gm/pbauth"
	"server/internals/generated/webapi/pbbase"
	"server/internals/generated/webapi/plat/platauth"
	"server/internals/logger"
	"server/internals/utils/ucommon"
	"server/internals/utils/uslice"
	"server/internals/utils/utime"
)

func languageToProtobuf(v *core_db.LanguagePack) *platauth.LangPack {
	return &platauth.LangPack{
		Key:     v.Key,
		Val:     v.Val,
		ValType: v.ValType,
	}
}

func entToProtobuf(v *core_db.LanguagePack) *pbauth.LanguagePackVo {
	return &pbauth.LanguagePackVo{
		Id:      v.ID,
		Lang:    v.Lang,
		Tn:      v.Tn,
		Fn:      v.Fn,
		ExtId:   v.ExtID,
		Key:     v.Key,
		Val:     v.Val,
		ValType: v.ValType,
	}
}

// @GetData only for gm-readonly
func GetData(ctx context.Context, req *pbauth.LanguagePackDataReq) (*pbauth.LanguagePackDataResp, error) {
	result, err := dbcore.CliRd.LanguagePack.
		Query().
		Where(
			languagepack.Tn(req.Tn),
			languagepack.ExtID(req.ExtId),
		).
		All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbauth.LanguagePackDataResp{
		List: uslice.Map(result, entToProtobuf),
	}, nil
}

// @List only for gm-readonly
func List(ctx context.Context, req *pbauth.LanguagePackPageReq) (*pbauth.LanguagePackPageResp, error) {
	conds := []predicate.LanguagePack{}
	if req.Tn != nil {
		conds = append(conds, languagepack.TnEQ(*req.Tn))
	}
	if req.Fn != nil {
		conds = append(conds, languagepack.FnEQ(*req.Fn))
	}
	if req.Key != nil {
		conds = append(conds, languagepack.KeyEQ(*req.Key))
	}
	if req.ExtId != nil {
		conds = append(conds, languagepack.ExtIDEQ(*req.ExtId))
	}

	offset, limit := ucommon.PageToOffset2(int(req.PageNo), int(req.PageSize))
	order := core_db.Desc(languagepack.FieldID)
	result, err := dbcore.CliRd.LanguagePack.
		Query().
		Where(conds...).
		Order(order).
		Limit(limit).
		Offset(offset).
		All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}

	sum := srbac.GetSum(req.PageNo, func(i int32) (int, error) {
		return dbcore.CliRd.LanguagePack.
			Query().
			Where(conds...).
			Count(ctx)
	})
	return &pbauth.LanguagePackPageResp{
		List: uslice.Map(result, entToProtobuf),
		Sum:  sum,
	}, nil
}

// @Get only for gm-readonly
func Get(ctx context.Context, req *pbbase.IdReq) (resp *pbauth.LanguagePackVo, err error) {
	result, err := dbcore.CliRd.LanguagePack.Get(ctx, req.Id)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return entToProtobuf(result), nil
}

func Insert(ctx context.Context, req *pbauth.LanguagePackAddReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.LanguagePack.
		Create().
		SetLang(req.Lang).
		SetTn(req.Tn).
		SetFn(req.Fn).
		SetExtID(req.ExtId).
		SetKey(fmt.Sprintf("%s.%s.%s.%d", req.Lang, req.Tn, req.Fn, req.ExtId)).
		SetVal(req.Val).
		SetValType(req.ValType).
		SetUpdatedTime(utime.UnixMs()).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbbase.EmptyResp{}, nil
}

func Update(ctx context.Context, req *pbauth.LanguagePackEditReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.LanguagePack.
		UpdateOneID(req.Id).
		SetLang(req.Lang).
		SetTn(req.Tn).
		SetFn(req.Fn).
		SetExtID(req.ExtId).
		SetKey(fmt.Sprintf("%s.%s.%s.%d", req.Lang, req.Tn, req.Fn, req.ExtId)).
		SetVal(req.Val).
		SetValType(req.ValType).
		SetUpdatedTime(utime.UnixMs()).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbbase.EmptyResp{}, nil
}

func Delete(ctx context.Context, req *pbbase.IdReq) (*pbbase.EmptyResp, error) {
	err := dbcore.Cli.LanguagePack.
		DeleteOneID(req.Id).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return &pbbase.EmptyResp{}, nil
}

func GetListByLang(ctx context.Context, lang string, version int64) (*platauth.GetLangPackResp, error) {
	order := core_db.Desc(languagepack.FieldUpdatedTime)
	result, err := dbcore.Cli.LanguagePack.
		Query().
		Where(
			languagepack.LangEQ(lang),
			languagepack.UpdatedTimeGT(version),
			languagepack.ServerOnly(false),
		).
		Order(order).
		All(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	//TODO 以后可以考虑存入缓存
	version = int64(0)
	if len(result) > 0 {
		version = result[0].UpdatedTime
	}
	return &platauth.GetLangPackResp{
		List:    uslice.Map(result, languageToProtobuf),
		Version: version,
	}, nil
}

func GetLangByTnFnExtId(ctx context.Context, lang, tn, fn string, extId ...int64) ([]*core_db.LanguagePack, error) {

	conds := []predicate.LanguagePack{
		languagepack.Lang(lang),
	}

	if len(tn) > 0 {
		conds = append(conds, languagepack.Tn(tn))
	}

	if len(fn) > 0 {
		conds = append(conds, languagepack.Fn(fn))
	}

	if len(extId) > 0 {
		conds = append(conds, languagepack.ExtIDIn(extId...))
	}

	return dbcore.Cli.LanguagePack.Query().
		Where(conds...).
		All(ctx)
}

func GetByLangTnFnExtId(ctx context.Context, lang, tn, fn string, extId int64) (*core_db.LanguagePack, error) {
	result, err := dbcore.Cli.LanguagePack.
		Query().
		Where(
			languagepack.Lang(lang),
			languagepack.Tn(tn),
			languagepack.Fn(fn),
			languagepack.ExtID(extId),
		).
		Only(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil, err
	}
	return result, nil
}

func UpdateByTnFnExtId(ctx context.Context, tn, fn string, extId int64, val string) error {
	err := dbcore.Cli.LanguagePack.
		Update().
		SetVal(val).
		Where(
			languagepack.Tn(tn),
			languagepack.Fn(fn),
			languagepack.ExtID(extId),
		).
		Exec(ctx)
	if err != nil {
		logger.Sys.Errorln(err)
		return err
	}
	return nil
}
