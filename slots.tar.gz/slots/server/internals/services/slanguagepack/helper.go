package slanguagepack

import (
	"context"
	"fmt"
	"server/ent/core_db"
	"server/ent/core_db/languagepack"
	"server/internals/utils/ustring"
	"server/internals/utils/utime"
	"strings"

	"entgo.io/ent/dialect/sql"
)

func DeleteLangWithTx(ctx context.Context, tx *core_db.Tx, tn string, id int64) error {
	_, err := tx.LanguagePack.Delete().Where(languagepack.ExtID(id), languagepack.Tn(tn)).Exec(ctx)
	if err != nil {
		return err
	}
	return nil
}

func SaveLangWithTx(
	ctx context.Context,
	tx *core_db.Tx,
	id int64,
	kv map[string]string,
	serverOnlyFields []string) error {

	creates := []*core_db.LanguagePackCreate{}

	var lang, tn, fn string
	now := utime.UnixMs()
	for k, v := range kv {
		ks := strings.Split(k, ".")
		n := len(ks)
		if n != 3 {
			return fmt.Errorf("FillMutation, scanf key failed: %v", n)
		}
		lang = ks[0]
		tn = ks[1]
		fn = ks[2]
		key := fmt.Sprintf("%s.%s.%s.%d", lang, tn, fn, id)
		c := tx.LanguagePack.Create().
			SetLang(lang).
			SetTn(tn).
			SetFn(fn).
			SetExtID(id).
			SetKey(key).
			SetVal(v).
			SetValType("text").
			SetUpdatedTime(now).
			SetServerOnly(ustring.ContainsCaseIncentive(serverOnlyFields, fn))
		creates = append(creates, c)
	}

	return tx.LanguagePack.CreateBulk(creates...).
		OnConflict(sql.ResolveWithIgnore()).
		Exec(ctx)
}
