package sgmauth

import (
	"context"
	"server/ent/core_db"
	"server/ent/core_db/sysuser"
	"server/internals/configs/g"
	"server/internals/core/ttl_cache"
	"server/internals/db/dbcore"
	"server/internals/logger"
	"strconv"
	"time"
)

type GmAuthInfo struct {
	// "IdentityKey": claims["identity"],
	// "UserName":    claims["nice"],
	// "RoleKey":     claims["rolekey"],
	// "UserId":      claims["identity"],
	// "RoleIds":     claims["roleid"],
	// "DataScope":   claims["datascope"],
	Jti          string
	ID           int32
	GmName       string
	GmRole       int32
	GmRoleKey    string
	ChannelScope map[string]struct{}
	Whiteips     []string
}

var cacheAuthInfo = ttl_cache.NewTtlCache[*GmAuthInfo](30 * time.Second)
var cacheAuthInfoByAcctID = ttl_cache.NewTtlCache[*GmAuthInfo](30 * time.Second)

type authInfoLoader func(string) (*core_db.SysUser, error)

func GetAuthInfoByJwtId(jti string) *GmAuthInfo {
	return getAuthInfo(jti, func(jti string) (*core_db.SysUser, error) {
		return dbcore.Cli.SysUser.
			Query().
			WithOwner().
			Where(sysuser.Jti(jti)).
			Only(context.Background())
	})
}
func makeAcctKey(acctId int) string {
	return strconv.FormatInt(int64(acctId), 36)
}
func getAuthInfo(jti string, loader authInfoLoader) *GmAuthInfo {
	info, loaded := cacheAuthInfo.Get(jti)

	if loaded {

		otherInfo, ok := cacheAuthInfoByAcctID.Get(makeAcctKey(int(info.ID)))
		if ok && otherInfo.Jti == jti {
			return info
		}

		// 当前传入的 jti ，不是最新的jti。踢掉之前的。
		cacheAuthInfo.Delete(jti)
	}

	acct, err := loader(jti)
	if err != nil {
		logger.Sys.Errorln(err)
		return nil
	}
	// role, err := acct.Edges.RoleOrErr()
	role, err := acct.Edges.OwnerOrErr()
	if err != nil {
		logger.Sys.Errorln(err)
		return nil
	}
	info = &GmAuthInfo{
		Jti:          jti,
		ID:           acct.ID,
		GmName:       acct.NickName,
		GmRole:       acct.RoleID,
		GmRoleKey:    role.RoleKey,
		ChannelScope: map[string]struct{}{},
		Whiteips:     acct.Whiteips,
	}

	for _, v := range acct.ChannelScope {
		info.ChannelScope[v] = struct{}{}
	}

	cacheAuthInfo.Set(jti, info, time.Second*g.PlatformCacheAuthInfoSec)
	cacheAuthInfoByAcctID.Set(makeAcctKey(int(info.ID)), info, time.Second*g.PlatformCacheAuthInfoSec)
	return info
}

func CleanCacheById(id int) {
	cacheAuthInfoByAcctID.Delete(makeAcctKey(id))
}

func CleanCache() {
	cacheAuthInfoByAcctID.Clean()
}
