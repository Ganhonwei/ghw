package middleware

import (
	"bytes"
	"fmt"
	"server/internals/endpoint/router_builder"
	"server/internals/generated/core/errcode"
	"server/internals/perr"
	"server/internals/utils/ujwt"
	"net/http"

	"github.com/pascaldekloe/jwt"
	"github.com/valyala/fasthttp"
)

type GetAuthKeyFunc func() []byte
type AuthCallback func(claims *jwt.Claims, ctx *router_builder.RequestCtx) error
type TokenGetter func(ctx *router_builder.RequestCtx) []byte

var (
	ErrKicked = fmt.Errorf("jwt is kicked")
)

var JwtQueryTokenGetter = QueryTokenGetter("jwt")
var BearTokenGetter = BearTokenHeader()

func MakeJwtAuth(tokenGetter TokenGetter, getAuthKey GetAuthKeyFunc, authCb AuthCallback) router_builder.RequestHandler {
	return func(ctx *router_builder.RequestCtx) {
		data := tokenGetter(ctx)

		c, ok := ujwt.Check(getAuthKey(), data)
		if !ok {
			ctx.SetStatusCode(http.StatusUnauthorized)
			ctx.Abort()
			return
		}

		err := authCb(c, ctx)
		if err != nil {
			if perr.IsCode(err, errcode.ErrCode_AcctForbidden) {
				ctx.SetStatusCode(http.StatusForbidden)
				ctx.Abort()
			} else {
				ctx.SetStatusCode(http.StatusUnauthorized)
				ctx.Abort()
			}
		}

	}
}

func MakeAllowJwtAuth(tokenGetter TokenGetter, getAuthKey GetAuthKeyFunc, authCb AuthCallback) router_builder.RequestHandler {
	return func(ctx *router_builder.RequestCtx) {
		data := tokenGetter(ctx)
		if len(data) > 0 {
			c, ok := ujwt.Check(getAuthKey(), data)
			if !ok {
				ctx.SetStatusCode(http.StatusUnauthorized)
				ctx.Abort()
				return
			}

			err := authCb(c, ctx)
			if err != nil {
				if perr.IsCode(err, errcode.ErrCode_AcctForbidden) {
					ctx.SetStatusCode(http.StatusForbidden)
					ctx.Abort()
				} else {
					ctx.SetStatusCode(http.StatusUnauthorized)
					ctx.Abort()
				}
			}
		}
	}
}

func QueryTokenGetter(q string) TokenGetter {
	return func(ctx *router_builder.RequestCtx) []byte {
		return ctx.QueryArgs().Peek(q)
	}
}

func HeaderTokenGetter(h string) TokenGetter {
	hbs := []byte(h)
	return func(ctx *router_builder.RequestCtx) []byte {
		return ctx.Request.Header.PeekBytes(hbs)
	}
}

func BearTokenHeader() TokenGetter {
	tokenGetter := HeaderTokenGetter(fasthttp.HeaderAuthorization)

	return func(ctx *router_builder.RequestCtx) []byte {
		bear := tokenGetter(ctx)
		if !bytes.HasPrefix(bear, ujwt.Bearer) {
			return nil
		}
		return bear[len(ujwt.Bearer):]
	}
}
