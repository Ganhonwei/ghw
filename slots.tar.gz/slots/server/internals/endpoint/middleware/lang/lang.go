package lang

import (
	"fmt"
	"server/internals/configs/g"
	"server/internals/endpoint/router_builder"
	"server/internals/utils/uslice"
	"server/internals/utils/utypes"
	"strings"

	"github.com/valyala/fasthttp"
	"golang.org/x/exp/slices"
	"golang.org/x/text/language"
)

var (
	ErrNoSupportedLang = fmt.Errorf("lang is't supported")
	defLang            = "en"
)

func MakeLang(langs []string) router_builder.RequestHandler {

	_ = uslice.Map(langs, language.MustParse)
	langs = uslice.Map(langs, strings.ToLower)

	return func(ctx *router_builder.RequestCtx) {
		accept := ctx.Request.Header.Peek(fasthttp.HeaderAcceptLanguage)

		lang := utypes.BytesToString(accept)
		lang = strings.ToLower(lang)
		if !slices.Contains(langs, lang) {
			ctx.SetUserValue(g.CtxLangKey, defLang)
		} else {
			ctx.SetUserValue(g.CtxLangKey, lang)
		}

	}
}

func SetDefaultLang(lang string) {
	defLang = strings.ToLower(lang)
}

func GetCtxLang(ctx *router_builder.RequestCtx) string {
	v := ctx.UserValue(g.CtxLangKey)

	if v == nil {
		return defLang
	}

	if vv, ok := v.(string); ok {
		return vv
	}

	return defLang
}

func GetCtxLangWithDefault(ctx *router_builder.RequestCtx, defLang string) string {
	v := ctx.UserValue(g.CtxLangKey)

	if v == nil {
		return defLang
	}

	if vv, ok := v.(string); ok {
		return vv
	}

	return defLang
}
