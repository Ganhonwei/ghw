package endpoint

import (
	"bytes"
	"server/internals/endpoint/router_builder"
	"server/internals/logger"
	"sync"
	"time"

	"github.com/fasthttp/router"
	"github.com/valyala/fasthttp"
	"github.com/valyala/fasthttp/pprofhandler"
)

type Endpoint struct {
	name       string
	bind       string
	srv        *fasthttp.Server
	router     *router.Router
	wg         sync.WaitGroup
	allowPprof bool
}

func (ep *Endpoint) init() {
	if ep.allowPprof {
		ep.srv.Handler = func(ctx *fasthttp.RequestCtx) {
			if bytes.HasPrefix(ctx.Path(), []byte("/debug/pprof/")) {
				pprofhandler.PprofHandler(ctx)
			} else {
				ep.router.Handler(ctx)
			}
		}
	} else {
		ep.srv.Handler = ep.router.Handler
	}
}

func (ep *Endpoint) Start() {
	ep.init()

	ep.wg.Add(1)
	go func() {
		defer ep.wg.Done()
		logger.Web.Infof("Endpoint[%s] start at: %s", ep.name, ep.bind)
		if err := ep.srv.ListenAndServe(ep.bind); err != nil {
			logger.Web.Errorf("Endpoint[%s] start falied: %s", ep.name, err)
			panic(err)
		}
		logger.Web.Infof("Endpoint[%s] listen is stopped", ep.name)
	}()
}

func (ep *Endpoint) Stop() {
	ep.srv.Shutdown()
	ep.wg.Wait()
}

func NewEndpoint(name, bind string, routerBuilder *router_builder.RouterBuilder, allowPprof bool) *Endpoint {
	return &Endpoint{
		allowPprof: allowPprof,
		router:     routerBuilder.Build(),
		name:       name,
		bind:       bind,
		srv: &fasthttp.Server{
			MaxKeepaliveDuration:         10 * time.Second,
			DisablePreParseMultipartForm: true,
			LogAllErrors:                 true,
			Logger:                       logger.NewLogger(name),
		},
	}
}
