package cors

import (
	"strings"

	"github.com/valyala/fasthttp"
	"golang.org/x/exp/maps"
)

var (
	corsAllowHeaders = map[string]bool{
		fasthttp.HeaderAuthorization: true,
		fasthttp.HeaderContentType:   true,
		fasthttp.HeaderUserAgent:     true,
	}
	// corsAllowHeaders = "Authorization"
	corsAllowMethods     = "HEAD,GET,POST,OPTIONS"
	corsAllowOrigin      = "*"
	corsAllowCredentials = "true"
	allowHeaders         = "content-type"
)

func AddAllowHeader(s string) {
	corsAllowHeaders[s] = true

	genAllowHeaders()
}

func genAllowHeaders() {
	allowHeaders = strings.Join(maps.Keys(corsAllowHeaders), ",")
	allowHeaders = allowHeaders + "," + "XDEV,X-MAINAPK,h5client"
}

func GlobalOPTIONS(ctx *fasthttp.RequestCtx) {
	ctx.Response.Header.Set("Access-Control-Allow-Credentials", corsAllowCredentials)
	ctx.Response.Header.Set("Access-Control-Allow-Headers", allowHeaders)
	ctx.Response.Header.Set("Access-Control-Allow-Methods", corsAllowMethods)
	ctx.Response.Header.Set("Access-Control-Allow-Origin", corsAllowOrigin)
}

func init() {
	genAllowHeaders()
}
