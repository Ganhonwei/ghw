package router_builder

import (
	"testing"
)

func rb_root(ctx *RequestCtx)     {}
func rb_api_root(ctx *RequestCtx) {}

func TestRouterBuilder_Build(t *testing.T) {

	rb := NewRouterBuilder("Test", "", rb_root)

	rb.Router("/api", rb_api_root).Get("/abc", func(ctx *RequestCtx) {

	}).Post("/post", func(ctx *RequestCtx) {

	})

	rb.Router("/wxapi").Get("/abc", func(ctx *RequestCtx) {

	}).Post("/post", func(ctx *RequestCtx) {

	})

	rb.Build()

	// tests := []struct {
	// 	name string
	// 	b    *RouterBuilder
	// 	want *router.Router
	// }{
	// 	// TODO: Add test cases.
	// }
	// for _, tt := range tests {
	// 	t.Run(tt.name, func(t *testing.T) {
	// 		if got := tt.b.Build(); !reflect.DeepEqual(got, tt.want) {
	// 			t.Errorf("RouterBuilder.Build() = %v, want %v", got, tt.want)
	// 		}
	// 	})
	// }
}
