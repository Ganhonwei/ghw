package router_builder

import (
	"encoding/hex"
	"encoding/json"
	"reflect"
	"runtime"
	"server/internals/configs/g"
	"server/internals/generated/core/errcode"
	"server/internals/generated/webapi/pbbase"
	"server/internals/logger"
	"server/internals/perr"
	"server/internals/utils/usession"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/blake2b"
	"google.golang.org/protobuf/proto"
)

var (
	reqIdSeq = time.Now().UnixMicro()
)

func NewRequestId() int64 {
	return atomic.AddInt64(&reqIdSeq, 1)
}

type MessagePointer[T any] interface {
	*T
	proto.Message
}

type Handler[TReq any, TResp any] func(ctx *RequestCtx, req TReq) (TResp, error)

var handlerNames = map[uintptr]string{}

func WrapHandler[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {

	f := func(ctx *RequestCtx) {
		uuid := NewRequestId()
		reqPath := string(ctx.Path())
		reqHost := strings.ToLower(string(ctx.Host()))
		t1 := time.Now()
		sessKey := GetCtxSessionKey(ctx)

		defer func() {
			logger.Web.Debugf("%v[%v]: WebRequest: End %v Cost Time: %v", sessKey, uuid, reqPath, time.Since(t1))
		}()

		req := PTReq(new(TReq))
		err := ctx.BindJson(req, false)
		if err != nil {
			logger.Web.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %v %#v", sessKey, uuid, reqPath, string(ctx.PostBody()), err)
			ctx.DoError(err)
			return
		}

		resp, err := h(ctx, req)
		if err != nil {
			if perr.IsOkOrWait(err) {
				ec, _ := perr.GetCode(err)
				ctx.DoErrorWithProtobuf(ec, resp)
			} else {
				ctx.DoError(err)
			}
			logger.Web.Debugf("%v[%v]: WebRequest: DoHandlerFailed: %v %#v", sessKey, uuid, reqPath, err)
			return
		}

		ctx.DoProtobuf(resp, reqHost)
	}

	handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	return f
}

// for sample
var _ = WrapHandler(func(*RequestCtx, *pbbase.PingReq) (*pbbase.PongResp, error) {
	return nil, nil
})

func WrapHandlerHtml[
	TReq any,
	TResp string,
	PTReq MessagePointer[TReq],
	PTResp string](h Handler[PTReq, PTResp]) RequestHandler {

	f := func(ctx *RequestCtx) {
		uuid := NewRequestId()
		reqPath := string(ctx.Path())
		t1 := time.Now()
		sessKey := GetCtxSessionKey(ctx)

		defer func() {
			logger.Web.Debugf("%v[%v]: WebRequest: End %v Cost Time: %v", sessKey, uuid, reqPath, time.Since(t1))
		}()

		req := PTReq(new(TReq))
		err := ctx.BindForm(req)
		if err != nil {
			logger.Web.Debugf("%v[%v]: WebRequest: BindFormFailed %v %v %#v", sessKey, uuid, reqPath, ctx.PostArgs(), err)
			ctx.DoError(err)
			return
		}

		resp, err := h(ctx, req)
		if err != nil {
			ctx.DoError(err)
			logger.Web.Debugf("%v[%v]: WebRequest: DoHandlerFailed: %v %#v", sessKey, uuid, reqPath, err)
			return
		}

		body := []byte(resp)
		ctx.Response.Header.Add("Content-Type", "text/html")
		ctx.Response.Header.Add("Cache-Control", "no-cache, no-store, must-revalidate")
		ctx.Response.BodyWriter().Write(body)
	}

	handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	return f
}

func WrapHandlerAutoNormal[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {

	return wrapHandlerCore(h, false, false, false, false, false)
}

func WrapHandlerAutoCompress[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {

	return WrapHandlerAutoCompressWithDump[TReq, TResp](h, true, true)

	// f := func(ctx *RequestCtx) {
	// 	uuid := NewRequestId()
	// 	ctx.SetUserValue(g.CtxRequestId, uuid)
	// 	reqPath := string(ctx.Path())
	// 	sessKey := GetCtxSessionKey(ctx)

	// 	t1 := time.Now()

	// 	defer func() {
	// 		logger.Web.Debugf("%v[%v]: WebRequest: End %v Cost Time: %v", sessKey, uuid, reqPath, time.Since(t1))
	// 	}()

	// 	xdev := ctx.Request.Header.Peek("XDEV")

	// 	ctx.needCompress = len(xdev) <= 0
	// 	ctx.needDecompress = len(xdev) <= 0

	// 	req := PTReq(new(TReq))
	// 	err := ctx.BindJson(req)
	// 	if err != nil {
	// 		logger.Web.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %#v", sessKey, uuid, reqPath, err)
	// 		ctx.DoError(err)
	// 		return
	// 	}

	// 	resp, err := h(ctx, req)
	// 	if err != nil {
	// 		if perr.IsOkOrWait(err) {
	// 			ec, _ := perr.GetCode(err)
	// 			ctx.DoErrorWithProtobuf(ec, resp)
	// 		} else {
	// 			ctx.DoError(err)
	// 		}
	// 		logger.Web.Debugf("%v[%v]: WebRequest: DoHandler %v %#v", sessKey, uuid, reqPath, err)
	// 		return
	// 	}

	// 	ctx.DoProtobuf(resp)
	// }

	// handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	// return f
}

func WrapHandlerAutoCompressWithDump[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp], dumpRequest, dumpResponse bool) RequestHandler {

	return wrapHandlerCore(h, dumpRequest, dumpResponse, false, false, false)

	// f := func(ctx *RequestCtx) {
	// 	uuid := NewRequestId()
	// 	ctx.SetUserValue(g.CtxRequestId, uuid)
	// 	reqPath := string(ctx.Path())
	// 	sessKey := GetCtxSessionKey(ctx)

	// 	t1 := time.Now()

	// 	defer func() {
	// 		logger.Web.Debugf("%v[%v]: WebRequest: End %v Cost Time: %v", sessKey, uuid, reqPath, time.Since(t1))
	// 	}()

	// 	xdev := ctx.Request.Header.Peek("XDEV")

	// 	ctx.needCompress = len(xdev) <= 0
	// 	ctx.needDecompress = len(xdev) <= 0
	// 	ctx.dumpRequest = dumpRequest
	// 	ctx.dumpResponse = dumpResponse

	// 	//维护模式检查
	// 	isMain := ssysconfig.GetIsMainMode(ctx)
	// 	mainApk := string(ctx.Request.Header.Peek(g.CtxMainApk))
	// 	if isMain && mainApk != "apk" { //维护模式开启，非指定header不准同行
	// 		ctx.DoError(perr.NewCodeError(errcode.ErrCode_MaintenanceNotRequest))
	// 		ctx.Abort()
	// 		return
	// 	}

	// 	req := PTReq(new(TReq))
	// 	err := ctx.BindJson(req)
	// 	if err != nil {
	// 		logger.Web.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %#v", sessKey, uuid, reqPath, err)
	// 		ctx.DoError(err)
	// 		return
	// 	}

	// 	resp, err := h(ctx, req)
	// 	if err != nil {
	// 		if perr.IsOkOrWait(err) {
	// 			ec, _ := perr.GetCode(err)
	// 			ctx.DoErrorWithProtobuf(ec, resp)
	// 		} else {
	// 			ctx.DoError(err)
	// 		}
	// 		logger.Web.Debugf("%v[%v]: WebRequest: DoHandler %v %#v", sessKey, uuid, reqPath, err)
	// 		return
	// 	}

	// 	ctx.DoProtobuf(resp)
	// }

	// handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	// return f
}

func WrapHandlerAutoCompressWithDumpDebug[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp], dumpRequest, dumpResponse bool) RequestHandler {

	return wrapHandlerCore(h, dumpRequest, dumpResponse, false, true, false)
}

func WrapHandlerAutoCompressWithAes[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {
	return wrapHandlerCore(h, true, true, true, false, false)
}

func WrapHandlerAutoCompressWithAes2[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {
	return wrapHandlerCore(h, true, true, true, false, true)
}

func WrapHandlerAutoCompressWithParam[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp], p map[string]string) RequestHandler {

	return wrapHandlerCore(h, true, true, true, false, false)

}

func WrapHandlerWithDynApi[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp]) RequestHandler {
	f := func(ctx *RequestCtx) {
		uuid := NewRequestId()
		ctx.SetUserValue(g.CtxRequestId, uuid)
		reqPath := string(ctx.Path())
		sessKey := GetCtxSessionKey(ctx)

		t1 := time.Now()

		defer func() {
			logger.Web.Debugf("%v[%v]: WebRequest: End %v Cost Time: %v", sessKey, uuid, reqPath, time.Since(t1))
		}()

		//动态API参数替换
		needParama := ctx.UserValue("ParamMappings")
		if np, ok := needParama.(map[string]string); ok {
			ctx.needParam = np
		}
		ctx.needAES = false
		ctx.needCompress = false
		ctx.needDecompress = false
		ctx.dumpRequest = false
		ctx.dumpResponse = false

		req := PTReq(new(TReq))
		err := ctx.BindJson(req, false) //AES解密逻辑在这里面，参数替换在这里面
		if err != nil {
			logger.Web.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %#v", sessKey, uuid, reqPath, err)
			ctx.DoError(err)
			return
		}

		resp, _ := h(ctx, req) //特殊处理不会返回异常
		jdata, _ := json.Marshal(resp)
		ctx.Success("application/json", jdata)
	}

	handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	return f
}

func wrapHandlerCore[
	TReq any,
	TResp any,
	PTReq MessagePointer[TReq],
	PTResp MessagePointer[TResp]](h Handler[PTReq, PTResp], dumpRequest, dumpResponse, allowAES, isDebug, decryptFirst bool) RequestHandler {

	f := func(ctx *RequestCtx) {
		uuid := NewRequestId()
		ctx.SetUserValue(g.CtxRequestId, uuid)
		reqPath := string(ctx.Path())
		reqHost := strings.ToLower(string(ctx.Host()))
		sessKey := GetCtxSessionKey(ctx)

		t1 := time.Now()

		defer func() {
			if ctx.isDebug {
				logger.WebDebug.Debugf("%v[%v]: WebRequest: End %v %v Cost Time: %v", sessKey, uuid, reqHost, reqPath, time.Since(t1))
			} else {
				logger.Web.Debugf("%v[%v]: WebRequest: End %v %v Cost Time: %v", sessKey, uuid, reqHost, reqPath, time.Since(t1))
			}
		}()

		xdev := ctx.Request.Header.Peek("XDEV")
		htclient := ctx.Request.Header.Peek("H5CLIENT")

		//动态API参数替换
		needParama := ctx.UserValue("ParamMappings")
		if np, ok := needParama.(map[string]string); ok {
			ctx.needParam = np
		}

		// ctx.needAES = allowAES && len(xdev) <= 0
		//先改为全部加密
		ctx.needAES = len(xdev) <= 0
		ctx.needCompress = len(xdev) <= 0
		ctx.needDecompress = len(xdev) <= 0
		ctx.dumpRequest = dumpRequest
		ctx.dumpResponse = dumpResponse
		ctx.isDebug = isDebug
		ctx.isH5 = len(htclient) > 0

		//维护模式检查
		isMain := false
		mainApk := string(ctx.Request.Header.Peek(g.CtxMainApk))
		if isMain && mainApk != "apk" { //维护模式开启，非指定header不准同行
			ctx.DoError(perr.NewCodeError(errcode.ErrCode_MaintenanceNotRequest))
			ctx.Abort()
			return
		}

		req := PTReq(new(TReq))
		err := ctx.BindJson(req, decryptFirst) //AES解密逻辑在这里面
		if err != nil {
			if ctx.isDebug {
				logger.WebDebug.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %#v", sessKey, uuid, reqPath, err)
			} else {
				logger.Web.Debugf("%v[%v]: WebRequest: BindJsonFailed %v %#v", sessKey, uuid, reqPath, err)
			}
			ctx.DoError(err)
			return
		}
		resp, err := h(ctx, req)
		if err != nil {
			if perr.IsOkOrWait(err) {
				ec, _ := perr.GetCode(err)
				ctx.DoErrorWithProtobuf(ec, resp)
			} else {
				ctx.DoError(err)
			}
			if ctx.isDebug {
				logger.WebDebug.Debugf("%v[%v]: WebRequest: DoHandler %v %#v", sessKey, uuid, reqPath, err)
			} else {
				logger.Web.Debugf("%v[%v]: WebRequest: DoHandler %v %#v", sessKey, uuid, reqPath, err)
			}

			return
		}

		ctx.DoProtobuf(resp, reqHost)
	}

	handlerNames[reflect.ValueOf(f).Pointer()] = runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()

	return f
}

func MustChectSessionKey(force bool) func(*RequestCtx) {

	return func(ctx *RequestCtx) {

		p := string(ctx.Path())
		if strings.HasPrefix(p, "/callback/") || strings.HasPrefix(p, "/cp/") || strings.HasSuffix(p, "/ping") {
			return
		}

		//TODO 先检查新key，如果没有就检查旧key
		xkey := string(ctx.Request.Header.Peek(g.CtxSessionKeyNew))
		if xkey == "" || len(xkey) == 0 {
			xkey = string(ctx.Request.Header.Peek(g.CtxSessionKey))
		}
		if !force {
			ctx.SetUserValue(g.CtxSessionKey, xkey)
			return
		}
		found, valid := usession.CheckSession(xkey)
		if found {
			if valid {
				ctx.SetUserValue(g.CtxSessionKey, xkey)
			} else {
				// TODO 记录 IP 异常信息
				ctx.SetStatusCode(401)
				ctx.Abort()
			}
			return
		}

		if len(xkey) != 40 {
			// TODO 记录 IP 异常信息
			usession.SetSession(xkey, false)
			ctx.SetStatusCode(401)
			ctx.Abort()
			return
		}

		data := []byte(xkey[:24])
		data = append(data, []byte("nopainnogain@#$123")...)
		hash := blake2b.Sum256(data)
		sign := hex.EncodeToString(hash[:])

		if xkey[24:] != sign[:16] {
			// TODO 记录 IP 异常信息
			usession.SetSession(xkey, false)
			ctx.SetStatusCode(401)
			ctx.Abort()
			return
		}

		ctx.SetUserValue(g.CtxSessionKey, xkey)
		usession.SetSession(xkey, true)
	}
}

func GetCtxSessionKey(ctx *RequestCtx) string {
	v := ctx.UserValue(g.CtxSessionKey)
	if v == nil {
		return "nil"
	}

	vv, ok := v.(string)
	if !ok {
		return "nil"
	}

	return vv
}

func CheckChannelID() func(*RequestCtx) {
	return func(ctx *RequestCtx) {

		p := string(ctx.Path())
		if strings.HasPrefix(p, "/callback/") || strings.HasPrefix(p, "/cp/") || strings.HasSuffix(p, "/ping") {
			return
		}

		channId := string(ctx.Request.Header.Peek(g.CtxChanKey))

		id, err := strconv.ParseInt(channId, 10, 64)
		if err != nil {
			id = 1
		}
		if id < 1 {
			id = 1
		}

		ctx.SetUserValue(g.CtxChanKey, id)
	}
}

func GetCtxChannelID(ctx *RequestCtx, cid int64) int64 {
	if cid > 0 {
		return cid
	}
	v := ctx.UserValue(g.CtxChanKey)
	if v == nil {
		return 1
	}

	vv, ok := v.(int64)
	if !ok {
		return 1
	}

	return vv
}

func GetCtxPkg(ctx *RequestCtx) string {
	v := ctx.UserValue(g.CtxPkgKey)
	if v == nil {
		return ""
	}

	vv, ok := v.(string)
	if !ok {
		return ""
	}

	return vv
}
