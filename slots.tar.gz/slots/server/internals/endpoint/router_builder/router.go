package router_builder

import (
	"fmt"
	"server/cmd/task/tgbot"
	"server/internals/endpoint/cors"
	"server/internals/logger"
	"server/internals/utils/uruntime"
	"net/http"
	"path"
	"reflect"
	"runtime"

	"github.com/fasthttp/router"
	"github.com/valyala/fasthttp"
)

type RouterItem struct {
	Method      string
	Path        string
	Handlers    []RequestHandler
	handlerName string
}

func (ri *RouterItem) HandlerName() string {
	if len(ri.handlerName) > 0 {
		return ri.handlerName
	}

	for _, v := range ri.Handlers {

		name, found := handlerNames[reflect.ValueOf(v).Pointer()]
		if found {
			ri.handlerName = name
			return name
		}

	}

	ri.handlerName = NameOfFunction(ri.Handlers[len(ri.Handlers)-1])
	return ri.handlerName
}

type RouterBuilder struct {
	name        string
	path        string
	middlewares []RequestHandler
	children    []*RouterBuilder
	handlers    map[string]*RouterItem
}

func (b *RouterBuilder) Name() string { return b.name }

func (b *RouterBuilder) handle(method, path string, reqHandlers ...RequestHandler) *RouterBuilder {
	if _, ok := b.handlers[path]; ok {
		panic(fmt.Sprintf("register dupilcated url: %s", path))
	}

	b.handlers[path] = &RouterItem{
		Method:   method,
		Path:     path,
		Handlers: reqHandlers,
	}
	return b
}

func (b *RouterBuilder) Get(path string, reqHandlers ...RequestHandler) *RouterBuilder {
	return b.handle(http.MethodGet, path, reqHandlers...)
}

func (b *RouterBuilder) Post(path string, reqHandlers ...RequestHandler) *RouterBuilder {
	return b.handle(http.MethodPost, path, reqHandlers...)
}

func (b *RouterBuilder) Router(path string, handlers ...RequestHandler) *RouterBuilder {
	rb := NewRouterBuilder(b.name, path, handlers...)
	b.children = append(b.children, rb)
	return rb
	// idx := slices.IndexFunc(b.children, func(rb *RouterBuilder) bool {
	// 	return rb.path == path
	// })
	// if idx < 0 {
	// 	rb := NewRouterBuilder(path, handlers...)
	// 	b.children = append(b.children, rb)
	// 	return rb
	// } else {
	// 	return b.children[idx]
	// }
}

func (b *RouterBuilder) innerBuild(parentHandlers []RequestHandler, parentPath string) (rtv []*RouterItem) {

	ph := make([]RequestHandler, len(parentHandlers), len(parentHandlers)+len(b.middlewares))
	copy(ph, parentHandlers)

	ph = append(ph, b.middlewares...)

	basePath := path.Join(parentPath, b.path)
	for _, itm := range b.handlers {
		i := &RouterItem{
			Method: itm.Method,
			Path:   path.Join(basePath, itm.Path),
		}
		i.Handlers = append(i.Handlers, ph...)
		i.Handlers = append(i.Handlers, itm.Handlers...)
		rtv = append(rtv, i)
	}

	for _, child := range b.children {
		rtv = append(rtv, child.innerBuild(ph, basePath)...)
	}

	return
}

func (b *RouterBuilder) GetRouterItems() []*RouterItem {
	return b.innerBuild(nil, "")
}

func (b *RouterBuilder) Build() *router.Router {

	items := b.GetRouterItems()

	r := router.New()
	r.HandleOPTIONS = true
	r.GlobalOPTIONS = cors.GlobalOPTIONS

	maxPath, maxHName := 0, 0
	for _, itm := range items {
		if len(itm.Path) > maxPath {
			maxPath = len(itm.Path)
		}
		if len(itm.HandlerName()) > maxHName {
			maxHName = len(itm.HandlerName())
		}
	}

	fmtStr := "Router[%s][%4s] %-" + fmt.Sprintf("%v", maxPath) + "s => [%d]%-" + fmt.Sprintf("%v", maxHName) + "s\n"

	for _, itm := range items {

		logger.Web.Debugf(fmtStr, b.Name(), itm.Method, itm.Path, len(itm.Handlers), itm.HandlerName())

		handlers := itm.Handlers
		r.Handle(itm.Method, itm.Path, func(ctx *fasthttp.RequestCtx) {
			defer func() {
				if err := recover(); err != nil {
					tgErrStr := ""
					errStr := fmt.Sprintf("Path: %s, Error: %s", ctx.Path(), err)
					tgErrStr += errStr + "\n"
					logger.Web.Errorln(errStr)

					errStr = fmt.Sprintf("    CallStack: %s", uruntime.CallStack(3))
					tgErrStr += errStr + "\n"
					logger.Web.Errorln(errStr)

					for _, m := range handlers {
						errStr = fmt.Sprintf("    Middlewares: %s", NameOfFunction(m))
						tgErrStr += errStr + "\n"
						logger.Web.Errorln(errStr)
					}
					tgbot.SendErrorLog(tgErrStr)

					defer func() {
						if err := recover(); err != nil {
							logger.Web.Errorf("FATAL: %s", err)
						}
					}()
					ctx.Error("", http.StatusInternalServerError)
				}
			}()

			cors.GlobalOPTIONS(ctx)

			c := &RequestCtx{
				RequestCtx: ctx,
				handlers:   handlers,
				index:      0,
			}

			c.Next()
		})
	}

	return r
}

func (b *RouterBuilder) Use(h RequestHandler) {
	b.middlewares = append(b.middlewares, h)
}

func NameOfFunction(f RequestHandler) string {
	return runtime.FuncForPC(reflect.ValueOf(f).Pointer()).Name()
}

func NewRouterBuilder(name, path string, handlers ...RequestHandler) *RouterBuilder {
	return &RouterBuilder{
		name:        name,
		path:        path,
		middlewares: handlers,
		handlers:    make(map[string]*RouterItem),
	}
}
