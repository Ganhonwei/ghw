package router_builder

import (
	"bytes"
	"compress/zlib"
	"encoding/json"
	"fmt"
	"io"
	"server/cmd/task/tgbot"
	"server/internals/configs/g"
	"server/internals/generated/core/errcode"
	"server/internals/logger"
	"server/internals/perr"
	"server/internals/utils/uaes"
	"server/internals/utils/ucache"
	"server/internals/utils/uhash"
	"server/internals/utils/ujson"
	"server/internals/utils/utime"
	"strings"

	"github.com/mitchellh/mapstructure"
	"github.com/valyala/fasthttp"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

var filterNoHost = map[string]bool{
	//上线前才添加，不需要加密的host
	"54.238.230.208": true,
	"192.168.66.200": true,
	"192.168.66.74":  true,
	// "192.168.66.167":         true,
	"192.168.66.99":          true,
	"dev-api.tigerjp.com":    true,
	"test-api.tigerjp.com":   true,
	"prod-api.tigerjp88.com": true,
}

type RequestHandler func(*RequestCtx)

type WebApiCodeGetter interface {
	GetCode() errcode.ErrCode
}

type RequestCtx struct {
	*fasthttp.RequestCtx
	handlers       []RequestHandler
	index          int
	needDecompress bool
	needCompress   bool
	dumpRequest    bool
	dumpResponse   bool
	needAES        bool
	needParam      map[string]string
	isDebug        bool
	isH5           bool
}

func (ctx *RequestCtx) Abort() {
	ctx.index = len(ctx.handlers)
}

func (ctx *RequestCtx) Next() {
	// logger.Infof("Request: %s", ctx.Path())
	for ctx.index < len(ctx.handlers) {
		idx := ctx.index
		ctx.index++
		// logger.Infof("    Call Handler: %s", nameOfFunction(ctx.handlers[idx]))
		ctx.handlers[idx](ctx)
	}
}

func (ctx *RequestCtx) BindForm(req any) error {

	params := map[string]string{}

	ctx.PostArgs().VisitAll(func(key, value []byte) {
		params[string(key)] = string(value)
	})
	return mapstructure.WeakDecode(params, req)
}

func (ctx *RequestCtx) BindJson(req proto.Message, decryptFirst bool) error {
	dump := func(data string) {
		uuid := ctx.UserValue(g.CtxRequestId)
		if ctx.isDebug {
			logger.WebDebug.Debugf("%v[%v]: WebRequest: BindJsonOK, %v Body: %v", GetCtxSessionKey(ctx), uuid, string(ctx.Path()), data)
		} else {
			logger.Web.Debugf("%v[%v]: WebRequest: BindJsonOK, %v Body: %v", GetCtxSessionKey(ctx), uuid, string(ctx.Path()), data)
		}
	}

	doit := func(data []byte, forceDump bool) ([]byte, error) {
		buf := data
		// if decryptFirst {
		// 	logger.Sys.Errorln("1111111111111111111111111111", buf)
		// 	if ctx.needDecompress {
		// 		rd, err := zlib.NewReader(bytes.NewBuffer(data))
		// 		if err != nil {
		// 			return nil, err
		// 		}

		// 		buf2, err := io.ReadAll(rd)
		// 		if err != nil {
		// 			return nil, err
		// 		}

		// 		buf = buf2
		// 	}
		// 	logger.Sys.Errorln("2222222222222222222222222222222", buf)
		// }
		//替换真实参数（只有plat才有）
		if len(ctx.needParam) > 0 {
			var real = map[string]any{}
			var out = map[string]any{}

			err := ujson.Unmarshal(buf, &real)
			if err != nil {
				logger.Sys.Errorln("dynapi real params", err)
				return nil, err
			}
			for k, v := range real {
				if ogiKey, found := ctx.needParam[k]; found {
					out[ogiKey] = v
				} else {
					out[k] = v
				}
			}
			bufjson := ujson.Marshal2(out)
			return bufjson, protojson.Unmarshal(bufjson, req)
		}
		return buf, protojson.Unmarshal(buf, req)
	}

	host := strings.ToLower(string(ctx.Request.Host()))
	lastIndex := strings.LastIndex(host, ":")
	if lastIndex > -1 {
		host = host[:lastIndex]
	}
	data := ctx.PostBody()
	if !decryptFirst {
		if ctx.needDecompress {
			rd, err := zlib.NewReader(bytes.NewBuffer(data))
			if err != nil {
				return err
			}

			buf2, err := io.ReadAll(rd)
			if err != nil {
				return err
			}

			data = buf2
			// logger.Sys.Debugln("decompress data", data)
		}
	}

	// _, ok := filterNoHost[host] //是否是不加密的
	if ctx.needAES { //对请求解密
		days := utime.DaysSinceUtcEpoch()
		for i := 0; i < 2; i++ {

			days -= int32(i)
			md, _ := GetHashByHost(fmt.Sprintf("%v%v", host, days))
			if ctx.isH5 {
				md, _ = GetHashByHost("uiolj0805lyouiryxlo97891")
			}
			key := []byte(md[:16])
			iv := []byte(md[16:])
			logger.Sys.Debugf("needAES DecryptAESCBC host:%v, days:%v, md5:%v, key:%v, iv:%v\n", host, days, md, key, iv)
			// logger.Sys.Debugf("body %v, %v", data, base64.StdEncoding.EncodeToString(data))
			dedata, err := uaes.DecryptAESCBC(data, key, iv)
			if err != nil {
				if i == 0 {
					continue
				}
				// logger.Sys.Errorln("DecryptAESCBC err", err)
				tgbot.SendErrorLog(fmt.Sprintf("%v %v,DecryptAESCBC err:%v", string(ctx.Path()), ctx.GetClientIP(), err))
				return perr.NewCodeError(errcode.ErrCode_UnknownError)
			}

			ogidata, err := doit(dedata, false)
			if err == nil {
				if ctx.dumpRequest {
					dump(string(ogidata))
				}

				return nil
			} else {
				logger.Sys.Errorln("doit err :", err)
			}
		}

		return fmt.Errorf("decr failed")

	} else {
		ogidata, err := doit(data, true)
		if ctx.dumpRequest {
			dump(string(ogidata))
		}

		return err
	}

	// if ctx.needDecompress {
	// 	rd, err := zlib.NewReader(bytes.NewBuffer(ctx.PostBody()))
	// 	if err != nil {
	// 		return err
	// 	}

	// 	buf2, err := io.ReadAll(rd)
	// 	if err != nil {
	// 		return err
	// 	}

	// 	buf = buf2
	// } else {
	// 	buf = ctx.PostBody()
	// }

	// if ctx.dumpRequest {
	// 	uuid := ctx.UserValue(g.CtxRequestId)
	// 	logger.Web.Debugf("%v[%v]: WebRequest: BindJsonOK, %v Body: %v", GetCtxSessionKey(ctx), uuid, string(ctx.Path()), string(buf))
	// }

	// return protojson.Unmarshal(buf, req)
}

func GetHashByHost(host string) (string, error) {
	return ucache.GetOrUpdateAny(ucache.KeyAesHash.P1(host), func() (string, error) {
		return uhash.SumMD5(host), nil
	}, g.PlatformContentCacheLevelAes)
}

func (ctx *RequestCtx) DoError(err error) {
	code := errcode.ErrCode_Failed
	message := err.Error()
	if codeGetter, ok := err.(WebApiCodeGetter); ok {
		code = codeGetter.GetCode()
	}
	ctx.DoCodeMessage(code, message)
}

func (ctx *RequestCtx) DoCode(code errcode.ErrCode) {
	ctx.DoCodeMessage(code, errcode.ErrCode_name[int32(code)])
}

func (ctx *RequestCtx) DoCodeMessage(code errcode.ErrCode, message string) {
	ctx.DoResult(code, nil, message)
}

func (ctx *RequestCtx) DoProtobuf(data proto.Message, host string) {
	result := ujson.Marshal2(data)
	ctx.DoResult(errcode.ErrCode_Ok, result, "")
}

func (ctx *RequestCtx) DoErrorWithProtobuf(code errcode.ErrCode, data proto.Message) {
	result, _ := protojson.Marshal(data)
	ctx.DoResult(code, result, "")
}

func (ctx *RequestCtx) DoResult(code errcode.ErrCode, result json.RawMessage, message string) {

	resp := struct {
		Code    errcode.ErrCode `json:"code"`
		Result  json.RawMessage `json:"result,omitempty"`
		Message string          `json:"message,omitempty"`
	}{
		Code:    code,
		Result:  result,
		Message: message,
	}

	jdata, _ := json.Marshal(resp)
	if ctx.dumpResponse {
		if ctx.isDebug {
			logger.WebDebug.Debugf("DoResult: %v => %v", string(ctx.Path()), string(jdata))
		} else {
			logger.Web.Debugf("DoResult: %v => %v", string(ctx.Path()), string(jdata))
		}
	}

	host := strings.ToLower(string(ctx.Request.Host()))
	lastIndex := strings.LastIndex(host, ":")
	if lastIndex > -1 {
		host = host[:lastIndex]
	}

	// if ctx.needCompress {

	// 	b := bytes.NewBuffer(nil)
	// 	zw := zlib.NewWriter(b)
	// 	_, _ = zw.Write(jdata)
	// 	zw.Close()

	// 	jdata = b.Bytes()
	// 	// jdata2 := base64.StdEncoding.EncodeToString(jdata)
	// 	// jdata, _ = base64.StdEncoding.DecodeString(jdata2)
	// 	// logger.Sys.Debugf("needAES needCompress jdata:%v\n", hex.EncodeToString(jdata))
	// }

	// _, ok := filterNoHost[host] //是否是不加密的
	if ctx.needAES { //对请求加密
		days := utime.DaysSinceUtcEpoch()
		md, _ := GetHashByHost(fmt.Sprintf("%v%v", host, days))
		if ctx.isH5 {
			md, _ = GetHashByHost("uiolj0805lyouiryxlo97891")
		}
		key := []byte(md[:16])
		iv := []byte(md[16:])
		dedata, err := uaes.EncryptAESCBC(jdata, key, iv)
		if err == nil {
			jdata = dedata
		}

		// logger.Sys.Debugf("needAES EncryptAESCBC host:%v, days:%v, md5:%v data: %v\n",
		// 	host, days, md, base64.StdEncoding.EncodeToString(jdata))
	}

	if ctx.needCompress {

		b := bytes.NewBuffer(nil)
		zw := zlib.NewWriter(b)
		_, _ = zw.Write(jdata)
		zw.Close()

		jdata = b.Bytes()
		// jdata2 := base64.StdEncoding.EncodeToString(jdata)
		// jdata, _ = base64.StdEncoding.DecodeString(jdata2)
		// logger.Sys.Debugf("needAES needCompress jdata:%v\n", hex.EncodeToString(jdata))
	}

	ctx.Success("application/json", jdata)
}

func (ctx *RequestCtx) ResponseUnmarshal() errcode.ErrCode {
	resp := struct {
		Code errcode.ErrCode `json:"code"`
	}{}
	_ = json.Unmarshal(ctx.Response.Body(), &resp)

	return resp.Code
}

func (ctx *RequestCtx) GetClientIP() string {
	clientIP := string(ctx.Request.Header.Peek("X-Forwarded-For"))
	if index := strings.IndexByte(clientIP, ','); index >= 0 {
		clientIP = clientIP[0:index]
	}

	clientIP = strings.TrimSpace(clientIP)
	if len(clientIP) > 0 {
		return clientIP
	}
	clientIP = strings.TrimSpace(string(ctx.Request.Header.Peek("X-Real-Ip")))
	if len(clientIP) > 0 {
		return clientIP
	}

	return ctx.RemoteIP().String()
}

func (ctx *RequestCtx) GetCFIPCountry() string {
	country := string(ctx.Request.Header.Peek("CF-IPCountry"))
	if len(country) > 0 {
		return country
	}
	return ""
}
