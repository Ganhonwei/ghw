package usession

import (
	"time"

	"github.com/esimov/gogu/cache"
)

// type Session struct {
// 	Id      string
// 	IsValid bool
// }

var (
	c = cache.New[string, bool](cache.NoExpiration, 1*time.Minute)
)

func CheckSession(key string) (found, valid bool) {
	item, err := c.Get(key)
	if item == nil || err != nil {
		return false, false
	}

	return true, item.Val()
}

func SetSession(key string, valid bool) {
	_ = c.Update(key, valid, 15*time.Minute)
}
