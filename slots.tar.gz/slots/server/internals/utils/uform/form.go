package uform

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/samber/lo"
)

func HideMiddName(d string) (r string) {
	count := len(d)
	if count < 3 {
		return d
	}
	return d[:2] + "*****" + d[len(d)-2:]
}

func HideMiddMobile(d string) (r string) {
	count := len(d)
	if count < 5 {
		return d
	}
	return d[:3] + "******" + d[len(d)-2:]
}

func HideMiddUserId(id int64) (r string) {
	d := fmt.Sprintf("%v", id)
	count := len(d)
	if count < 5 {
		return d
	}
	return d[:3] + "******" + d[len(d)-2:]
}

func CompareVersion(old, new string) bool {

	const maxVerLen = 3

	stoi := func(v string, _ int) int {
		vv, err := strconv.Atoi(v)
		if err != nil {
			return 0
		}
		return vv
	}
	nv := lo.Map(strings.Split(new, "."), stoi)
	ov := lo.Map(strings.Split(old, "."), stoi)

	padding := func(v []int) []int {
		if len(v) < maxVerLen {
			v = append(v, make([]int, maxVerLen-len(v))...)
		}
		return v
	}
	nvs := padding(nv)
	ovs := padding(ov)
	// 1.0
	// 1.0.1

	for i := 0; i < maxVerLen; i++ {
		if nvs[i] == ovs[i] {
			continue
		}

		return nvs[i] > ovs[i]
	}
	return false
}

func CompareVersion2(a, b string) int {

	const maxVerLen = 3

	stoi := func(v string, _ int) int {
		vv, err := strconv.Atoi(v)
		if err != nil {
			return 0
		}
		return vv
	}
	nv := lo.Map(strings.Split(a, "."), stoi)
	ov := lo.Map(strings.Split(b, "."), stoi)

	padding := func(v []int) []int {
		if len(v) < maxVerLen {
			v = append(v, make([]int, maxVerLen-len(v))...)
		}
		return v
	}
	avs := padding(nv)
	bvs := padding(ov)
	// 1.0
	// 1.0.1

	for i := 0; i < maxVerLen; i++ {
		if avs[i] == bvs[i] {
			continue
		}

		if avs[i] > bvs[i] {
			return 1
		}
		return -1
	}
	return 0
}
