package uform

import (
	"fmt"
	"server/internals/utils/uhash"
	"server/internals/utils/uhttp"
	"server/internals/utils/ujson"
	"server/internals/utils/urand"
	"server/internals/utils/uslice"
	"server/internals/utils/utime"
	"math/rand"
	"strconv"
	"strings"
	"testing"
)

func TestCompareVersion(t *testing.T) {
	// tt := utime.ParseJakartaTimeByInt64(20240626)
	// fmt.Println(tt)
	// start, end := utime.GetWeekStartAndEnd(utime.ParseJakartaUnsafed("2024-07-28"))
	// fmt.Println(start, "~~", end)

	// start2, end2 := utime.GetMonthStartAndEnd(utime.ParseJakartaUnsafed("2024-07-28"))
	// fmt.Println(start2, "~~", end2)
}

// 构建每天首充用户未来7天充值率的SQL
func TestStatSQL(t *testing.T) {
	startfmt := "%v"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 30; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		for i := 1; i < 8; i++ {
			nextfmt := now.AddDate(0, 0, i).Format(utime.LayoutADate)
			s := "(select count(b.account_id) from (select DISTINCT a.account_id from log_order_recharges a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.account_id in(select t.account_id from log_order_recharges t where t.is_first=1 and date_format(t.created_at,'%%Y-%%m-%%d')='%v')) b)"
			sql := fmt.Sprintf(s, nextfmt, nowfmt)
			sqls = append(sqls, sql)
		}
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, fmt.Sprintf("select %v", sqlstr))
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

func TestKwarAcct(t *testing.T) {

	type acctReq struct {
		Mail    string `json:"mail"`
		Pwd     string `json:"pwd"`
		Yzm     string `json:"yzm"`
		AffCode string `json:"affCode"`
		Cdkey   string `json:"cdkey"`
	}

	type acctResp struct {
		Code    int    `json:"code,omitempty"`
		Message string `json:"message,omitempty"`
	}

	acct := map[string]string{
		"nicecoin":    "nicecoin",
		"tothemoon":   "tothemoo",
		"digcoin":     "digcoin0",
		"BNBchain":    "BNBchain",
		"Ethereum":    "Ethereum",
		"Polygon":     "Polygon0",
		"TRON":        "TRON0000",
		"Avalanche":   "Avalanch",
		"EOS":         "EOS00000",
		"Arbitrum":    "Arbitrum",
		"Fantom":      "Fantom00",
		"Optimism":    "Optimism",
		"Cronos":      "Cronos00",
		"Tezos":       "Tezos000",
		"ThunderCore": "ThunderC",
	}

	url := "https://k3-api-prod.degengame.cc/plat/auth/v2/email_register"
	// url = "https://k3-api-test.degengame.cc/plat/auth/v2/email_register"
	for k, v := range acct {
		for i := 1; i <= 200; i++ {
			mail := fmt.Sprintf("%v%03d@dgga.dme", k, i)
			reqParam := &acctReq{
				Mail:    mail,
				Pwd:     v,
				Yzm:     "",
				AffCode: "",
				Cdkey:   "",
			}
			params := ujson.MarshalToString2(reqParam)
			data, err := uhttp.Post(url, "application/json; charset=UTF-8", []byte(params))
			if err != nil {
				fmt.Println(err)
				continue
			}
			resp, err := ujson.JsonStringToObj[acctResp](string(data))
			if err != nil {
				fmt.Println(err)
				continue
			}
			if resp.Code > 0 {
				fmt.Println("失败", reqParam.Mail, " : ", reqParam.Pwd)
			} else {
				fmt.Println(reqParam.Mail, " : ", reqParam.Pwd)
			}
		}
	}
}

func TestRandSeven(t *testing.T) {
	for i := 0; i < 10; i++ {
		r := rand.Intn(7) + 1
		RandSeven2(1, 777777, r)
	}
	// fmt.Println("***************")
	// for i := 0; i < 10; i++ {
	// 	RandSeven2(100, 1000, 2)
	// }
}

func RandSeven2(min, max, ji int) {
	if ji > 6 && ji < 1 {
		return
	}
	seven := []int{1, 2, 3, 4, 5, 6}
	rate := seven[ji-1]
	rates := make([]int, 10)
	for i := 0; i < rate; i++ {
		rates = append(rates, 7)
	}
	num := urand.RandRange(int64(min), int64(max))
	numstr := strconv.Itoa(int(num))
	numstr = strings.ReplaceAll(numstr, "7", "6")
	dis := strings.Split(numstr, "")
	indexs := RandIndex(len(dis), ji)
	for _, v := range indexs {
		dis[v] = "7"
	}
	fmt.Println("随机金额", numstr, "命中金额", strings.Join(dis, ""))
}

func RandIndex(m, j int) []int {
	dis := []int{}
	for i := 0; i < m; i++ {
		dis = append(dis, i)
	}
	uslice.Shuffle(dis)
	return dis[:j]
}

func RandSeven(min, max int) {
	seven := []int{7, 77, 777, 7777, 77777, 777777}
	rate := []int{1, 2, 3, 4, 5, 6}
	sub := max - min
	index := len(fmt.Sprintf("%v", sub))

	rands := make([]int, 10)
	for i := 0; i < index; i++ {
		for m := 0; m < rate[i]; m++ {
			rands = append(rands, seven[i])
		}
	}

	uslice.Shuffle(rands)
	ming := rands[0]
	mindex := len(fmt.Sprintf("%v", ming))

	rannum := urand.RandRange(int64(min), int64(max))
	rannumstr := strconv.Itoa(int(rannum))

	dis := []string{}
	mindex2 := 0
	for i := index; i > 0; i-- {
		s := rannumstr[i-1 : i]
		if ming == 0 {
			if s == "7" {
				s = "6" //可以替换为任意非7
			}
			dis = append(dis, s)
			continue
		}
		if s == "7" {
			if mindex2 == mindex { //7替换完了
				s = "6" //可以替换为任意非7
			}
			dis = append(dis, s)
			mindex2++
		} else {
			if mindex2 == mindex { //7替换完了
				dis = append(dis, s)
			} else {
				dis = append(dis, "7")
				mindex2++
			}
		}
	}
	dis2 := []string{}
	for i := index; i > 0; i-- {
		dis2 = append(dis2, dis[i-1])
	}
	fmt.Printf("最多%v个7, 随机%v , 命中%v , 中奖%v\n", index, rannumstr, ming, strings.Join(dis2, ""))
}

func TestWeiYs(t *testing.T) {
	fmt.Println(0 / 3)
	fmt.Println(1 / 3)
	fmt.Println(2 / 3)
	fmt.Println(3 / 3)
	fmt.Println(4 / 3)
	fmt.Println(5 / 3)
	fmt.Println(6 / 3)
	fmt.Println(7 / 3)
	fmt.Println(8 / 3)
}

// 被推广人留存
func TestStatSQL2(t *testing.T) {
	startfmt := "2024-07-02"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 67; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v', (select count(t.id) from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留,(select count(t.id) from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留付费"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首日总输赢正向付费用户
func TestStatSQL3(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		// s := "select '%v', (select count(t.id) from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留,(select count(t.id) from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留付费"
		s := "select '%v',(select count(a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount>0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id)) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount>0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount>0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首日总输赢负向付费用户
func TestStatSQL4(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		// s := "select '%v', (select count(t.id) from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t where date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留,(select count(t.id) from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0) 付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 次留付费,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.account_id from account_agents t left join accounts a on a.id=t.account_id where a.total_recharge_amount>0 and date_format(t.created_at,'%%Y-%%m-%%d')='%v' and t.up_level_agent>0)) 七留付费"
		s := "select '%v',(select count(a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount<0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id)) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount<0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and a.total_win_amount<0 and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首日破产付费用户
func TestStatSQL5(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v',(select count(t.id) from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id)) union select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1))) t) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.id from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id)) union select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1))) t)) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.id from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id)) union select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id) and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1))) t)) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首次破产后当日有充值过付费用户
func TestStatSQL6(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v',(select count(t.id) from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1))) t) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1)))) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)>1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.before_balance<100000 and b.id =(select aa.id from account_amounts aa where aa.amount_type=1 and date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id order by aa.id asc limit 1,1)))) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首次破产后当日未充值过付费用户
func TestStatSQL7(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v',(select count(t.id) from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id))) t) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select t.id from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id))) t)) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select t.id from (select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and 1=(select count(aa.id)=1 from account_amounts aa where aa.amount_type=1 and aa.account_id=a.id and date_format(aa.created_at,'%%Y-%%m-%%d')='%v') and exists(select b.id from account_amounts b where b.after_balance<100000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id))) t)) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 首日背包有足够金额付费用户(大于5000)
func TestStatSQL8(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v',(select count(a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance>500000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id))) 人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance>500000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id)))) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_recharges l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id) and exists(select b.id from account_amounts b where b.after_balance>500000 and b.id =(select max(aa.id) from account_amounts aa where date_format(aa.created_at,'%%Y-%%m-%%d')='%v' and aa.account_id=a.id)))) 七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

// 未来至少提现过1次
func TestStatSQL9(t *testing.T) {
	startfmt := "2024-06-01"
	start := utime.ParseJakartaUnsafed(startfmt)
	dates := []string{}
	for m := 0; m < 100; m++ {
		now := start.AddDate(0, 0, m)
		nowfmt := now.Format(utime.LayoutADate)
		sqls := []string{}
		s := "select '%v',(select count(DISTINCT a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id)) 首日提现付费人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v' and l.is_first=1 and l.account_id=a.id))) 七留,(select count(DISTINCT a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and NOT exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v'  and l.account_id=a.id) and a.vip>0) 首日未提现付费人数,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and !exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v'  and l.account_id=a.id) and a.vip>0)) 未提现付费次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and !exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')='%v'  and l.account_id=a.id) and a.vip>0)) 未提现付费七留,(select count(DISTINCT a.id) from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')<>'%v'  and l.account_id=a.id) and a.vip>0) 未来至少提现过1次,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 1 day) and a.account_id in(select  a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')<>'%v'  and l.account_id=a.id) and a.vip>0)) 未来至少提现过1次次留,(select count(DISTINCT a.account_id) from log_account_actives a where date_format(a.created_at,'%%Y-%%m-%%d')=DATE_ADD('%v',INTERVAL 6 day) and a.account_id in(select  a.id from accounts a where date_format(a.created_at,'%%Y-%%m-%%d')='%v' and exists(select l.id from log_order_withdraws l where date_format(l.created_at,'%%Y-%%m-%%d')<>'%v'  and l.account_id=a.id) and a.vip>0)) 未来至少提现过1次七留"
		sql := fmt.Sprintf(s, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt, nowfmt)
		sqls = append(sqls, sql)
		sqlstr := strings.Join(sqls, ",")
		dates = append(dates, sqlstr)
	}
	data := strings.Join(dates, "\nunion\n")
	fmt.Println(data)
}

func TestHkPay(t *testing.T) {
	p := "20000https://dev-hide.tigerjp.com/callback/hkpay/rechargeDANATiger_d3devmod17285409899406025aa4fc3baf4b595040c14e8025f31362"
	hash := uhash.SumMD5(p)
	fmt.Println("md5", hash)

	p2 := "Tiger_d3devmod17285493409423027f9361b937cc20be73749ec014bdd9f6"
	hash2 := uhash.SumSHA256(p2)
	fmt.Println("sha256", hash2)

	// (amount + channelCode + email+ merchantCode + orderNumber+ phone + userName + md5_key)
	p3 := "20000DANApanda_pawo@yahoo.comTiger_d3devmod17285501029427040812992102Kumala Dewi5aa4fc3baf4b595040c14e8025f31362"
	hash3 := uhash.SumMD5(p3)
	fmt.Println("md5回调", hash3)

	// SHA256(amount + bankAccount+ bankCode + channelCode + email+ merchantCode + orderNumber+ phone + userName + sha256_key)
	p4 := "20000100100100DANAALLpanda_pawo@yahoo.comTiger_d3devmod17285511419434020812992102Kumala Dewi7f9361b937cc20be73749ec014bdd9f6"
	hash4 := uhash.SumSHA256(p4)
	fmt.Println("sha256回调", hash4)

}

func TestRiqi(t *testing.T) {
	today := utime.ParseJakartaTime("2024-10-13 20:12:12", utime.LayoutA)
	fmt.Println(utime.GetWeekStartAndEnd(today))
	fmt.Println(utime.GetWeekStartAndEndNew(today))

	for i := 0; i < 30; i++ {
		fmt.Print(urand.RandRange(10, 15), " ")
	}
	fmt.Println("")
	for i := 0; i < 30; i++ {
		fmt.Print(urand.RandRange(1, 15), " ")
	}
	fmt.Println("")
	for i := 0; i < 30; i++ {
		fmt.Print(urand.RandRange(100, 200), " ")
	}
}
