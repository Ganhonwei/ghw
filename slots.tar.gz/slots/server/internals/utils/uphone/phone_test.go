package uphone

import (
	"testing"
)

func TestCheckPhone(t *testing.T) {

	type args struct {
		phone string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{name: "+8618187654321", args: args{phone: "+8613887654321"}, want: true},
		{name: "8618187654321", args: args{phone: "8613887654321"}, want: true},
		{name: "18187654321", args: args{phone: "13887654321"}, want: true},
		{name: "85518187654321", args: args{phone: "85513887654321"}, want: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got, ok := CheckPhone(tt.args.phone, true); ok != tt.want {
				t.Errorf("CheckPhone() = %v, want %v", got, tt.want)
			}
		})
	}
}
