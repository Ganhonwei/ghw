package uphone

import (
	"server/internals/utils/urand"
	"server/internals/utils/utest"
	"log"

	"github.com/nyaruka/phonenumbers"
)

var (
	defRegionCode = "CN"
)

var phoneMinPrefix = map[string]int{
	//测试号段
	"62999": 14,
	//TELKOMSEL
	"62852": 13,
	"62853": 13,
	"62811": 11,
	"62812": 12,
	"62813": 13,
	"62821": 13,
	"62822": 13,
	"62823": 13,
	"62851": 13,
	//INDOSAT - IOH
	"62855": 11,
	"62856": 11,
	"62857": 13,
	"62858": 13,
	"62814": 13,
	"62815": 12,
	"62816": 12,
	//XL Axiata
	"62817": 11,
	"62818": 11,
	"62819": 11,
	"62859": 13,
	"62877": 13,
	"62878": 13,
	//AXIS - AXIATA
	"62831": 11,
	"62832": 11,
	"62833": 11,
	"62838": 12,
	"62839": 13,
	//HUTCH - 3 - IOH
	"62895": 13,
	"62896": 12,
	"62897": 12,
	"62898": 12,
	"62899": 12,
	//SMARTFREN
	"62881": 12,
	"62882": 12,
	"62883": 12,
	"62884": 12,
	"62885": 12,
	"62886": 12,
	"62887": 12,
	"62888": 12,
	"62889": 12,
}
var phoneMaxPrefix = map[string]int{
	//测试号段
	"62999": 14,
	//TELKOMSEL
	"62852": 13,
	"62853": 13,
	"62811": 12,
	"62812": 13,
	"62813": 13,
	"62821": 13,
	"62822": 13,
	"62823": 13,
	"62851": 13,
	//INDOSAT - IOH
	"62855": 13,
	"62856": 13,
	"62857": 13,
	"62858": 13,
	"62814": 13,
	"62815": 13,
	"62816": 13,
	//XL Axiata
	"62817": 13,
	"62818": 13,
	"62819": 13,
	"62859": 13,
	"62877": 13,
	"62878": 13,
	//AXIS - AXIATA
	"62831": 13,
	"62832": 13,
	"62833": 13,
	"62838": 13,
	"62839": 13,
	//HUTCH - 3 - IOH
	"62895": 14,
	"62896": 13,
	"62897": 13,
	"62898": 13,
	"62899": 13,
	//SMARTFREN
	"62881": 14,
	"62882": 14,
	"62883": 14,
	"62884": 14,
	"62885": 14,
	"62886": 14,
	"62887": 14,
	"62888": 14,
	"62889": 14,
}

func SetDefaultRegionCode(regionCode string) {

	// check regionCode is valid
	if _, found := phonenumbers.GetSupportedRegions()[regionCode]; !found {
		log.Panicf("unsupported region: %v", regionCode)
	}

	defRegionCode = regionCode
}

func CheckPhone(phone string, testIsPass bool) (mobile string, r bool) {
	//2023.12.13 测试号段不准通过校验，来控制不准绑定
	// 测试号段直接允许通过
	phone2, ok := utest.IsTestPhone(phone)
	if ok {
		return phone2, testIsPass
	}
	//测试账号
	if utest.IsTestWorkAccount(phone) {
		return phone, testIsPass
	}
	p, err := phonenumbers.Parse(phone, defRegionCode)
	if err != nil {
		return phone, false
	}
	mobile, r = phonenumbers.Format(p, phonenumbers.E164), phonenumbers.IsValidNumber(p)
	if r { //手机号段验证
		curr := len(mobile) - 1
		pre := mobile[1:6]
		min, ok := phoneMinPrefix[pre]
		if ok {
			if curr < min { //小于最小长度
				return phone, false
			}
		}
		max, ok2 := phoneMaxPrefix[pre]
		if ok2 {
			if curr > max { //大于最大长度
				return phone, false
			}
		}
	}
	return mobile, r
}

func IsValidNumber(phone string) bool {
	// 测试号段直接允许通过
	_, ok := utest.IsTestPhone(phone)
	if ok {
		return true
	}
	//测试账号
	if utest.IsTestWorkAccount(phone) {
		return true
	}
	p, err := phonenumbers.Parse(phone, defRegionCode)
	if err != nil {
		return false
	}
	return phonenumbers.IsValidNumber(p)
}

func RandomInvalidNumber() string {
	return urand.LowerStrings(16)
}

func HideMiddStr(d string) (r string) {
	count := len(d)
	if count < 6 {
		return d
	}
	return d[:2] + "*****" + d[len(d)-2:]
}
