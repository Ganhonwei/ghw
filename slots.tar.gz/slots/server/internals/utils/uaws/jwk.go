package uaws

import (
	"context"
	"server/internals/logger"
	"server/internals/utils/ujson"
	"time"

	"github.com/lestrrat-go/jwx/v2/jwk"
	"github.com/lestrrat-go/jwx/v2/jws"
)

var (
	ctx, cancel = context.WithCancel(context.Background())
	jwkCache    *jwk.Cache
	awsJkwsUrl  = ""
)

type AwsIdToken struct {
	Sub             string `json:"sub"`
	EmailVerified   bool   `json:"email_verified"`
	Iss             string `json:"iss"`
	CognitoUsername string `json:"cognito:username"`
	OriginJti       string `json:"origin_jti"`
	Aud             string `json:"aud"`
	EventID         string `json:"event_id"`
	TokenUse        string `json:"token_use"`
	AuthTime        int    `json:"auth_time"`
	Nickname        string `json:"nickname"`
	Exp             int    `json:"exp"`
	Iat             int    `json:"iat"`
	Jti             string `json:"jti"`
	Email           string `json:"email"`
}

func Start(awsJwksUrl string) {

	awsJkwsUrl = awsJwksUrl

	jwkCache = jwk.NewCache(ctx)
	err := jwkCache.Register(awsJwksUrl, jwk.WithRefreshInterval(30*time.Minute))
	if err != nil {
		logger.Errorf("failed to Register aws JWKS: %s\n", err)
		panic("uaws jwk init failed")
	}
	for {
		_, err = jwkCache.Refresh(ctx, awsJkwsUrl)
		if err != nil {
			logger.Errorf("failed to refresh aws JWKS: %s\n", err)
			// panic("uaws jwk init failed")
			time.Sleep(time.Second)
			continue
		}

		break
	}
	logger.Infof("Load AwsJWKs data ok: %v", awsJwksUrl)
}

func Stop() {
	cancel()
}

func init() {
	// 	https://cognito-idp.us-east-1.amazonaws.com/us-east-1_gXyoCI19r/.well-known/jwks.json
}

func VerifySign(token string) ([]byte, bool) {
	buf, err := jws.Verify([]byte(token),
		jws.WithKeySet(jwk.NewCachedSet(jwkCache, awsJkwsUrl), jws.WithRequireKid(true)),
	)
	if err != nil {
		return nil, false
	}

	return buf, true
}

func VerifyIdToken(token string) (*AwsIdToken, bool) {

	buf, ok := VerifySign(token)
	if !ok {
		return nil, false
	}

	rtv := AwsIdToken{}
	err := ujson.Unmarshal(buf, &rtv)
	if err != nil {
		logger.Errorf("VerifyIdToken: Payload Parse Failed: %#v\n", err)
		return nil, false
	}

	return &rtv, true
}
