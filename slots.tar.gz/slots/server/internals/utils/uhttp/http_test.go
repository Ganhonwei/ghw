package uhttp

import (
	"reflect"
	"testing"
)

func TestGetIfCompressed(t *testing.T) {
	type args struct {
		url string
	}
	tests := []struct {
		name    string
		args    args
		want    []byte
		wantErr bool
	}{}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetIfCompressed(tt.args.url)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetIfCompressed() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetIfCompressed() = %v, want %v", got, tt.want)
			}
		})
	}
}
