package uhttp

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"net/url"

	"server/internals/utils/ujson"

	"github.com/valyala/fasthttp"
)

var (
	client *http.Client
)

func init() {
	client = &http.Client{}
}

func GetHost(data string) string {
	u, err := url.Parse(data)
	if err != nil {
		return ""
	}
	return u.Host
}

func GetCsv(url string) ([]byte, error) {
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}
	bs, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	return bs, nil
}

func Get(url string) ([]byte, error) {
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}

func GetIfCompressed(url string) ([]byte, error) {

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	rsp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(rsp)

	req.SetRequestURI(url)
	req.Header.Set(fasthttp.HeaderAcceptEncoding, "br, gzip, deflate")

	if err := fasthttp.Do(req, rsp); err != nil {
		return nil, err
	}

	switch string(rsp.Header.Peek(fasthttp.HeaderContentEncoding)) {
	case "br":
		return rsp.BodyUnbrotli()
	case "gzip":
		return rsp.BodyGunzip()
	case "deflate":
		return rsp.BodyInflate()
	}

	return rsp.Body(), nil
}

func GetCompressedObject[T any, TPtr *T](url string) (TPtr, error) {
	data, err := GetIfCompressed(url)
	if err != nil {
		return nil, err
	}

	return ujson.JsonStringToObj[T, TPtr](string(data))
}

func Post(url string, contentType string, data []byte) ([]byte, error) {
	resp, err := client.Post(url, contentType, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}

func PostWithHeader(url string, headers map[string]string, data []byte) ([]byte, error) {

	req, err := http.NewRequest("POST", url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}

func PostWithHeaderByMg(url string, headers map[string]string, data []byte, okCode int) ([]byte, error) {

	req, err := http.NewRequest("POST", url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != okCode {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}

func GetWithHeader(url string, headers map[string]string, data []byte) ([]byte, error) {

	req, err := http.NewRequest("GET", url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}

func PatchWithHeader(url string, headers map[string]string, data []byte) ([]byte, error) {

	req, err := http.NewRequest("PATCH", url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("http code %v", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}
