package uaes

import (
	"fmt"
	"testing"

	"github.com/samber/lo"
)

func TestEncrypt(t *testing.T) {

	// data := "{\"list\":[\"192.168.66.99:60000\",\"www.google.com\"]}"
	// data = "{}"
	// key := "148d087a901826cbc07573c5fcaa1fb6"

	// encData, err := EncryptAESGCM([]byte(data), key)
	// if err != nil {
	// 	fmt.Println("EncryptAESGCM err", err)
	// } else {
	// 	enc := hex.EncodeToString(encData)
	// 	fmt.Println("加密后", enc)
	// 	dec, err := hex.DecodeString(enc)
	// 	if err != nil {
	// 		fmt.Println("DecodeString err", err)
	// 	}
	// 	decData, err := DecryptAESGCM([]byte(dec), key)
	// 	if err != nil {
	// 		fmt.Println("err", err)
	// 	} else {
	// 		fmt.Println("解密后", string(decData))
	// 	}
	// }

	whitelist := map[string]bool{
		"aaa": true,
		"bbb": true,
		"ccc": true,
	}
	fmt.Println(lo.Keys(whitelist))

}
