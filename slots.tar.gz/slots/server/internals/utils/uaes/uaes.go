package uaes

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"server/internals/utils/uhash"
)

// AESCBC加密
func EncryptAESCBC(plainData []byte, key, iv []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, errors.Join(fmt.Errorf("AESEncrypt: create cipher faield: "), err)
	}
	cbc := cipher.NewCBCEncrypter(block, iv)
	plainData = PKCS5Padding(plainData, block.BlockSize())
	crypted := make([]byte, len(plainData))
	cbc.CryptBlocks(crypted, plainData)
	crypted2 := base64.StdEncoding.EncodeToString(crypted)
	crypted, _ = base64.StdEncoding.DecodeString(crypted2)
	return crypted, nil
}

// AESCBC解密
func DecryptAESCBC(crypt []byte, key, iv []byte) ([]byte, error) {
	if len(crypt) == 0 {
		return nil, fmt.Errorf("crypt content empty")
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, errors.Join(fmt.Errorf("AESDecrypt: create cipher faield: "), err)
	}

	cbc := cipher.NewCBCDecrypter(block, iv)
	decrypted := make([]byte, len(crypt))
	cbc.CryptBlocks(decrypted, crypt)

	data, err := PKCS5Trimming(decrypted)
	return data, err
}

func PKCS5Padding(ciphertext []byte, blockSize int) []byte {
	padding := blockSize - len(ciphertext)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}

func PKCS5Trimming(data []byte) ([]byte, error) {
	paddingLength := int(data[len(data)-1])
	if paddingLength <= 0 || paddingLength > len(data) {
		return data, fmt.Errorf("PKCS5Trimming paddingLength error")
	}
	return data[:(len(data) - paddingLength)], nil
}

// AESGCM加密
func EncryptAESGCM(plaintext []byte, host string) ([]byte, error) {
	key := []byte(uhash.SumMD5(host))
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}

	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

// AESGCM解密
func DecryptAESGCM(ciphertext []byte, host string) ([]byte, error) {
	key := []byte(uhash.SumMD5(host))
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}

	nonceSize := gcm.NonceSize()
	if len(ciphertext) < nonceSize {
		return nil, errors.New("ciphertext too short")
	}

	nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
	return gcm.Open(nil, nonce, ciphertext, nil)
}

// AESGCM解密
func DecryptAESGCMWithNonce(ciphertext []byte, k, n []byte) ([]byte, error) {
	block, err := aes.NewCipher(k)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	if len(n) != gcm.NonceSize() {
		return nil, errors.New("nonce invalid")
	}

	return gcm.Open(nil, n, ciphertext, nil)
}

// AES加密（CTR模式）
func EncryptAESCTR(plainText []byte, key, iv []byte) ([]byte, error) {
	//指定加密算法，返回一个AES算法的Block接口对象
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	//指定分组模式，返回一个BlockMode接口对象
	blockMode := cipher.NewCTR(block, iv)
	//加密连续数据库
	cipherText := make([]byte, len(plainText))
	blockMode.XORKeyStream(cipherText, plainText)
	//返回密文
	return cipherText, nil
}

// AES解密（CTR模式）
func DecryptAESCTR(cipherText []byte, key, iv []byte) ([]byte, error) {
	//指定解密算法，返回一个AES算法的Block接口对象
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	//指定初始化向量IV,和加密的一致
	//指定分组模式，返回一个BlockMode接口对象
	blockMode := cipher.NewCTR(block, iv)
	//解密
	plainText := make([]byte, len(cipherText))
	blockMode.XORKeyStream(plainText, cipherText)
	return plainText, nil
}

// DESEncrypt 使用 DES-ECB 加密
func EncryptDESECB(src, key []byte) ([]byte, error) {
	if len(key) > 8 {
		key = key[:8]
	}
	block, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	src = PKCS5Padding(src, block.BlockSize())
	encrypted := make([]byte, len(src))

	// ECB 方式加密
	for bs, be := 0, block.BlockSize(); bs < len(src); bs, be = bs+block.BlockSize(), be+block.BlockSize() {
		block.Encrypt(encrypted[bs:be], src[bs:be])
	}
	return encrypted, nil
}
