package ustring

import (
	"server/internals/utils/uslice"
	"strings"
)

func ContainsCaseIncentive(lst []string, s string) bool {
	return uslice.ContainFunc(lst, func(e string) bool { return strings.EqualFold(e, s) })
}

func Contains(slice []string, str string) bool {
	for _, v := range slice {
		if v == str {
			return true
		}
	}
	return false
}
