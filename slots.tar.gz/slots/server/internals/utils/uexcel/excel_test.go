package uexcel

import (
	"context"
	"fmt"
	"server/ent/core_db"
	"server/internals/configs/cfg_plat"
	"server/internals/db/dbcore"
	"testing"
)

func TestMain(m *testing.T) {
	cfg_plat.Plat.LoadConfig("../../../confs/dev_plat.yaml")
	dbcore.Open(cfg_plat.Plat.CoreDB)

	f, err := dbcore.Cli.GameRecord.Query().First(context.Background())
	if err != nil {
		return
	}

	bulk := make([]*core_db.GameRecordCreate, 0)
	for i := 0; i < 1000000; i++ {
		bulk = append(bulk, dbcore.Cli.GameRecord.Create().
			SetAccountID(f.AccountID).
			SetBetAmount(f.BetAmount).
			SetBetNum(fmt.Sprint("", f.BetNum, i)).
			SetBetResultID(f.BetResultID).
			SetBetTime(f.BetTime).
			SetChannelID(f.ChannelID).
			SetCompanyID(f.CompanyID).
			SetCompanyName(f.CompanyName).
			SetGameID(f.GameID).
			SetGameName(f.GameName))
		if len(bulk) >= 1000 {
			err := dbcore.Cli.GameRecord.CreateBulk(bulk...).Exec(context.Background())
			if err != nil {
				return
			}
			bulk = make([]*core_db.GameRecordCreate, 0)
		}
	}
}
