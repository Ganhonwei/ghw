package uexcel

import (
	"errors"
	"fmt"
	"server/internals/logger"
	"server/internals/utils/utime"
	"os"
	"path/filepath"
	"reflect"

	"github.com/xuri/excelize/v2"
)

var ExportPath string = "temp_excel/"
var MaxSize int64 = 1024 * 1024 * 1024 // 1G
var MaxRow int64 = 1000000

func ExportExeclByFunc[Bean any, C any](f func(c C) ([]Bean, C), condition C, sheetName string) (string, error) {
	now := utime.JakartaTime().UnixMilli()
	b, lastPoint := f(condition)
	if len(b) <= 0 {
		return "", errors.New("data is empty")
	}

	//创建文件夹
	if err := ensureDirExists(); err != nil {
		logger.Errorf("make dir fail:%v", err)
		return "", err
	}

	// 判断文件夹大小
	if size, err := getDirSize(ExportPath); err != nil || size >= MaxSize {
		return "", errors.New("Not enough space, please clean the export file")
	}

	file := excelize.NewFile()
	defer file.Close()
	file.SetSheetName("Sheet1", sheetName)
	streamWriter, err := file.NewStreamWriter(sheetName)
	if err != nil {
		logger.Errorf("%v", err)
		return "", err
	}

	// 设置标题
	if err := seTableTitle(b[0], streamWriter); err != nil {
		logger.Errorf("%v", err)
		return "", err
	}
	// 内容,从第二行开始
	var rowIndex int64 = 2
	for {
		if len(b) <= 0 {
			break
		}
		// 设置值
		for _, val := range b {
			setRowValue(val, streamWriter, rowIndex)
			rowIndex++
		}
		if rowIndex > MaxRow {
			// 超过最大行数就结束
			break
		}
		b, lastPoint = f(lastPoint)
	}

	if err := streamWriter.Flush(); err != nil {
		logger.Errorf("flush fail:%v", err)
		return "", err
	}
	filePath := fmt.Sprintf("%s%s_%d.xlsx", ExportPath, sheetName, utime.JakartaTime().UnixMilli())
	if err := file.SaveAs(filePath); err != nil {
		logger.Errorf("save excel fail:%v", err)
		return "", err
	}

	var size float64
	info, err := os.Stat(filePath)
	if err == nil {
		size = float64(info.Size()) / 1024 / 1024
	}
	logger.Infof("export excel %s success size:%.2fM, cost:%.3fms", sheetName, size, float64(utime.JakartaTime().UnixMilli()-now)/1000)
	return filePath, nil
}

func ensureDirExists() error {
	if _, err := os.Stat(ExportPath); os.IsNotExist(err) {
		err := os.MkdirAll(ExportPath, os.ModePerm) // 递归创建
		if err != nil {
			return err
		}
	}
	return nil
}

// 计算目录的总大小
func getDirSize(path string) (int64, error) {
	var totalSize int64

	err := filepath.WalkDir(path, func(_ string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// 获取文件信息
		if !d.IsDir() { // 只统计文件大小
			info, err := d.Info()
			if err != nil {
				return err
			}
			totalSize += info.Size()
		}
		return nil
	})

	return totalSize, err
}

func seTableTitle(bean any, write *excelize.StreamWriter) error {
	types := reflect.TypeOf(bean)
	if types.Kind() == reflect.Ptr {
		types = types.Elem() // 解引用指针，获取结构体的实际值
	}
	header := make([]any, 0)
	for k := 0; k < types.NumField(); k++ {
		excelTag, ok := types.Field(k).Tag.Lookup("excel")
		if !ok || excelTag == "-" {
			continue
		}
		header = append(header, excelTag)
	}
	if err := write.SetRow("A1", header); err != nil {
		return err
	}
	return nil
}

func setRowValue(bean any, write *excelize.StreamWriter, row int64) {
	valSlice := make([]any, 0)
	vals := reflect.ValueOf(bean)
	types := reflect.TypeOf(bean)
	if types.Kind() == reflect.Ptr {
		types = types.Elem() // 解引用指针，获取结构体的实际值
	}
	if vals.Kind() == reflect.Ptr {
		vals = vals.Elem() // 解引用指针，获取结构体的实际值
	}
	for k := 0; k < vals.NumField(); k++ {
		excelTag, ok := types.Field(k).Tag.Lookup("excel")
		if !ok || excelTag == "-" {
			continue
		}
		valSlice = append(valSlice, vals.Field(k).Interface())
	}
	err := write.SetRow(fmt.Sprintf("A%d", row), valSlice)
	if err != nil {
		logger.Errorf("setRowValue fail, cell:%s%d, err:%v", row, err)
	}
}
