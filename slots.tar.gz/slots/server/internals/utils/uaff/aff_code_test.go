package uaff

import (
	"fmt"
	"server/internals/utils/utime"
	"testing"
)

func TestEncode(t *testing.T) {

	t1 := utime.JakartaTime()
	for i := int64(0); i < 10000000; i++ {
		e := Encode(i)
		d := Decode(e)
		if i != d {
			t.Errorf("i: %d, e: %s, d: %d", i, e, d)
		}
	}
	t2 := utime.JakartaTime()
	fmt.Println("ok", t2.Sub(t1))
}
