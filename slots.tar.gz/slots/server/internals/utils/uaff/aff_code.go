package uaff

import (
	"server/internals/utils/uaff/optimus"
)

var (
	opt = optimus.NewCalculated(838038673, 20220101)
)

const pool = "ewbzy2qgcthmnadiu796vj8453fxspkr"

var dt = map[rune]uint64{}

func init() {
	for idx, r := range pool {
		dt[r] = uint64(idx)
	}
}

func Encode(in int64) string {
	n := opt.Encode(uint64(in))

	out := []byte{}
	mask5 := uint64(0x1f)
	for i := 0; i < 7; i++ {
		b := pool[(n>>(i*5))&mask5]
		if b >= 'a' && b <= 'z' && n&(1<<i) > 0 {
			b -= 0x20
		}
		out = append(out, b)
	}

	return string(out)
}

func Decode(in string) int64 {

	if len(in) != 7 {
		return -1
	}

	n := uint64(0)
	for i, b := range in {
		if b >= 'A' && b <= 'Z' {
			b += 0x20
		}
		n = n | dt[b]<<(i*5)
	}

	return int64(opt.Decode(n))
}
