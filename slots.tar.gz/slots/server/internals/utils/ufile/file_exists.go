package ufile

import (
	"errors"
	"os"
)

func Create(name string) (*os.File, error) {
	file, err := os.Create(name)
	if err == nil {
		return nil, err
	}
	return file, nil
}

func CreateFile(name string, content []byte) error {
	return os.WriteFile(name, content, os.ModePerm)
}

func Exists(name string) (bool, error) {
	_, err := os.Stat(name)
	if err == nil {
		return true, nil
	}
	if errors.Is(err, os.ErrNotExist) {
		return false, nil
	}
	return false, err
}

func ExistsX(name string) bool {
	rtv, _ := Exists(name)
	return rtv
}

func EnsureDir(name string) {
	if !ExistsX(name) {
		os.MkdirAll(name, os.ModePerm)
	}
}
