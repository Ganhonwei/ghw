package ufile

import (
	"io/ioutil"
	"os"
	"strings"

	"server/internals/utils/uhttp"

	jsoniter "github.com/json-iterator/go"
)

func LoadFileData(url string) ([]byte, error) {
	lowerUrl := strings.ToLower(url)
	remoteUrl := strings.HasPrefix(lowerUrl, "http://") || strings.HasPrefix(lowerUrl, "https://")

	if remoteUrl {
		return uhttp.Get(url)
	} else {
		return ioutil.ReadFile(url)
	}
}

func ReadFile(fn string, sz int) ([]byte, error) {
	f, err := os.Open(fn)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	rtv := make([]byte, sz)
	rd, err := f.Read(rtv)
	if err != nil {
		return nil, err
	}

	return rtv[:rd], nil
}

func UnmarshalFileToJson(filePath string, v interface{}) error {
	f, err := LoadFileData(filePath)
	if err != nil {
		return err
	}

	return jsoniter.Unmarshal(f, v)
}

func UnmarshalLocalFileToJson(filePath string, v interface{}) error {
	f, err := ioutil.ReadFile(filePath)
	if err != nil {
		return err
	}

	return jsoniter.Unmarshal(f, v)
}
