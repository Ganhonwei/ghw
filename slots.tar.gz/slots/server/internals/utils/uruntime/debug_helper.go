package uruntime

import (
	"fmt"
	"server/internals/logger"
	"runtime"
	"strconv"
	"strings"
)

func CallByX(x int, caller, udata string) {
	_, file, line, _ := runtime.Caller(x)
	logger.Debugf("%v: %v CallBy: %v[%v]", caller, udata, file, line)
}

func CallBy(caller, udata string) {
	CallByX(2, caller, udata)
}

func GetGoid() int64 {
	var (
		buf [64]byte
		n   = runtime.Stack(buf[:], false)
		stk = strings.TrimPrefix(string(buf[:n]), "goroutine")
	)

	idField := strings.Fields(stk)[0]
	id, err := strconv.Atoi(idField)
	if err != nil {
		panic(fmt.Errorf("can not get goroutine id: %v", err))
	}

	return int64(id)
}

func DebugPrint(data string) {
	_, file, line, _ := runtime.Caller(1)
	logger.Debugf("[GOID: %v]%v CallBy: %v[%v]", GetGoid(), data, file, line)
}
