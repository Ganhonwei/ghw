package uhash

import (
	"encoding/hex"
	"fmt"
	"sort"

	"server/internals/utils/utypes"
)

func CalcSignSHA256(data map[string]interface{}, key string) string {

	keys := make([]string, 0, len(data))
	for k := range data {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	h := allowSha256()
	defer freeSHA256(h)
	for _, k := range keys {
		h.Write(utypes.StringToBytes(k))
		h.Write(utypes.StringToBytes(fmt.Sprintf("%v", data[k])))
	}
	h.Write(utypes.StringToBytes(key))

	sum := h.Sum(nil)
	return hex.EncodeToString(sum)
}

func SumSHA256(params ...string) string {
	h := allowSha256()
	defer freeSHA256(h)
	for _, k := range params {
		h.Write(utypes.StringToBytes(k))
	}

	sum := h.Sum(nil)
	return hex.EncodeToString(sum)
}

func SumSHA256Bytes(params ...[]byte) []byte {
	h := allowSha256()
	defer freeSHA256(h)
	for _, k := range params {
		h.Write(k)
	}

	return h.Sum(nil)
}
