package uhash

import (
	"encoding/hex"

	"server/internals/utils/utypes"
)

func SumMD5(params ...string) string {
	h := AllowMD5()
	defer FreeMD5(h)
	for _, k := range params {
		h.Write(utypes.StringToBytes(k))
	}

	sum := h.Sum(nil)
	return hex.EncodeToString(sum)
}

func SumMD5Bytes(params ...[]byte) []byte {
	h := AllowMD5()
	defer FreeMD5(h)
	for _, k := range params {
		h.Write(k)
	}

	return h.Sum(nil)
}
