package uhash

import (
	"crypto/sha256"
	"hash"
	"sync"
)

var sha256Pool = sync.Pool{
	New: func() interface{} { return sha256.New() },
}

func allowSha256() hash.Hash {
	h := sha256Pool.Get().(hash.Hash)
	h.Reset()
	return h
}

func freeSHA256(h hash.Hash) {
	sha256Pool.Put(h)
}
