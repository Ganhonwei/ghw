package uhash

import (
	"crypto/md5"
	"hash"
	"sync"
)

var md5Pool = sync.Pool{
	New: func() interface{} { return md5.New() },
}

func AllowMD5() hash.Hash {
	h := md5Pool.Get().(hash.Hash)
	h.Reset()
	return h
}

func FreeMD5(h hash.Hash) {
	md5Pool.Put(h)
}
