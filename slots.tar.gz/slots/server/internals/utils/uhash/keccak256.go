package uhash

import "server/internals/utils/ucrypto"

func SumKeccak256(data ...[]byte) []byte {
	return ucrypto.NewKeccak256().Hash(data...)
}
