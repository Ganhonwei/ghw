package uslice

func Map[FT any, TT any](src []FT, f func(FT) TT) []TT {
	var rtv []TT
	length := len(src)
	for i := 0; i < length; i++ {
		rtv = append(rtv, f(src[i]))
	}
	return rtv
}

func MakeMap[T any, KT comparable](src []T, f func(T) KT) map[KT]T {
	rtv := make(map[KT]T, len(src))
	length := len(src)
	for i := 0; i < length; i++ {
		rtv[f(src[i])] = src[i]
	}
	return rtv
}

func Maps[FT any, TT any](src []FT, f func(FT) []TT) []TT {
	var rtv []TT
	length := len(src)
	for i := 0; i < length; i++ {
		rtv = append(rtv, f(src[i])...)
	}
	return rtv
}

func MakeMaps[FT any, T any, KT comparable](src []FT, f func(FT) (KT, T)) map[KT][]T {
	rtv := make(map[KT][]T, len(src))
	length := len(src)
	for i := 0; i < length; i++ {
		k, v := f(src[i])
		if _, ok := rtv[k]; !ok {
			rtv[k] = []T{}
		}
		rtv[k] = append(rtv[k], v)
	}
	return rtv
}

func KeyValue[FT any, VT any, KT comparable](src []FT, f func(FT) (KT, VT)) map[KT]VT {

	rtv := make(map[KT]VT, len(src))

	for _, it := range src {
		k, v := f(it)
		rtv[k] = v
	}

	return rtv
}
