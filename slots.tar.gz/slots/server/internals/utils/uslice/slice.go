package uslice

import (
	"fmt"
	"math/rand"
)

func InsertAt[T any](l []T, elem T, at int) []T {
	r := append(make([]T, 0, len(l)+1), l[:at]...)
	r = append(r, elem)
	r = append(r, l[at:]...)
	return r
}

func RemoveAt[T any](l []T, at int) []T {
	return append(l[:at], l[at+1:]...)
}

func Shuffle[T any](l []T) {
	rand.Shuffle(len(l), func(i, j int) {
		l[i], l[j] = l[j], l[i]
	})
}

func First[T any](l []T, f func(T) bool) (T, bool) {
	for _, v := range l {
		if f(v) {
			return v, true
		}
	}
	var r T
	return r, false
}

func IsUniq[T comparable](l []T) bool {
	m := map[T]bool{}
	for _, t := range l {
		if m[t] {
			return false
		} else {
			m[t] = true
		}

	}
	return true
}

func RemoveFirst[T comparable](l []T, v T) ([]T, bool) {
	for i, t := range l {
		if t == v {
			for j := i + 1; j < len(l); j++ {
				l[j-1] = l[j]
			}
			l = l[:len(l)-1]
			return l, true
		}
	}
	return l, false
}

func RemoveAll[T comparable](l []T, v T) ([]T, bool) {
	var ok bool
	for i := len(l) - 1; i >= 0; i-- {
		if l[i] == v {
			l = append(l[:i], l[i+1:]...)
			ok = true
		}
	}
	return l, ok
}

func ContainFunc[T any](l []T, f func(v T) bool) bool {

	for _, v := range l {
		if f(v) {
			return true
		}
	}
	return false
}

func Len32[T any](l []T) int32 {
	return int32(len(l))
}

func GroupByFunc[S ~[]T, T any, K comparable](src S, f func(v T) K) map[K][]T {
	r := make(map[K][]T, len(src))
	for _, elem := range src {
		k := f(elem)
		r[k] = append(r[k], elem)
	}
	return r
}

func KeyByFunc[S ~[]T, T any, K comparable](src S, f func(v T) K) map[K]T {
	r := make(map[K]T, len(src))
	for _, item := range src {
		r[f(item)] = item
	}
	return r
}

func Uniq[S ~[]T, T comparable](src S) S {
	m := make(map[T]bool, len(src))
	n := 0

	for i, v := range src {
		if n > 0 {
			src[i-n] = v
		}

		if m[v] {
			n++
		} else {
			m[v] = true
		}
	}

	return src[:len(src)-n]
}

func UniqByFunc[S ~[]T, T any, K comparable](src S, f func(T) K) S {
	m := make(map[K]bool, len(src))
	n := 0

	for i, v := range src {
		if n > 0 {
			src[i-n] = v
		}

		k := f(v)

		if m[k] {
			n++
		} else {
			m[k] = true
		}
	}

	return src[:len(src)-n]
}

func Chunk[S ~[]T, T any](src S, size int) []S {
	if len(src) == 0 {
		return nil
	}

	r := make([]S, 0, len(src)/size+1)
	for i := 0; i < len(src); {
		end := i + size
		if end > len(src) {
			end = len(src)
		}
		r = append(r, src[i:end])
		i = end
	}

	return r
}

func IntsToStrings[T int | int64](l []T) []string {
	// todo 优化
	rtv := make([]string, 0, len(l))
	for _, v := range l {
		rtv = append(rtv, fmt.Sprintf("%v", v))
	}

	return rtv
}

// 查找两个数组的不同
func Arrcmp(x []int64, j []int64) ([]int64, []int64) {
	msrc := make(map[int64]byte)
	var added, deleted []int64
	for _, v := range x {
		msrc[v] = 1
	}
	for _, v := range j {
		if _, ok := msrc[v]; ok {
			delete(msrc, v)
			continue
		}
		added = append(added, v)
	}
	for k := range msrc {
		deleted = append(deleted, k)
	}

	return deleted, added
}

// 查找两个数组的交集

func Intersection[T int64](s1 []T, s2 []T) []T {
	if len(s1) == 0 || len(s2) == 0 {
		return nil
	}

	r := make([]T, 0)
	doc := make(map[T]struct{})
	for _, s := range s1 {
		doc[s] = struct{}{}
	}

	for _, s := range s2 {
		_, ok := doc[s]
		if ok {
			r = append(r, s)
		}
	}

	return r
}
