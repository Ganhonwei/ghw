package uslice

func Forech[S ~[]T, T any](src S, f func(T)) {
	length := len(src)
	for i := 0; i < length; i++ {
		f(src[i])
	}
}

func Any[S ~[]T, T any](src S, f func(T) bool) bool {
	length := len(src)
	for i := 0; i < length; i++ {
		if f(src[i]) {
			return true
		}
	}
	return false
}

func Unique[T comparable](vals []T) []T {
	n := len(vals)
	if n <= 0 {
		return vals
	}

	out := make([]T, 0, n)
	checkDupli := make(map[T]struct{}, n)
	for _, v := range vals {
		if _, found := checkDupli[v]; found {
			continue
		}

		checkDupli[v] = struct{}{}
		out = append(out, v)
	}

	return out
}

func All[S ~[]T, T any](src S, f func(T) bool) bool {
	length := len(src)
	for i := 0; i < length; i++ {
		if !f(src[i]) {
			return false
		}
	}
	return true
}

func DeleteFirstFunc[S ~[]T, T any](l S, f func(v T) bool) ([]T, bool) {
	for i, v := range l {
		if f(v) {
			oldLen := len(l)
			l = RemoveAt(l, i)
			return l, oldLen != len(l)
		}
	}

	return l, false
}

func DeleteAllFunc[S ~[]T, T any](l S, f func(v T) bool) ([]T, bool) {
	var r bool
	for i := len(l) - 1; i >= 0; i-- {
		if f(l[i]) {
			l = RemoveAt(l, i)
			if !r {
				r = true
			}
		}
	}

	return l, r
}

func Clear[S ~[]T, T any](l S) S {
	return l[:0]
}
