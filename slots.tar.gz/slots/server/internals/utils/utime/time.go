package utime

import (
	"fmt"
	"regexp"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/ethereum/go-ethereum/common/math"
)

const (
	SecondsOfDay = int32(60 * 60 * 24)
	Daily        = time.Hour * 24
)

var DefaultTime = time.Unix(0, 0)
var maxTime = time.UnixMilli(math.MaxInt64)

var frameMs int64

func init() {
	atomic.StoreInt64(&frameMs, time.Now().UTC().UnixMilli())
	go func() {
		t := time.NewTicker(10 * time.Millisecond)
		for range t.C {
			atomic.StoreInt64(&frameMs, time.Now().UTC().UnixMilli())
		}
	}()
}

func AfterMs(ms int64) int64 {
	return UnixMs() + ms
}

func UnixMs() int64 {
	return atomic.LoadInt64(&frameMs)
}

func UnixSec() int64 {
	return UnixMs() / 1000
}

var d20230101, _ = time.Parse(time.RFC3339, "2023-01-01T00:00:00Z")

func SecFrom20230101() int64 {
	return int64(time.Now().UTC().Sub(d20230101).Seconds())
}

func DaysSinceUtcEpoch() int32 {
	return int32(UnixSec() / int64(SecondsOfDay))
}

func DaysSinceUtcEpochForValue(t time.Time) int32 {
	return int32(t.UTC().Unix() / int64(SecondsOfDay))
}

func DayPastByMinute(at time.Time, minute int) time.Time {
	n := at.Local()
	m := int(0)
	t := n.Minute() % minute
	if t == 0 { //时间点整点
		m = n.Minute()
	} else {
		m = n.Minute() - t
	}
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), m, 0, 0, time.Local)
}

func DayRangeByMinute(at time.Time, minute int) (time.Time, time.Time) {
	n := at.Local()
	m := int(0)
	t := n.Minute() % minute
	if t == 0 { //时间点整点
		m = n.Minute()
	} else {
		m = n.Minute() - t
	}
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), m-minute, 0, 0, time.Local), time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), m, 0, 0, time.Local)
}

func DayAddMinute(at time.Time, minute int) (time.Time, time.Time) {
	end := time.Date(at.Year(), at.Month(), at.Day(), at.Hour(), at.Minute()+minute, 0, 0, time.Local)
	ns := time.Now().UTC().Unix()
	if minute < 0 {
		if at.Unix() > ns {
			return end, end
		} else {
			return end, at
		}
	} else {
		if end.Unix() > ns {
			return at, at
		} else {
			return at, end
		}
	}
}

// 获得当前时间所属的时刻
func TimeUtcDivIntervalMinutes(at time.Time, minute int) time.Time {
	t := at.UTC()
	mm := t.Minute() / minute * minute
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), mm, 0, 0, time.UTC)
}

// 获得当前时间所属的时刻
func TimeJakartaDivIntervalMinutes(at time.Time, minute int) time.Time {
	t := at.In(locJakarta)
	mm := t.Minute() / minute * minute
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), mm, 0, 0, locJakarta)
}

// 获得当前时间所属的时刻
func TimeJakartaDivIntervalHours(at time.Time) time.Time {
	t := at.In(locJakarta)
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), 0, 0, 0, locJakarta)
}

func DayBeginByMinute(at time.Time) time.Time {
	n := at.Local()
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), n.Minute(), 0, 0, time.Local)
}

func DayBeginUtcByMinute(at time.Time) time.Time {
	n := at.UTC()
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), n.Minute(), 0, 0, time.UTC)
}

func DayBeginJakartaByMinute(at time.Time) time.Time {
	n := at.In(locJakarta)
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), n.Minute(), 0, 0, locJakarta)
}

func DayBeginUtcBy(at time.Time) time.Time {
	n := at.UTC()
	return time.Date(n.Year(), n.Month(), n.Day(), 0, 0, 0, 0, time.UTC)
}

func HourBeginJakartaBy(at time.Time) time.Time {
	n := at.In(locJakarta)
	return time.Date(n.Year(), n.Month(), n.Day(), n.Hour(), 0, 0, 0, locJakarta)
}

func DayBeginJakartaBy(at time.Time) time.Time {
	n := at.In(locJakarta)
	return time.Date(n.Year(), n.Month(), n.Day(), 0, 0, 0, 0, locJakarta)
}

func DayRangeUtcBy(at time.Time) (time.Time, time.Time) {
	n := at.UTC()
	a := time.Date(n.Year(), n.Month(), n.Day(), 0, 0, 0, 0, time.UTC)
	return a, a.AddDate(0, 0, 1)
}

func DayRangeJakartaBy(at time.Time) (time.Time, time.Time) {
	loc, _ := time.LoadLocation("Asia/Jakarta") // 加载雅加达时区
	n := at.In(loc)                             // 转换到 Jakarta 时区
	a := time.Date(n.Year(), n.Month(), n.Day(), 0, 0, 0, 0, loc)
	return a, a.AddDate(0, 0, 1) // 返回 Jakarta 当日 00:00 和次日 00:00
}

func MaxTime() interface{} {
	return maxTime
}

func UnixMsToUtcTime(ts int64) time.Time {
	return time.UnixMilli(ts).UTC()
}

func UnixSecToUtcTime(ts int64) time.Time {
	return time.Unix(ts, 0).UTC()
}

func UnixMsToJakartaTime(ts int64) time.Time {
	return time.UnixMilli(ts).In(locJakarta)
}

func UnixSecToJakartaTime(ts int64) time.Time {
	return time.Unix(ts, 0).In(locJakarta)
}

func DateFromYMDUtc(ymd int32) time.Time {

	y := ymd / 10000
	m := (ymd / 100) % 100
	d := ymd % 100

	return time.Date(int(y), time.Month(m), int(d), 0, 0, 0, 0, time.UTC)
}

func YearMonthDayUtc() int32 {
	return YearMonthDay(time.Now().UTC())
}

func YearMonthDay(t time.Time) int32 {
	return int32(t.Year())*10000 + int32(t.Month())*100 + int32(t.Day())
}

func YearMonthDay64(t time.Time) int64 {
	return int64(t.Year())*10000 + int64(t.Month())*100 + int64(t.Day())
}

func TodayUtc() time.Time {
	return DateOfTime(time.Now().UTC())
}

func TodayJakarta() time.Time {
	return DateOfTime(JakartaTime())
}

func TodayJakartaAdd(day int) time.Time {
	return DateOfTime(JakartaTime()).AddDate(0, 0, day)
}

func DateOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

func YearOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), time.January, 1, 0, 0, 0, 0, t.Location())
}

func MinuteOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), 0, 0, t.Location())
}

func MonthBeginOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), 1, 0, 0, 0, 0, t.Location())
}

func DayStartOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

func DayEndOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 23, 59, 59, 0, t.Location())
}

func NextYear(t time.Time) time.Time {
	return time.Date(t.Year()+1, t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second(), t.Nanosecond(), t.Location())
}

func HourOfTime(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), 0, 0, 0, t.Location())
}

func NextHour(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour()+1, 0, 0, 0, t.Location())
}

func NextDay(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day()+1, 0, 0, 0, 0, t.Location())
}

func GetLocationJakarta() *time.Location {
	return locJakarta
}

var locJakarta *time.Location
var locUtc *time.Location = time.UTC

func init() {
	locJakarta, _ = time.LoadLocation("Asia/Jakarta")
}

const (
	LayoutZero    = "2006-01-02 00:00:00"
	LayoutA       = "2006-01-02 15:04:05"
	LayoutB       = "2006/01/02 15:04:05"
	LayoutC       = "20060102150405"
	LayoutADate   = "2006-01-02"
	LayoutBDate   = "2006/01/02"
	LayoutAYMDHM  = "2006-01-02 15:00"
	LayoutAYMDHMS = "2006-01-02 15:00:00"
)

func ParseJakartaUnsafed(v string) time.Time {
	layouts := []string{
		LayoutA, LayoutADate, LayoutB, LayoutBDate,
	}

	for _, l := range layouts {
		t, e := time.ParseInLocation(l, v, locJakarta)
		if e == nil {
			return t
		}
	}

	return time.Unix(0, 0).In(locJakarta)
}

func ParseUtcUnsafed(v string) time.Time {
	layouts := []string{
		LayoutA, LayoutADate, LayoutB, LayoutBDate,
	}

	for _, l := range layouts {
		t, e := time.ParseInLocation(l, v, locUtc)
		if e == nil {
			return t
		}
	}

	return time.Unix(0, 0).UTC()
}

func ParseUtcTime(date string, fmt string) time.Time {
	t, e := time.ParseInLocation(fmt, date, locUtc)
	if e == nil {
		return t
	}
	return time.Unix(0, 0).UTC()
}

func ParseJakartaTimeByInt64(date int64) time.Time {
	t, e := time.ParseInLocation("20060102", fmt.Sprintf("%v", date), locJakarta)
	if e == nil {
		return t
	}
	return time.Unix(0, 0)
}

func ParseJakartaTime(date string, fmt string) time.Time {
	t, e := time.ParseInLocation(fmt, date, locJakarta)
	if e == nil {
		return t
	}
	return time.Unix(0, 0)
}

func UtcTime() time.Time {
	return time.Now().UTC()
}

func JakartaTime() time.Time {
	return time.Now().In(locJakarta)
}

var regexTS10 = regexp.MustCompile(`^\d{10}$`)
var regexTS13 = regexp.MustCompile(`^\d{13}$`)

func QueryParamTime(v string) (time.Time, error) {

	if regexTS10.MatchString(v) {
		ts, err := strconv.ParseInt(v, 10, 64)
		return time.Unix(ts, 0), err
	}

	if regexTS13.MatchString(v) {
		ts, err := strconv.ParseInt(v, 10, 64)
		return time.Unix(0, ts*int64(time.Millisecond)), err
	}

	t, err := time.ParseInLocation(time.RFC3339, v, time.UTC)
	if err == nil {
		return t, nil
	}

	t, err = time.ParseInLocation(time.RFC3339Nano, v, time.UTC)
	if err == nil {
		return t, nil
	}

	return time.ParseInLocation("2006-01-02T15:04:05.999Z07:00", v, time.UTC)
}

func StartOfWeek(now time.Time) time.Time {
	date := DateOfTime(now)
	weekday := date.Weekday()

	var n int32
	if weekday == time.Sunday {
		n = 6
	} else {
		n = int32(weekday) - 1
	}

	return date.Add(-(time.Hour * time.Duration(24*n)))
}

func TimeSubDays(end, start time.Time) int {

	if end.Location().String() != start.Location().String() {
		return -1
	}
	hours := end.Sub(start).Hours()

	if hours <= 0 {
		return -1
	}
	// sub hours less than 24
	if hours < 24 {
		// may same day
		t1y, t1m, t1d := end.Date()
		t2y, t2m, t2d := start.Date()
		isSameDay := (t1y == t2y && t1m == t2m && t1d == t2d)
		if isSameDay {
			return 0
		} else {
			return 1
		}
	} else { // equal or more than 24

		if (hours/24)-float64(int(hours/24)) == 0 { // just 24's times
			return int(hours / 24)
		} else { // more than 24 hours
			return int(hours/24) + 1
		}
	}

}

func TimeSubDaysByInt64(end, start int64) int64 {
	temp := end - start
	day := temp / 60 / 60 / 24
	return day
}

func ParseHHmm(at time.Time) string {
	n := at.Local()
	return fmt.Sprintf("%02d:%02d", n.Hour(), n.Minute())
}

func ParseIntYmd(at time.Time) int64 {
	n := at.Local()
	t := fmt.Sprintf("%d%02d%02d", n.Year(), n.Month(), n.Day())
	tt, _ := strconv.ParseInt(t, 10, 64)
	return tt
}

func ParseUnix(f string, at string) int64 {
	t, err := time.Parse(f, at)
	if err != nil {
		return 0
	}
	return t.Unix()
}

func ParseIntYearMonth(at time.Time) int64 {
	n := at.Local()
	t := fmt.Sprintf("%d%02d", n.Year(), n.Month())
	tt, _ := strconv.ParseInt(t, 10, 64)
	return tt
}

func ParseIntDay(at time.Time) int64 {
	n := at.Local()
	return int64(n.Day())
}

func IsSameday(t1, t2 time.Time) bool {
	return ParseIntYmd(t1) == ParseIntYmd(t2)
}

func IsWeekday(t1 time.Time) bool {
	return t1.Weekday() == time.Sunday
}

func IsMonthEndday(t1 time.Time) bool {
	_, end := GetMonthStartAndEnd(t1)
	return t1.Format(LayoutADate) == end.Format(LayoutADate)
}

func IsWithinDay(t1, t2 time.Time, day int) bool {
	a := ParseIntYmd(t1)
	b := ParseIntYmd(t2)
	t7 := t1.AddDate(0, 0, day)
	c := ParseIntYmd(t7)
	return b >= a && b <= c
}
func Yesterday() time.Time {
	n := time.Now()
	return time.Date(n.Year(), n.Month(), n.Day()-1, 0, 0, 0, 0, time.Local)
}

func Tomorrow() time.Time {
	n := time.Now()
	return time.Date(n.Year(), n.Month(), n.Day()+1, 0, 0, 0, 0, time.Local)
}

func InitTimeRange(m int) []string {
	result := []string{}
	max := (60 / m) * 24
	for i := 0; i < max; i++ {
		result = append(result, FormatMinuteToHour(i*m))
	}
	return result
}

func FormatMinuteToHour(d int) string {
	h := d / 60
	m := d % 60
	return fmt.Sprintf("%02d:%02d", h, m)
}

// 周一到周日
func GetWeekStartAndEnd(now time.Time) (time.Time, time.Time) {
	week := now.Weekday()
	//time.Weekday()的周日是 0， 改为7
	if week == time.Sunday {
		week = 7
	}
	// 获取本周第一天（周一）
	monday := now.AddDate(0, 0, -int(week)+1)
	// 获取本周最后一天（周日）
	sunday := now.AddDate(0, 0, -int(week)+7)
	return monday, sunday
}

func GetMonthStartAndEnd(now time.Time) (time.Time, time.Time) {
	start := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, locJakarta)
	end := start.AddDate(0, 1, -1) // 增加一个月，然后减去一天到达本月的最后一天
	return start, end
}

func DateAddHour(now time.Time, hour int64) time.Time {
	t, _ := time.ParseDuration(fmt.Sprintf("%vh", hour))
	return now.Add(t)
}

func TimeToString(t time.Time, format string) string {
	return t.Format(format)
}

func GetWeekStartAndEndNew(now time.Time) (time.Time, time.Time) {
	day := now.Weekday()
	if day == 0 {
		day = 7
	}
	// 获取本周第一天（周一）
	monday := now.AddDate(0, 0, -int(day)+1)
	// 获取本周最后一天（周日）
	sunday := now.AddDate(0, 0, -int(day)+7)
	return monday, sunday
}

func DateAddMinute(now time.Time, minute int64) time.Time {
	t, _ := time.ParseDuration(fmt.Sprintf("%vm", minute))
	return now.Add(t)
}
