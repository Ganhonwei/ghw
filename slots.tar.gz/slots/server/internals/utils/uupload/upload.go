package uupload

import (
	"fmt"
	"server/internals/utils/ufile"
	"server/internals/utils/urand"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"

	"github.com/valyala/fasthttp"
)

func genFn(bp string) (string, string) {
	np := urand.HexStrings(2)
	npp := filepath.Join(bp, np)
	ufile.EnsureDir(npp)

	fn := urand.LowerStrings(8)
	randName := filepath.Join(npp, fn)
	for i := 0; ufile.ExistsX(randName); i++ {
		fn = urand.LowerStrings(8 + i/8)
		randName = filepath.Join(npp, fn)
	}

	return randName, filepath.Join(np, fn)
}

func SaveFile(fh *multipart.FileHeader,
	basePath string,
	allowContentTypes map[string]string) (string, error) {

	// TODO => save upload record

	ofn, rfn := genFn(basePath)

	err := fasthttp.SaveMultipartFile(fh, ofn)
	if err != nil {
		return "", err
	}

	data, err := ufile.ReadFile(ofn, 32)
	if err != nil {
		return "", err
	}

	ct := http.DetectContentType(data)
	if ext, ok := allowContentTypes[ct]; ok {
		nofn := ofn + ext
		if err := os.Rename(ofn, nofn); err != nil {
			os.Remove(ofn)
			return "", fmt.Errorf("disabled content type: %s", err)
		}

		return rfn + ext, nil
	} else {
		os.Remove(ofn)
		return "", fmt.Errorf("disabled content type: %s", ct)
	}
}
