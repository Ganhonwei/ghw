package ueth

import (
	"crypto/ecdsa"
	"errors"
	"fmt"
	"strings"

	"github.com/ethereum/go-ethereum/crypto"

	"server/internals/utils/uhash"
	"server/internals/utils/utypes"
)

func ValidateAddress(address string) bool {

	addrLowerStr := strings.ToLower(address)
	if !strings.HasPrefix(addrLowerStr, "0x") {
		return false
	}
	addrLowerStr = addrLowerStr[2:]
	// address = address[2:]

	var binaryStr string
	addrBytes := []byte(addrLowerStr)
	hash256 := uhash.SumKeccak256(utypes.StringToBytes(addrLowerStr)) // 注意，这里是直接对字符串转换成byte切片然后哈希

	for i, e := range addrLowerStr {
		//如果是数字则跳过
		if e >= '0' && e <= '9' {
			continue
		} else {
			binaryStr = fmt.Sprintf("%08b", hash256[i/2]) // 注意，这里一定要填充0
			if binaryStr[4*(i%2)] == '1' {
				addrBytes[i] -= 32
			}
		}
	}

	return "0x"+string(addrBytes) == address
}

func RandomAddress() (string, error) {
	privateKey, err := crypto.GenerateKey()
	if err != nil {
		return "", err
	}

	publicKey := privateKey.Public()
	publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return "", errors.New("random address fail")
	}

	address := crypto.PubkeyToAddress(*publicKeyECDSA).Hex()

	return address, nil
}
