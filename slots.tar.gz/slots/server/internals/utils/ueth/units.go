package ueth

import (
	"server/ent/schema/ftype"
	"math/big"
)

// func Gwei2Wei(gwei int64) int64 {
// 	return int64(float64(gwei) / 1_000_000_000)
// }

func ToWeiFromPermyriadEther(n int64) ftype.BigInt {
	return ftype.BigInt{
		Int: big.NewInt(0).Mul(
			big.NewInt(n),
			big.NewInt(100_000_000_000_000)),
	}
}

func GweiToWei(gwei int64) ftype.BigInt {
	return ftype.BigInt{
		Int: big.NewInt(0).Mul(
			big.NewInt(gwei),
			big.NewInt(1_000_000_000)),
	}
}

func Wei(wei string) (ftype.BigInt, bool) {

	if wei == "" {
		return ftype.NewBigInt(0), true
	}

	rtv, err := ftype.Parse(wei)
	if err != nil {
		return ftype.NewBigInt(0), false
	}

	return rtv, true
}

func MustWei(wei string) ftype.BigInt {
	rtv, _ := Wei(wei)
	return rtv
}
