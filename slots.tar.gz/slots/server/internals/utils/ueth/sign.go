package ueth

import (
	"encoding/hex"
	"fmt"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

// import (
// 	"encoding/hex"
// 	"fmt"

// 	"github.com/ethereum/go-ethereum/cmd/utils"
// 	"github.com/ethereum/go-ethereum/common"
// 	"github.com/ethereum/go-ethereum/crypto"
// )

func SignHash(data []byte) []byte {
	msg := fmt.Sprintf("\x19Ethereum Signed Message:\n%d", len(data))
	return crypto.Keccak256([]byte(msg), data)
}

func ValidateSign(addr string, sig string, message []byte) bool {

	if !common.IsHexAddress(addr) {
		return false
	}
	address := common.HexToAddress(addr)
	if sig[:2] == "0x" {
		sig = sig[2:]
	}
	signature, err := hex.DecodeString(sig)
	if err != nil || len(signature) != 65 {
		return false
	}

	if signature[64] >= 27 {
		signature[64] -= 27
	}

	recoveredPubkey, err := crypto.SigToPub(SignHash(message), signature)
	if err != nil || recoveredPubkey == nil {
		return false
	}
	// recoveredPubkeyBytes := crypto.FromECDSAPub(recoveredPubkey)
	recoveredAddress := crypto.PubkeyToAddress(*recoveredPubkey)
	return address == recoveredAddress
}
