package ujson

import (
	"fmt"
	"strconv"
	"unsafe"

	jsoniter "github.com/json-iterator/go"
)

type float64AsStringCodec struct {
}

func (codec *float64AsStringCodec) Decode(ptr unsafe.Pointer, iter *jsoniter.Iterator) {
	valueType := iter.WhatIsNext()
	switch valueType {
	case jsoniter.NilValue:
		*((*float64)(ptr)) = float64(0)

	case jsoniter.NumberValue:
		*((*float64)(ptr)) = iter.ReadFloat64()

	case jsoniter.StringValue:

		var err error
		val := iter.ReadString()
		*((*float64)(ptr)), err = strconv.ParseFloat(val, 64)
		if err == nil {
			break
		}

		iter.ReportError("float64AsStringCodec.Decode", fmt.Sprintf("unexpected value: %+v", err.Error()))
		*((*float64)(ptr)) = float64(0)

	}
}

func (codec *float64AsStringCodec) IsEmpty(ptr unsafe.Pointer) bool {
	return (*((*float64)(ptr))) == float64(0)
}
func (codec *float64AsStringCodec) Encode(ptr unsafe.Pointer, stream *jsoniter.Stream) {
	val := *((*float64)(ptr))
	stream.WriteString(strconv.FormatFloat(val, 'f', -1, 64))
}

func init() {

	jsoniter.RegisterTypeEncoder("float64", &float64AsStringCodec{})
	jsoniter.RegisterTypeDecoder("float64", &float64AsStringCodec{})

}
