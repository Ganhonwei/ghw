package ujson

import (
	"server/internals/utils/utypes"

	jsoniter "github.com/json-iterator/go"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

func Marshal(v interface{}) ([]byte, error) {
	return jsoniter.Marshal(v)
}

func Marshal2(v interface{}) []byte {
	r, _ := jsoniter.Marshal(v)
	return r
}

// MarshalIndent same as json.MarshalIndent. Prefix is not supported.
func MarshalIndent(v interface{}, prefix, indent string) ([]byte, error) {
	return jsoniter.MarshalIndent(v, prefix, indent)
}

// MarshalToString convenient method to write as string instead of []byte
func MarshalToString(v interface{}) (string, error) {
	return jsoniter.MarshalToString(v)
}

// MarshalToString2 convenient method to write as string instead of []byte
func MarshalToString2(v interface{}) string {
	s, _ := jsoniter.MarshalToString(v)
	return s
}

func MarshalToStringIndent2(v interface{}) string {
	s, _ := MarshalIndent(v, "", "  ")
	return utypes.BytesToString(s)
}

func ProtoBufToJsonString(v proto.Message) string {
	b, _ := protojson.Marshal(v)
	return utypes.BytesToString(b)
}

func ProtoBufToJson(v proto.Message) []byte {
	b, _ := protojson.Marshal(v)
	return b
}

func JsonStringToProtoBuf[T any, PT interface {
	*T
	proto.Message
}](s string) (PT, error) {
	v := PT(new(T))
	err := protojson.Unmarshal([]byte(s), v)
	if err != nil {
		return nil, err
	}
	return v, nil
}

func JsonDataToObj[T any, PT interface{ *T }](s []byte) (PT, error) {
	v := PT(new(T))
	err := jsoniter.Unmarshal(s, v)
	if err != nil {
		return nil, err
	}
	return v, nil
}

func JsonStringToObj[T any, PT interface{ *T }](s string) (PT, error) {
	v := PT(new(T))
	err := jsoniter.UnmarshalFromString(s, v)
	if err != nil {
		return nil, err
	}
	return v, nil
}

func Unmarshal(data []byte, v interface{}) error {
	return jsoniter.Unmarshal(data, v)
}

// UnmarshalFromString is a convenient method to read from string instead of []byte
func UnmarshalFromString(str string, v interface{}) error {
	return jsoniter.UnmarshalFromString(str, v)
}
