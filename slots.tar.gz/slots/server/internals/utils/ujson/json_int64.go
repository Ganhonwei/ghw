package ujson

import (
	"fmt"
	"strconv"
	"unsafe"

	jsoniter "github.com/json-iterator/go"
)

type int64AsStringCodec struct {
}

func (codec *int64AsStringCodec) Decode(ptr unsafe.Pointer, iter *jsoniter.Iterator) {
	valueType := iter.WhatIsNext()
	switch valueType {
	case jsoniter.NilValue:
		*((*int64)(ptr)) = int64(0)
		break
	case jsoniter.NumberValue:
		*((*int64)(ptr)) = iter.ReadInt64()
		break
	case jsoniter.StringValue:

		var err error
		val := iter.ReadString()
		*((*int64)(ptr)), err = strconv.ParseInt(val, 10, 64)
		if err == nil {
			break
		}

		iter.ReportError("int64AsStringCodec.Decode", fmt.Sprintf("unexpected value: %+v", err.Error()))
		*((*int64)(ptr)) = int64(0)
		break
	}
}

func (codec *int64AsStringCodec) IsEmpty(ptr unsafe.Pointer) bool {
	return (*((*int64)(ptr))) == int64(0)
}
func (codec *int64AsStringCodec) Encode(ptr unsafe.Pointer, stream *jsoniter.Stream) {
	val := *((*int64)(ptr))
	// TODO 临时改下啊
	// stream.WriteString(strconv.FormatInt(val, 10))
	stream.WriteInt64(val)
}

func init() {

	jsoniter.RegisterTypeEncoder("int64", &int64AsStringCodec{})
	jsoniter.RegisterTypeDecoder("int64", &int64AsStringCodec{})

}
