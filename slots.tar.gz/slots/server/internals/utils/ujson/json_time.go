package ujson

import (
	"fmt"
	"time"
	"unsafe"

	jsoniter "github.com/json-iterator/go"
)

type timeAsInt64 struct {
}

func (codec *timeAsInt64) Decode(ptr unsafe.Pointer, iter *jsoniter.Iterator) {
	valueType := iter.WhatIsNext()
	switch valueType {
	case jsoniter.NilValue:
		*((*time.Time)(ptr)) = time.Unix(0, 0)
		break
	case jsoniter.NumberValue:
		*((*time.Time)(ptr)) = time.Unix(0, iter.ReadInt64()*int64(time.Millisecond))
		break
	case jsoniter.StringValue:
		var err error
		val := iter.ReadString()
		*((*time.Time)(ptr)), err = time.ParseInLocation(time.RFC3339, val, time.UTC)
		if err == nil {
			break
		}
		*((*time.Time)(ptr)), err = time.ParseInLocation(time.RFC3339Nano, val, time.UTC)
		if err == nil {
			break
		}

		*((*time.Time)(ptr)), err = time.ParseInLocation("2006-01-02T15:04:05.999Z07:00", val, time.UTC)
		if err == nil {
			break
		}
		iter.ReportError("timeAsInt64.Decode", fmt.Sprintf("unexpected value: %+v", err.Error()))
		*((*time.Time)(ptr)) = time.Unix(0, 0)
		break
	}
}

func (codec *timeAsInt64) IsEmpty(ptr unsafe.Pointer) bool {
	ts := *((*time.Time)(ptr))
	return ts.UnixNano() == 0
}
func (codec *timeAsInt64) Encode(ptr unsafe.Pointer, stream *jsoniter.Stream) {
	ts := *((*time.Time)(ptr))
	// stream.WriteString(ts..Format(time.RFC3339))
	stream.WriteInt64(ts.UnixNano() / int64(time.Millisecond))
}

func init() {

	jsoniter.RegisterTypeEncoder("time.Time", &timeAsInt64{})
	jsoniter.RegisterTypeDecoder("time.Time", &timeAsInt64{})

}
