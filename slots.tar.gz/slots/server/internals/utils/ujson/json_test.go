package ujson

import (
	"fmt"
	"server/internals/utils/umoney"
	"testing"
	"time"
)

func TestA(t *testing.T) {
	tests := []struct {
		name string
	}{
		{name: "x"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			A()
			mp := map[string]string{
				"amount": umoney.Fen2YuanFmt(123456), //金额按照元处理下单位
			}
			fmt.Println(mp["amount"])
		})
	}
}

type S struct {
	A  int64       `json:"a,omitempty"`
	A2 int64       `json:"a2,omitempty"`
	B  string      `json:"b,omitempty"`
	C  time.Time   `json:"c,omitempty"`
	D  *time.Time  `json:"d,omitempty"`
	E  []time.Time `json:"e,omitempty"`
}

func A() {

	// s := S{
	// 	A: 110,
	// 	B: "x",
	// 	C: time.Now(),
	// 	E: []time.Time{
	// 		time.Now(), time.Now(),
	// 	},
	// }

	// js, err := jsoniter.MarshalToString(s)
	// fmt.Println(js, err)

	// s2 := S{}
	// err = jsoniter.UnmarshalFromString(js, &s2)
	// logger.Printf("%+v, %+v\n", s2, err)

	// js, err = jsoniter.MarshalToString(s)
	// fmt.Println(js, err)

	// s3 := S{}

	// err = jsoniter.UnmarshalFromString(`

	// {"a":1,"b":"x","c":"2021-03-32T06:55:35Z","e":["2021-03-23T06:55:35Z","2021-03-23T06:55:35Z"]}

	// `, &s3)
	// logger.Printf("%+v, %+v\n", s3, err)

	// fmt.Println("")

}
