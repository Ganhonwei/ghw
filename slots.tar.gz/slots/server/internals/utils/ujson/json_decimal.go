package ujson

// github.com/shopspring/decimal

import (
	"fmt"
	"math/big"
	"unsafe"

	jsoniter "github.com/json-iterator/go"
	"github.com/shopspring/decimal"
)

type Decimalcodec struct {
}

func (codec *Decimalcodec) Decode(ptr unsafe.Pointer, iter *jsoniter.Iterator) {
	valueType := iter.WhatIsNext()
	switch valueType {
	case jsoniter.NilValue:
		*((*decimal.Decimal)(ptr)) = decimal.NewFromInt(0)
	case jsoniter.NumberValue:
		v := iter.ReadBigFloat()

		v = v.Mul(v, big.NewFloat(100))
		vv, _ := v.Int(nil)

		*((*decimal.Decimal)(ptr)) = decimal.NewFromBigInt(vv, 0)

	case jsoniter.StringValue:

		val := iter.ReadString()

		v, _, err := big.ParseFloat(val, 10, big.MaxPrec, big.ToZero)
		if err != nil {
			iter.ReportError("Decimalcodec.Decode", fmt.Sprintf("unexpected value: %+v", err.Error()))
			break
		}
		v = v.Mul(v, big.NewFloat(100))
		vv, _ := v.Int(nil)

		*((*decimal.Decimal)(ptr)) = decimal.NewFromBigInt(vv, 0)
	}
}

func (codec *Decimalcodec) IsEmpty(ptr unsafe.Pointer) bool {
	return false
}

func (codec *Decimalcodec) Encode(ptr unsafe.Pointer, stream *jsoniter.Stream) {
	v := *((*decimal.Decimal)(ptr))
	stream.WriteRaw(v.String())
}

func init() {

	// jsoniter.RegisterTypeEncoder("github.com/shopspring/decimal.Decimal", &Decimalcodec{})
	// jsoniter.RegisterTypeDecoder("github.com/shopspring/decimal.Decimal", &Decimalcodec{})

}
