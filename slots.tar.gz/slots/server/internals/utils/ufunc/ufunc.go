package ufunc

import (
	"errors"
	"fmt"

	"server/internals/logger"
	"server/internals/utils/uruntime"
)

func SafeGo(f func()) {
	go SafeFunc(f)
}

func AutoRestartGo(f func() error) {
	go func() {
		ch := make(chan error)
		defer close(ch)

		for {
			go func() {
				defer func() {
					if err := recover(); err != nil {
						if len(ch) == 0 {
							err_, ok := err.(error)
							if ok {
								ch <- err_
							} else {
								ch <- fmt.Errorf("%v\n", err)
							}
						}
					} else {
						if len(ch) == 0 {
							ch <- errors.New("panic with nil")
						}
					}
				}()

				err := f()
				ch <- err
			}()

			e := <-ch
			if e == nil {
				return
			}
			logger.Error(e)
		}
	}()
}

func SafeFunc(f func()) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("SafeFunc: %v, %v", err, string(uruntime.CallStack(1)))
		}
	}()

	f()
}

func SafeFuncWithMessage(message string, f func()) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("%#v - %#v\n", message, err)
		}
	}()

	f()
}
