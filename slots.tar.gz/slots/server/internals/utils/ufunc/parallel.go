package ufunc

import (
	"fmt"
	"reflect"
	"sync"

	"golang.org/x/sync/errgroup"

	"server/internals/logger"
	"server/internals/utils/uruntime"
)

func RunParallel(fs ...func() error) error {
	// TODO add call from
	eg := errgroup.Group{}
	for i := range fs {
		f := fs[i]
		eg.Go(func() (err error) {
			defer func() {
				if e := recover(); e != nil {
					//panic(e)
					err = fmt.Errorf("%v", e)

					logger.Debugf("RunParallel: %v", err)
					logger.Debugf("RunParallel: %v", string(uruntime.CallStack(0)))

				}
			}()
			err = f()
			return
		})
	}
	return eg.Wait()
}

// RunAsync
// todo panic callback or log
func RunAsync(target interface{}, cb interface{}, args ...interface{}) {
	go func() {
		targetValue := reflect.ValueOf(target)
		cbValue := reflect.ValueOf(cb)
		var argValues []reflect.Value
		for _, arg := range args {
			argValues = append(argValues, reflect.ValueOf(arg))
		}
		rtvValues := targetValue.Call(argValues)
		cbValue.Call(rtvValues)
	}()
}

func HandleParallel[S []T, T any](l S, f func(v T) error) {
	if len(l) == 0 {
		return
	}

	wg := sync.WaitGroup{}
	wg.Add(len(l))
	for _, v := range l {
		arg := v
		go func() {
			defer wg.Done()
			_ = f(arg) // todo err handle
		}()
	}

	wg.Wait()
}

func HandleParallelN[S []T, T any](nParallel int, s S, f func(v T)) {
	if len(s) == 0 {
		return
	}

	ch := make(chan T, nParallel)
	wg := sync.WaitGroup{}
	wg.Add(nParallel)

	for i := 0; i < nParallel; i++ {
		go func() {
			defer wg.Done()
			for arg := range ch {
				SafeFunc(func() {
					f(arg)
				})
			}
		}()
	}

	for _, v := range s {
		ch <- v
	}

	close(ch)
	wg.Wait()
}
