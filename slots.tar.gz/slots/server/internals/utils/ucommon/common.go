package ucommon

func PageToOffset(page, pageSize, nums int) (offset, limit int) {
	if page <= 0 || pageSize <= 0 {
		return 0, 40
	}
	// totalpages := int(math.Ceil(float64(nums) / float64(pageSize))) //page总数
	// if page > totalpages {
	// 	page = totalpages
	// }
	offset = int((page - 1) * pageSize)
	if offset < 0 {
		offset = 0
	}

	return offset, int(pageSize)
}

func PageToOffset2(page, pageSize int) (offset, limit int) {
	if page <= 0 || pageSize <= 0 {
		return 0, 40
	}
	offset = int((page - 1) * pageSize)
	if offset < 0 {
		offset = 0
	}

	return offset, int(pageSize)
}
