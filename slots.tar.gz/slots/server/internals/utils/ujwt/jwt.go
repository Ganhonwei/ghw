package ujwt

import (
	"server/internals/utils/utypes"
	"time"

	"github.com/pascaldekloe/jwt"
)

var Bearer = []byte("Bearer ")

func Check(secret []byte, authData []byte) (*jwt.Claims, bool) {
	c, err := jwt.HMACCheck(authData, secret)
	if err != nil {
		return nil, false
	}

	if !c.Valid(time.Now()) {
		return nil, false
	}

	return c, true
}

type Option func(c *jwt.Claims)

func WithString(k, v string) Option {
	return func(c *jwt.Claims) {
		c.Set[k] = v
	}
}

func WithIssued(t time.Time) Option {
	return func(c *jwt.Claims) {
		c.Issued = jwt.NewNumericTime(t.Round(time.Second))
	}
}

func WithExpires(nSec int) Option {
	return func(c *jwt.Claims) {
		c.Expires = jwt.NewNumericTime(time.Now().Add(time.Duration(nSec) * time.Second).Round(time.Second))
	}
}

func MakeJwtString(secret []byte, jti, sub string, opts ...Option) string {
	return utypes.BytesToString(MakeJwt(secret, jti, sub, opts...))
}

func MakeJwt(secret []byte, jti, sub string, opts ...Option) []byte {
	c := &jwt.Claims{
		Registered: jwt.Registered{
			ID:      jti,
			Subject: sub,
		},
		Set: map[string]interface{}{},
	}
	for _, opt := range opts {
		opt(c)
	}

	token, _ := c.HMACSign(jwt.HS256, secret)
	return token
}
