package ufirebase

import (
	"context"
	"log"

	firebase "firebase.google.com/go/v4"
	"firebase.google.com/go/v4/messaging"
	"google.golang.org/api/option"
)

var fbApp *firebase.App

func init() {
	opt := option.WithCredentialsFile("confs/supwin777-3499a-firebase-adminsdk-fbsvc-c8b83be31b.json")
	app, err := firebase.NewApp(context.Background(), nil, opt)
	if err != nil {
		log.Fatalf("error initializing app: %v", err)
		panic(err)
	}

	fbApp = app
}

func SendBatch(ctx context.Context, tokens []string, title, message string) (*messaging.BatchResponse, error) {
	mc, err := fbApp.Messaging(ctx)
	if err != nil {
		return nil, err
	}

	m := &messaging.MulticastMessage{
		Tokens: tokens,
		Notification: &messaging.Notification{
			Title: title,
			Body:  message,
		},
	}
	resp, err := mc.SendEachForMulticast(ctx, m)
	return resp, err
}

func SendEach(ctx context.Context, messages []*messaging.Message) (*messaging.BatchResponse, error) {
	mc, err := fbApp.Messaging(ctx)
	if err != nil {
		return nil, err
	}
	resp, err := mc.SendEach(ctx, messages)
	return resp, err
}

func SendPlayer(ctx context.Context, token string, title, message string) error {

	mc, err := fbApp.Messaging(ctx)
	if err != nil {
		return err
	}

	m := &messaging.Message{
		Notification: &messaging.Notification{
			Title: title,
			Body:  message,
		},
		Token: token,
	}
	_, err = mc.Send(ctx, m)
	return err
}
