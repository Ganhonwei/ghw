package uadmin

import (
	"net"
	"strconv"
	"strings"
)

// 参数规格
func ArgsPecification(str string) (string, string) {
	var argsKey string
	var argsValue string
	i := strings.LastIndex(str, "&")
	argsKey = str[1:i]
	argsValue = str[i+1:]
	return argsKey, argsValue
}

// 检查IP和端口的规格
func CheckIPAddressAndPortFormat(host string) bool {
	i := strings.Index(host, ":")
	if i != -1 {
		ip := host[:i]
		if ip := net.ParseIP(ip); ip == nil {
			return false
		}
		port, err := strconv.Atoi(host[i+1:])
		if err != nil {

			return false
		}
		if port < 0 || port > 65535 {

			return false
		}
	} else {
		if ip := net.ParseIP(host); ip == nil {
			return false
		}
	}
	return true
}
