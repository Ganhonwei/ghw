package uadmin

import (
	"bytes"
	"encoding/binary"

	captcha "github.com/mojocn/base64Captcha"
)

var (
	driver *captcha.DriverString
)

func init() {
	driver = new(captcha.DriverString)
	driver.Height = 44
	driver.Width = 120
	driver.NoiseCount = 5
	driver.ShowLineOptions = captcha.OptionShowSineLine | captcha.OptionShowSlimeLine | captcha.OptionShowHollowLine
	driver.Length = 4
	driver.Source = "1234567890qwertyuipkjhgfdsazxcvbnm"
	driver.Fonts = []string{"wqy-microhei.ttc"}
	driver.ConvertFonts()
}

func GenerateCaptchaHandler() (string, captcha.Item, error) {
	id, q, a := driver.GenerateIdQuestionAnswer()
	err := captcha.DefaultMemStore.Set(id, a)
	if err != nil {
		return "", nil, err
	}
	itm, err := driver.DrawCaptcha(q)
	if err != nil {
		return "", nil, err
	}
	return id, itm, err
}

func Verify(id, a string) bool {
	s := captcha.DefaultMemStore.Get(id, true)

	return s == a
}

func IntToBytes(n int64) []byte {
	x := int32(n)

	bytesBuffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(bytesBuffer, binary.BigEndian, x)

	return bytesBuffer.Bytes()
}
