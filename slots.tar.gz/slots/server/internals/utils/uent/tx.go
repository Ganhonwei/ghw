package uent

import (
	"context"
	"fmt"
	"server/ent/core_db"
	"server/internals/db/dbcore"
)

func WithTx(ctx context.Context, fn func(ctx2 context.Context, tx *core_db.Tx) error) error {
	tx, err := dbcore.Cli.Tx(ctx)
	if err != nil {
		return err
	}
	defer func() {
		if v := recover(); v != nil {
			tx.Rollback()
			panic(v)
		}
	}()
	if err = fn(ctx, tx); err != nil {
		if rerr := tx.Rollback(); rerr != nil {
			err = fmt.Errorf("rolling back transaction: %w", rerr)
		}
		return err
	}
	if err = tx.Commit(); err != nil {
		return fmt.Errorf("committing transaction: %w", err)
	}
	return nil
}
