package uent

import (
	"server/ent/core_db/account"

	"entgo.io/ent/dialect/sql"
)

// func AddWithdrawNeedBet(needBetAmount int64) func(u *sql.UpdateBuilder) {
// 	return func(u *sql.UpdateBuilder) {
// 		u.Set(account.FieldWithdrawNeedBet, sql.ExprFunc(func(b *sql.Builder) {
// 			b.Ident("if(").
// 				Ident(account.FieldWithdrawNeedBet).WriteOp(sql.OpAdd).Arg(needBetAmount).WriteOp(sql.OpLT).Arg(0).
// 				Comma().
// 				Arg(0).
// 				Comma().
// 				Ident(account.FieldWithdrawNeedBet).WriteOp(sql.OpAdd).Arg(needBetAmount).
// 				Ident(")")
// 		}))
// 	}
// }

func AddWithdrawCompBet(compBetAmount int64) func(u *sql.UpdateBuilder) {
	return func(u *sql.UpdateBuilder) {
		u.Set(account.FieldWithdrawCompBet, sql.ExprFunc(func(b *sql.Builder) {
			if compBetAmount < 0 { //结算后冲正
				b.Arg(sql.Raw("if(")).
					Ident(account.FieldWithdrawCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).WriteOp(sql.OpLT).Arg("0").
					Comma().
					Arg("0").
					Comma().
					Ident(account.FieldWithdrawCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).
					Arg(sql.Raw(")"))
			} else { //下注
				b.Arg(sql.Raw("if(")).
					Ident(account.FieldWithdrawCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).WriteOp(sql.OpGT).Ident(account.FieldWithdrawNeedBet).
					Comma().
					Ident(account.FieldWithdrawNeedBet).
					Comma().
					Ident(account.FieldWithdrawCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).
					Arg(sql.Raw(")"))
			}
		}))
	}
}

func AddGoldCompBet(compBetAmount int64) func(u *sql.UpdateBuilder) {
	return func(u *sql.UpdateBuilder) {
		// u.Set(accountgold.FieldCompBet, sql.ExprFunc(func(b *sql.Builder) {
		// 	if compBetAmount < 0 { //结算后冲正
		// 		b.Arg(sql.Raw("if(")).
		// 			Ident(accountgold.FieldCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).WriteOp(sql.OpLT).Arg("0").
		// 			Comma().
		// 			Arg("0").
		// 			Comma().
		// 			Ident(accountgold.FieldCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).
		// 			Arg(sql.Raw(")"))
		// 	} else { //下注
		// 		b.Arg(sql.Raw("if(")).
		// 			Ident(accountgold.FieldCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).WriteOp(sql.OpGT).Ident(accountgold.FieldNeedBet).
		// 			Comma().
		// 			Ident(accountgold.FieldNeedBet).
		// 			Comma().
		// 			Ident(accountgold.FieldCompBet).WriteOp(sql.OpAdd).Arg(compBetAmount).
		// 			Arg(sql.Raw(")"))
		// 	}
		// }))
	}
}
