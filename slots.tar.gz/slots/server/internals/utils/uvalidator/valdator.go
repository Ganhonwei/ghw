package uvalidator

import (
	"server/internals/generated/core/errcode"
	"server/internals/perr"
	"regexp"

	"github.com/go-playground/validator/v10"
)

var ValidateImpl *validator.Validate = validator.New()

// 自定义验证错误
func CustomValidationErrors(f1 interface{}) error {
	if err := ValidateImpl.Struct(f1); err != nil {
		for _, err := range err.(validator.ValidationErrors) {
			return err
		}

	}
	return nil
}

var (
	regexVaildAccount = regexp.MustCompile(`^\w{6,18}$`)                                    //检验账号
	regexVaildMobile  = regexp.MustCompile(`^1[345789]{1}\d{9}$`)                           //检验手机号
	regexVaildEmail   = regexp.MustCompile(`^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$`) //检验邮箱
	regexVaildNumber  = regexp.MustCompile(`^[0-9]*$`)                                      //检验数字
	regexVaildYzm     = regexp.MustCompile(`^\d{4}$`)                                       //检验验证码
	regexVaildNick    = regexp.MustCompile(`^[A-Za-z0-9]{4,13}$`)                           //检验昵称
)

// 校验手机号
func ValiMobile(data string) error {
	match := regexVaildMobile.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_MobileFmtErr)
	}
	return nil
}

// 校验邮箱
func ValiEmail(data string) error {
	match := regexVaildEmail.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_EmailFmtErr)
	}
	return nil
}

// 校验登录账号
func ValiAccount(data string) error {
	match := regexVaildAccount.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_AccountFmtErr)
	}
	return nil
}

// 校验登录昵称
func ValiNick(data string) error {
	match := regexVaildNick.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_AccountFmtErr) //因为不支持新的错误码语言包，暂时用账号格式错误码
	}
	return nil
}

// 校验验证码
func ValiYzm(data string) error {
	match := regexVaildYzm.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_SmsErr)
	}
	return nil
}

// 校验全数字
func ValiNumber(data string, minSize, maxSize int) error {
	match := regexVaildNumber.MatchString(data)
	if !match {
		return perr.NewCodeError(errcode.ErrCode_MumberFmtErr)
	}
	size := len(data)
	if size < minSize || size > maxSize {
		return perr.NewCodeError(errcode.ErrCode_MumberFmtErr)
	}
	return nil
}
