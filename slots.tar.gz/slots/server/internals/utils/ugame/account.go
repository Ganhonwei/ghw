package ugame

import (
	"server/internals/utils/utime"
	"time"
)

func IsNewAccount(registerAt time.Time) bool {
	return utime.JakartaTime().Sub(registerAt) <= NewAccountIntervalDur
}

const (
	BackAccountIntervalDur = 7 * 24 * time.Hour
	NewAccountIntervalDur  = 24 * time.Hour
)

func IsBackAccount(lastLoginAt time.Time) bool {
	return utime.JakartaTime().Sub(lastLoginAt) >= BackAccountIntervalDur
}

func GetChangeGameUrlHost(gameUrl string) string {
	// u, _ := url.Parse(gameUrl)
	// return base32.HexEncoding.EncodeToString([]byte(u.Host)) + ".xxxx.com"
	return gameUrl
}
