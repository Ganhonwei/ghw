package umap

import "strings"

func HasKey[M ~map[K]V, K comparable, V any](m M, k K) bool {
	_, ok := m[k]
	return ok
}

func QueryParamToMap(p string) map[string]string {
	result := map[string]string{}
	ps := strings.Split(p, "&")
	for _, v := range ps {
		pp := strings.Split(v, "=")
		result[pp[0]] = pp[1]
	}
	return result
}
