package uipchecker

import (
	"server/internals/endpoint/router_builder"
	"server/internals/logger"
	"net"
	"net/http"

	"github.com/yl2chen/cidranger"
)

type IPChecker func(string) bool

func MakeIPChecker(ips []string) IPChecker {

	if len(ips) == 0 {
		return func(s string) bool { return true }
	}

	whiteIPCidr := cidranger.NewPCTrieRanger()

	for _, strIP := range ips {

		_, cidr, e := net.ParseCIDR(strIP)
		if e != nil {
			ip := net.ParseIP(strIP)
			if ip != nil {
				cidr = &net.IPNet{
					IP:   ip,
					Mask: net.IPv4Mask(255, 255, 255, 255),
				}
			} else {
				logger.Sys.Errorf("MakeIPChecker Invalid: IpWhite: %v, %v", strIP, e)
				continue
			}
		}
		_ = whiteIPCidr.Insert(cidranger.NewBasicRangerEntry(*cidr))
	}

	return func(s string) bool {
		ip := net.ParseIP(s)
		if ip != nil {
			inWhite, err := whiteIPCidr.Contains(ip)
			if err != nil {
				return false
			}
			return inWhite
		} else {
			return false
		}
	}

}

func MakeChecker(ips []string, l logger.Logger) func(*router_builder.RequestCtx) {

	if len(ips) == 0 {
		return func(rc *router_builder.RequestCtx) {}
	}

	checker := MakeIPChecker(ips)
	return func(rc *router_builder.RequestCtx) {
		ip := rc.GetClientIP()
		if !checker(ip) {
			l.Warnf("Invalid IP Addree callback cb service: %v", ip)
			rc.SetStatusCode(http.StatusForbidden)
			rc.Abort()
		}
	}
}
