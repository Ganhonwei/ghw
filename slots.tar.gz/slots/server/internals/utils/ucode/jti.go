package ucode

import (
	"encoding/binary"
	"encoding/hex"
	"server/internals/utils/uhash"
	"sync/atomic"
	"time"
)

var jtiCounter uint64 = 1
var jtiSignKey = []byte(uhash.SumSHA256("=N9V8e5eN6&FE^M", "mMem5QpZnUK6g4@f", "one9inPeking"))

func MakeJti() string {

	buf := make([]byte, 16)
	binary.LittleEndian.PutUint64(buf, uint64(time.Now().UnixNano()))
	binary.LittleEndian.PutUint64(buf[8:], atomic.AddUint64(&jtiCounter, 1))

	return hex.EncodeToString(uhash.SumKeccak256(jtiSignKey, buf))
}
