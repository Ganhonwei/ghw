package ucode

import (
	"server/internals/utils/uhash"
	"server/internals/utils/urand"
)

var challegeSelfKey = uhash.SumSHA256("c!h2a#l4l5e^g7e*k9e)y", "3ov14-ig", "one9four(")

func MakeChallegeCode() string {
	return genChallegeCode(urand.HexStrings(8))
}

func genChallegeCode(nonce string) string {
	return nonce + uhash.SumSHA256(nonce, challegeSelfKey)[:8]
}

func ValidateChallegeCode(code string) bool {
	if len(code) != 16 {
		return false
	}

	return genChallegeCode(code[:8]) == code
}
