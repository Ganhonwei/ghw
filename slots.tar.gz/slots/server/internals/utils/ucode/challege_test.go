package ucode

import (
	"fmt"
	"testing"
)

func TestGenCode(t *testing.T) {
	code := MakeChallegeCode()
	fmt.Println(code)
}
