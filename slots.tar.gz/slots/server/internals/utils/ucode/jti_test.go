package ucode

import "testing"

func TestMakeJti(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		{name: "aa1", want: "want"},
		{name: "aa2", want: "want"},
		{name: "aa3", want: "want"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := MakeJti(); got != tt.want {
				t.Errorf("MakeJti() = %v, want %v", got, tt.want)
			}
		})
	}
}
