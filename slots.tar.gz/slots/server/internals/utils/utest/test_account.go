package utest

import (
	"fmt"
	"strconv"
	"strings"
)

var testWorkAccounts = map[string]struct{}{
	"+62999888888880": {}, // for google
	"+62999888888881": {}, // for google
	"+62999888888882": {}, // for google
	"+62999888888883": {}, // for google
	"+62999888888884": {}, // for google

	"+62999888888810": {}, // for pg soft
	"+62999888888811": {}, // for joker
	"+62999888888012": {}, // for pp
	"+62999888888013": {}, // for pp
}

func IsTestWorkAccount(s string) bool {
	if !strings.HasPrefix(s, "+62") {
		s = fmt.Sprintf("+62%v", s)
	}
	_, found := testWorkAccounts[s]
	return found
}

func IsTestPhone(s string) (string, bool) {
	if strings.HasPrefix(s, "+62999") {
		return s, true
	}
	if strings.HasPrefix(s, "999") {
		return "+62" + s, true
	}
	return s, false
}

func GetTestPhoneSms(s string) string {
	c := s[len(s)-4:]
	sms, _ := strconv.ParseInt(c, 10, 64)
	code := sms + 1
	return fmt.Sprintf("%v", code)
}
