package umoney

import (
	"fmt"
	"server/internals/configs/g"
	"strconv"

	"github.com/shopspring/decimal"
	"golang.org/x/text/language"
	"golang.org/x/text/message"
)

func Fen2YuanPrintFmt(fen int64, rate float64) string {
	d := decimal.NewFromFloat(rate)
	idr := Fen2YuanFmt(fen)
	if idr == "" {
		idr = "0"
	}
	dao := decimal.NewFromInt(fen).Mul(d).IntPart()
	usd := Fen2YuanFmt(dao)
	if usd == "" {
		usd = "0"
	}
	//return fmt.Sprintf("Rp %v , %v$", idr, usd)
	return fmt.Sprintf("%v , %v", idr, usd)
}

func Fen2YuanFmt(fen int64) string {
	p := message.NewPrinter(language.English)
	d := decimal.New(1, 2)
	result := decimal.NewFromInt(fen).DivRound(d, 2).String()
	r, _ := strconv.ParseFloat(result, 64)
	return p.Sprintf("%.2f", r)
}

func Fen2Yuan(fen int64) string {
	d := decimal.New(1, 2)
	result := decimal.NewFromInt(fen).DivRound(d, 2).String()
	return result
}

func Fen2IntYuan(fen int64) int64 {
	return fen / 100
	// d := decimal.New(1, 2)
	// result := decimal.NewFromInt(fen).DivRound(d, 2).String()
	// data, err := strconv.ParseInt(result, 10, 64)
	// if err != nil {
	// 	return 0
	// }
	// return data
}

func Yuan2Fen(yuan float64) int64 {
	d := decimal.New(1, 2)
	df := decimal.NewFromFloat(yuan).Mul(d).IntPart()
	//如果乘100后还有小数，就四舍五入后取整
	// d1 := decimal.New(1, 0)
	// dff := decimal.NewFromFloat(price).Mul(d).DivRound(d1, 0).IntPart()
	return df
}

func Yuan2IntFen(yuan int64) int64 {
	return yuan * 100
}

// 比例都是万分比
func GetFenCalcRateFen(fen int64, rate int64) int64 {
	r := decimal.NewFromInt(rate)
	d := decimal.NewFromInt(g.RateDivisor)
	f := decimal.NewFromInt(fen)
	df := r.Div(d).Mul(f).IntPart()
	return df
}

// 比例都是万分比
func GetRateCalcFen(fen int64, div int64) int64 {
	r := decimal.NewFromInt(fen)
	d := decimal.NewFromInt(g.RateDivisor)
	f := decimal.NewFromInt(div)
	df := r.Mul(d).Div(f).IntPart()
	return df
}

func GetFenCalcAvgFen(fen int64, count int64) int64 {
	r := decimal.NewFromInt(count)
	f := decimal.NewFromInt(fen)
	df := f.Div(r).IntPart()
	return df
}

func GetYuanCalcRateFen(fen int64, rate int64) string {
	return Fen2Yuan(GetFenCalcRateFen(fen, rate))
}

func ParseYuan(fen int64) decimal.Decimal {
	d := decimal.New(1, 2)
	result := decimal.NewFromInt(fen).DivRound(d, 2)
	return result
}

func ParseFen(yuan decimal.Decimal) int64 {
	d := decimal.New(1, 2)
	df := yuan.Mul(d).IntPart()
	return df
}

func YuanStrParseFen(yuan string) int64 {
	y, _ := decimal.NewFromString(yuan)
	d := decimal.New(1, 2)
	df := y.Mul(d).IntPart()
	return df
}

func MoneyToDecimal(money int64) decimal.Decimal {
	return decimal.New(money, -2)
}

func DecimalToMoney(yuan decimal.Decimal) int64 {
	d := decimal.New(1, 2)
	df := yuan.Mul(d).IntPart()
	return df
}

func MoneyToFloat(money int64) float64 {
	return float64(money) / 100
}

func FloatToMoney(y float64) int64 {
	yuan := decimal.NewFromFloat(y)
	d := decimal.New(1, 2)
	df := yuan.Mul(d).IntPart()
	return df
}

func GetPercent(x, y int64) float64 {
	xx := decimal.NewFromFloat(float64(x))
	yy := decimal.NewFromFloat(float64(y))
	d := decimal.New(1, 2)
	return xx.DivRound(yy, 4).Mul(d).InexactFloat64()
}

func GetPercent100(x, y int64) float64 {
	aa := decimal.NewFromFloat(float64(100))
	xx := decimal.NewFromFloat(float64(x))
	yy := decimal.NewFromFloat(float64(y))
	d := decimal.New(1, 2)
	return aa.Sub(xx.DivRound(yy, 4).Mul(d)).InexactFloat64()
}
