package umoney

import (
	"fmt"
	"testing"
)

func TestFen2YuanPrintFmt(t *testing.T) {
	x := int64(2075000000)
	y := int64(1334007866)
	r := GetPercent(y, x)
	r2 := GetPercent100(y, x)
	fmt.Println(fmt.Sprintf("%v%%", r))
	fmt.Println(fmt.Sprintf("%v%%", r2))

	testV := GetFenCalcRateFen(30000000, 10000)
	fmt.Sprintf("%v", testV)
}
