package utypes

import (
	"reflect"
	"unsafe"
)

func StringToBytes(s string) (b []byte) {
	sh := (*reflect.StringHeader)(unsafe.Pointer(&s))
	bh := (*reflect.SliceHeader)(unsafe.Pointer(&b))
	bh.Cap = sh.Len
	bh.Len = sh.Len
	bh.Data = sh.Data
	return b
}

func ToPointer[T any](v T) *T {
	r := new(T)
	*r = v
	return r
}
