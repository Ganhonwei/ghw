package utypes

import (
	"fmt"
	"unsafe"
)

func BytesToString(b []byte) string {
	return *(*string)(unsafe.Pointer(&b))
}

func BytesToStringError(b []byte) (string, error) {
	if b == nil {
		return "", fmt.Errorf("bytes is nil")
	}
	return *(*string)(unsafe.Pointer(&b)), nil
}

func DefaultValue[T any]() T {
	var r T
	return r
}
