package umath

import (
	"golang.org/x/exp/constraints"
	"math"
)

type Vec2[T constraints.Integer | constraints.Float] struct {
	X, Y T
}

func (v Vec2[T]) Add(v2 Vec2[T]) Vec2[T] {
	return Vec2[T]{
		X: v.X + v2.X,
		Y: v.Y + v2.Y,
	}
}

func (v Vec2[T]) AddXY(X, Y T) Vec2[T] {
	return Vec2[T]{
		X: v.X + X,
		Y: v.Y + Y,
	}
}

func DistancePower(x1, y1, x2, y2 int16) int32 {
	x := int32(x1 - x2)
	y := int32(y1 - y2)
	return x*x + y*y
}

func Within(x1, y1, x2, y2, r int16) bool {
	x := int32(x1 - x2)
	y := int32(y1 - y2)
	return x*x+y*y <= int32(r)*int32(r)
}

func Distance(x1, y1, x2, y2 int16) int16 {
	// todo 优化此处开方操作
	return int16(math.Sqrt(float64(DistancePower(x1, y1, x2, y2))))
}

// PointRotate 点x1,y1绕x2,y2顺时针旋转angle角度后得到的新坐标
func PointRotate(x1, y1, x2, y2 int32, angle float64) (int32, int32) {
	x := int32((float64(x1-x2) * Cos(angle)) - (float64(y1-y2) * Sin(angle)) + float64(x2))
	y := int32((float64(y1-y2) * Cos(angle)) + (float64(x1-x2) * Sin(angle)) + float64(y2))
	return x, y
}

func ManhattanDistance(x1, y1, x2, y2 int16) int16 {
	return Abs(x1-x2) + Abs(y1-y2)
}

// VecInterpolation 线段插值
func VecInterpolation[T constraints.Integer](x1, y1, x2, y2 T, percentage float64) (T, T) {
	return T(float64(x2-x1)*percentage) + x1, T(float64(y2-y1)*percentage) + y1
}
