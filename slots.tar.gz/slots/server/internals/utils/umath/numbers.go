package umath

import "golang.org/x/exp/constraints"

func Abs[T constraints.Integer | constraints.Float](v T) T {
	if v < 0 {
		return -v
	} else {
		return v
	}
}

func Max[T constraints.Integer | constraints.Float](v T, vs ...T) T {
	r := v
	for _, v = range vs {
		if v > r {
			r = v
		}
	}
	return r
}

func Min[T constraints.Integer | constraints.Float](v T, vs ...T) T {
	r := v
	for _, v = range vs {
		if v < r {
			r = v
		}
	}
	return r
}
