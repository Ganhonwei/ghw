package umath

import "math"

// 三角函数相关
// todo 做成查表

func Sin(angle float64) float64 {
	return math.Sin(angle)
}

func Cos(angle float64) float64 {
	return math.Cos(angle)
}

func Tan(angle float64) float64 {
	return math.Tan(angle)
}
