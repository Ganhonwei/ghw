package umath

type Rect struct {
	X1, Y1 int32
	X2, Y2 int32
	X3, Y3 int32
	X4, Y4 int32
}

func (rect Rect) IntersectWith(another Rect) bool {
	var r bool

	r = rect.IsPointIn(another.X1, another.Y1)
	if r {
		return r
	}

	r = rect.IsPointIn(another.X2, another.Y2)
	if r {
		return r
	}

	r = rect.IsPointIn(another.X3, another.Y3)
	if r {
		return r
	}

	r = rect.IsPointIn(another.X4, another.Y4)
	if r {
		return r
	}

	r = another.IsPointIn(rect.X1, rect.Y1)
	if r {
		return r
	}

	r = another.IsPointIn(rect.X2, rect.Y2)
	if r {
		return r
	}

	r = another.IsPointIn(rect.X3, rect.Y3)
	if r {
		return r
	}

	r = another.IsPointIn(rect.X4, rect.Y4)
	if r {
		return r
	}

	return r
}

func (rect Rect) IsPointIn(x, y int32) bool {
	return crossOf(rect.X1, rect.Y1, rect.X2, rect.Y2, x, y)*crossOf(rect.X3, rect.Y3, rect.X4, rect.Y4, x, y) >= 0 &&
		crossOf(rect.X2, rect.Y2, rect.X3, rect.Y3, x, y)*crossOf(rect.X4, rect.Y4, rect.X1, rect.Y1, x, y) >= 0
}

// 计算向量叉积
func crossOf(x1, y1, x2, y2, x3, y3 int32) int32 {
	return ((x2 - x1) * (y3 - y1)) - ((x3 - x1) * (y2 - y1))
}
