package urand

import (
	"server/internals/utils/utime"
	"math/rand"
)

var (
	randSet = rand.New(rand.NewSource(utime.JakartaTime().UnixMicro()))
)
