package urand

import (
	"server/internals/utils/uslice"
	"server/internals/utils/utypes"

	"golang.org/x/exp/constraints"
)

func Shuffle[T any](l []T) {
	randSet.Shuffle(len(l), func(i, j int) {
		l[i], l[j] = l[j], l[i]
	})
}

func RandomByWeight[T any](l []T, f func(v T) int32) (T, bool) {
	var weightSum int32
	weights := make([]int32, 0, len(l))
	for _, v := range l {
		weight := f(v)
		weights = append(weights, weight)
		weightSum += weight
	}
	n := randSet.Int31n(weightSum)

	var currentSum int32
	for i, weight := range weights {
		currentSum += weight
		if n < currentSum {
			return l[i], true
		}
	}

	return utypes.DefaultValue[T](), false
}

func RandomByWeightGetIndex[T any](l []T, f func(v T) int32) (T, int, bool) {
	var weightSum int32
	weights := make([]int32, 0, len(l))
	for _, v := range l {
		weight := f(v)
		weights = append(weights, weight)
		weightSum += weight
	}

	n := randSet.Int31n(weightSum)

	var currentSum int32
	for i, weight := range weights {
		currentSum += weight
		if n < currentSum {
			return l[i], i, true
		}
	}

	return utypes.DefaultValue[T](), 0, false
}

type randElem[T any] struct {
	Id int32
	V  T
}

// RandomNByWeight
// n总共随多少个出来
// max单元素随中上限
func RandomNByWeight[T any](l []T, n, max int32, allowPartial bool, f func(v T) int32) ([]T, bool) {
	rdItems := make([]*randElem[T], 0, n)
	for i, v := range l {
		rdItems = append(rdItems, &randElem[T]{
			Id: int32(i),
			V:  v,
		})
	}

	idCount := make(map[int32]int32, len(l))
	r := make([]T, 0, n)
	for int32(len(r)) < n && len(rdItems) > 0 {
		elem, ok := RandomByWeight(rdItems, func(v *randElem[T]) int32 {
			return f(v.V)
		})
		if !ok {
			if !allowPartial {
				return nil, false
			}
		}

		r = append(r, elem.V)
		if int32(len(r)) == n {
			return r, true
		} else {
			cnt := idCount[elem.Id]
			newCnt := cnt + 1
			if newCnt >= max {
				// 该元素随中次数已达上限，从随机列表中移除
				rdItems, _ = uslice.DeleteFirstFunc(rdItems, func(v *randElem[T]) bool {
					return elem == v
				})
			} else {
				idCount[elem.Id] = newCnt
			}
		}
	}

	if allowPartial {
		return r, true
	} else {
		return nil, false
	}
}

func RandomInRange[T constraints.Integer](left, right T, includeLeft, includeRight bool) T {
	if !includeLeft {
		left++
	}

	if includeRight {
		right++
	}

	diff := int64(right - left)
	non := diff < 0
	if non {
		diff = -diff
	}

	n := randSet.Int63n(diff)
	if non {
		n = -n
	}

	return left + T(n)
}

func RandomValueFromSlice[S ~[]T, T any](l S) T {
	if len(l) == 0 {
		return utypes.DefaultValue[T]()
	} else {
		return l[randSet.Intn(len(l))]
	}
}

func RandomKeyValueFromSlice[S ~[]T, T any](l S) (int, T) {
	if len(l) == 0 {
		return 0, utypes.DefaultValue[T]()
	} else {
		index := randSet.Intn(len(l))
		return index, l[index]
	}
}

func RandomPercent(v int32, scale int32) bool {
	return randSet.Int31n(scale) < v
}
