package urand

import (
	"server/internals/utils/utypes"
)

var hexChars = []byte("0123456789abcdef")
var hexCharsLen = len(hexChars)
var lowchars = []byte("abcdefghijklmnopqrstuvwxyz")
var lowcharsLen = len(lowchars)
var aZ09 = []byte("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
var aZ09Len = len(aZ09)

func HexStrings(length int) string {
	return randomStrings(hexChars, hexCharsLen, length)
}

func LowerStrings(length int) string {
	return randomStrings(lowchars, lowcharsLen, length)
}

func Strings(length int) string {
	return randomStrings([]byte(aZ09), aZ09Len, length)
}

func randomStrings(pool []byte, poolLen int, length int) string {
	out := make([]byte, 0, length)
	for i := 0; i < length; i++ {
		out = append(out, pool[randSet.Intn(poolLen)])
	}
	return utypes.BytesToString(out)
}
