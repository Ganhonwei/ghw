package ufacebook

import (
	"context"
	"fmt"
	"server/internals/utils/uhttp"
	"net/url"
)

type FacebookPicture struct {
	CacheKey string `json:"cache_key,omitempty"`
	Url      string `json:"url,omitempty"`
}

func GetUserPicture(ctx context.Context, userId int64, accessToken string) (pic *FacebookPicture, err error) {
	w := 200
	h := 200
	fields := url.QueryEscape("url,cache_key")

	url := fmt.Sprintf("https://graph.facebook.com/v16.0/%d/picture?width=%d&height=%d&fields=%s&access_token=%s",
		userId, w, h, fields, accessToken)
	resp, err := uhttp.GetCompressedObject[struct {
		Data *FacebookPicture `json:"data,omitempty"`
	}](url)
	if err != nil {
		return nil, err
	}
	return resp.Data, nil
}

type FacebookUserInfo struct {
	Id   int64  `json:"id,omitempty"`
	Name string `json:"name,omitempty"`
}

func GetUserInfo(ctx context.Context, accessToken string) (*FacebookUserInfo, error) {
	url := fmt.Sprintf("https://graph.facebook.com/v16.0/me?access_token=%s", accessToken)
	return uhttp.GetCompressedObject[FacebookUserInfo](url)
}
