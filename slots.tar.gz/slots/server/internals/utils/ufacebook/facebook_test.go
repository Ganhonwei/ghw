package ufacebook

import (
	"reflect"
	"testing"
)

func TestGetUserInfo(t *testing.T) {
	type args struct {
		accessToken string
	}
	tests := []struct {
		name    string
		args    args
		want    *FacebookUserInfo
		wantErr bool
	}{
		{
			name:    "lee jack",
			args:    args{accessToken: "EAAjbZBwrCTzoBAL8KC38VazgZAEi4gLrH8fKr4Cgx3swyau1whOybNoeJvaU8PmxaDL2cKt9mCqBrpC7EEwowY5LkWI6ydfre5ZBnJPxKdyLbZBLqfzAQZC9McRmRO3YRvYy7mWScYDaVwZAg5jvd8G5ecAQGmIhw2DhcBaK2ZBq1M8cPA52sAqtpm3VTT6cwDZBBnR0XLrhEarRurOZB3I63TLzzGSWWXXBgjQSaJ01fJgZDZD"},
			want:    &FacebookUserInfo{Id: 124193794002322, Name: "Lee Jack"},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetUserInfo(nil, tt.args.accessToken)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetUserInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetUserInfo() = %v, want %v", got, tt.want)
			}
		})
	}
}
