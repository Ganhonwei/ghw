package ucache

import (
	"server/internals/configs/g"
	"server/internals/core/ttl_cache"
	"server/internals/logger"
	"server/internals/utils/uruntime"
	"regexp"
	"sync"
	"time"

	"google.golang.org/protobuf/proto"
)

type LogicCache struct {
	cache *ttl_cache.TtlCache[any]
	lck   sync.Mutex
	locks map[string]*sync.Mutex
}

var logicCache *LogicCache

func init() {
	logicCache = &LogicCache{
		cache: ttl_cache.NewTtlCache[any](1 * time.Second),
		lck:   sync.Mutex{},
		locks: map[string]*sync.Mutex{},
	}
}

func Delete(key string) {

	logicCache.lck.Lock()
	if _, found := logicCache.locks[key]; !found {
		logicCache.locks[key] = &sync.Mutex{}
	}
	logicCache.lck.Unlock()

	// 防止 单个 key 被多次load
	logicCache.locks[key].Lock()
	defer logicCache.locks[key].Unlock()

	logicCache.cache.Delete(key)
}

func DeleteByExpr(expr string) {
	m, err := regexp.Compile(expr)
	if err != nil {
		return
	}

	remvedKeys := []string{}

	logicCache.cache.Range(func(key string, value any) bool {
		if m.MatchString(key) {
			remvedKeys = append(remvedKeys, key)
		}
		return true
	})

	for _, k := range remvedKeys {
		Delete(k)
	}
}

func GetOrUpdateSlice[KT Key, T proto.Message](key KT, getter func() ([]T, error), duration time.Duration) (v []T, e error) {
	v, _, e = getOrUpdateWithKey(key.Key(), getter, duration)
	return
}

// func init() {
// 	GetOrUpdateSlice(&CacheKey{}, func() ([]*pbauth.AccountLogVo, error) {
// 		return nil, nil
// 	}, g.PlatformContentCacheLevelLow)
// }

func GetOrUpdate[KT Key, T proto.Message](key KT, getter func() (T, error), duration time.Duration) (v T, e error) {
	v, _, e = getOrUpdateWithKey(key.Key(), getter, duration)
	return
}

func GetOrUpdateAny[KT Key, T any](key KT, getter func() (T, error), duration time.Duration) (v T, e error) {
	v, _, e = getOrUpdateWithKey(key.Key(), getter, duration)
	return
}

func GetOrUpdateAnyWithDoLoad[KT Key, T any](key KT, getter func() (T, error), duration time.Duration) (v T, doLoad bool, e error) {
	return getOrUpdateWithKey(key.Key(), getter, duration)
}

func getOrUpdateWithKey[T any](key string, getter func() (T, error), duration time.Duration) (v T, doLoad bool, e error) {

	if g.DumpLogicCacheLog {
		uruntime.CallByX(3, "getOrUpdateWithKey", key)
		logger.Debugln("getOrUpdateWithKey start ", key)
		defer logger.Debugln("getOrUpdateWithKey end ", key)
	}

	val, found := logicCache.cache.Get(key)
	if found {
		tv, _ := val.(T)
		return tv, false, nil
	}

	lck := (*sync.Mutex)(nil)
	logicCache.lck.Lock()
	if l, found := logicCache.locks[key]; !found {
		logicCache.locks[key] = &sync.Mutex{}
		lck = logicCache.locks[key]
	} else {
		lck = l
	}
	logicCache.lck.Unlock()

	// 防止 单个 key 被多次load
	lck.Lock()
	defer lck.Unlock()

	val, found = logicCache.cache.Get(key)
	if found {
		tv, _ := val.(T)
		return tv, false, nil
	}

	nv, err := getter()
	if err != nil {
		return v, true, err
	}

	logicCache.cache.Set(key, nv, duration)
	return nv, true, err
}
