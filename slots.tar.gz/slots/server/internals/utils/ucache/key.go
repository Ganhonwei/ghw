package ucache

import (
	"fmt"
)

var (
	KeyDynApi                        = NewCacheKeyP1[string]("dyn_api_%v", "dyn_api")
	KeyPackageRule                   = NewCacheKeyP1[string]("pkg_rules_%v", "pkg_rules")
	KeyWarnConfig                    = NewCacheKey("warn_config")
	KeySysConfig                     = NewCacheKey("sys_config")
	KeyAccountGetIndexAdData         = NewCacheKeyP1[string]("account_getIndexAdData_%v", "account_getIndexAdData")          //Advertise
	KeyAuthGetLauncherAd             = NewCacheKey("auth_getLauncherAd")                                                     //Advertise
	KeyAccountGetIndexFWData         = NewCacheKeyP1[string]("account_getIndexFWData_%v", "account_getIndexFWData")          //floatingWindow
	KeyAuthGetLauncherFW             = NewCacheKey("auth_getLauncherFW")                                                     //floatingWindow
	KeyAccountGetIndexMsgData        = NewCacheKeyP1[string]("account_getIndexMsgData_%v", "account_getIndexMsgData")        //Marquee
	KeyGetIndexMsgHash               = NewCacheKeyP1[string]("get_index_msg_hash_%v", "get_index_msg_hash")                  //Marquee
	KeyAccountGetIndexTagData        = NewCacheKey("account_getIndexTagData")                                                //Gametag
	KeyAccountGetIndexTagFunData     = NewCacheKey("account_getIndexTagFunData")                                             //Gametag
	KeyAccountGetBankList            = NewCacheKey("account_getBankList")                                                    //Withdrawbank
	KeyAccountGetAvatarList          = NewCacheKey("account_getAvatarList")                                                  //Accountavatar
	KeyGetNotices                    = NewCacheKeyP1[string]("get_notices_pkg_%v", "get_notices_pkg")                        //Notice
	KeyGetCatNotices                 = NewCacheKeyP1[string]("get_cat_notices_pkg_%v", "get_cat_notices_pkg")                //CatNotice
	KeyAuthGetConfig                 = NewCacheKey("auth_getConfig")                                                         //Sysconfig
	KeyAccountGetVipData             = NewCacheKey("account_getVipData")                                                     //
	KeyAccountGetVipConfig           = NewCacheKeyP1[int64]("account_getVipConfig_%v", "account_getVipConfig")               //
	KeyAccountGetVipConfigList       = NewCacheKeyP1[int64]("account_getVipConfig_list_%v", "account_getVipConfig_list")     //
	KeyAccountGetVipPoolAmount       = NewCacheKey("account_getVipPoolAmount")                                               //
	KeyAccountGetVipPoolAllRecord    = NewCacheKeyP1[int32]("account_getVipPoolAllRecord_%v", "account_getVipPoolAllRecord") //
	KeyAccountGetVipPoolMyRecord     = NewCacheKeyP1[string]("account_getVipPoolMyRecord_%v", "account_getVipPoolMyRecord")
	KeyAccountGetAgentById           = NewCacheKeyP1[int64]("account_getAgent_by_id_%v", "account_getAgent_by_id")          //acctagent
	KeyAccountPromotionById          = NewCacheKeyP1[int64]("account_promotion_by_id_%v", "account_promotion_by_id")        //推广佣金
	KeyAccountAgentFriendsById       = NewCacheKeyP1[string]("account_agent_friend_by_id_%v", "account_agent_friend_by_id") //推广好友
	KeyAgentWithDrawRecord           = NewCacheKey("agent_withdraw")
	KeyJackPotDrawRecord             = NewCacheKey("jack_pot_draw")
	KeyJackPotDrawRank               = NewCacheKey("jack_pot_rank")
	KeyEmailGetEmailList             = NewCacheKeyP1[string]("email_getEmailList_%v", "email_getEmailList")                                        //Email
	KeyActivityConfig                = NewCacheKeyP1[string]("activity_config_%v", "activity_config")                                              //
	KeyActivityConfigId              = NewCacheKeyP1[int64]("activity_config_id_%v", "activity_config_id")                                         //
	KeyActivityCodeConfigId          = NewCacheKeyP1[int64]("activity_config_code_id_%v", "activity_config_code_id")                               //
	KeyQueryByShouChong              = NewCacheKeyP1[int64]("activity_queryByShouChong_%v", "activity_queryByShouChong")                           //Activity
	KeyGetConfigByShouChongResp      = NewCacheKey("activity_getConfigByShouChongResp")                                                            //
	KeyGetConfigByShouCiChongZhiResp = NewCacheKeyP1[int64]("activity_getConfigByShouCiChongZhiResp_%v", "activity_getConfigByShouCiChongZhiResp") //
	KeyGetConfigByQianDaoResp        = NewCacheKeyP1[int64]("activity_getConfigByQianDaoResp_%v", "activity_getConfigByQianDaoResp")               //
	KeyGetListByHongBaoYuResp        = NewCacheKeyP1[int64]("activity_getListByHongBaoYuResp_%v", "activity_getListByHongBaoYuResp")               //
	KeyFanShuiGetInfo                = NewCacheKeyP1[int64]("activity_fs_getInfo_%v", "activity_fs_getInfo")                                       //
	KeyActivityDesc                  = NewCacheKeyP1[string]("activity_desc_%v", "activity_desc")                                                  //
	KeyFanShuiConfig                 = NewCacheKey("activity_fs_getCfg")                                                                           //Activity
	KeyGetRuleByVal                  = NewCacheKey("get_rule_by_val")                                                                              //Apploginrule
	KeyGetRuleByValPkg               = NewCacheKeyP1[string]("get_rule_by_val_pkg", "get_rule_by_val_pkg")                                         //Apploginrule
	KeyGetRechargeWayList            = NewCacheKeyP1[int64]("get_recharge_way_list", "get_recharge_way_List")                                      //RechargeWay
	KeyGetRechargeChannelList        = NewCacheKeyP1[int64]("get_recharge_channel_list", "get_recharge_channel_list")                              //RechargeChannel
	KeyGetRechargeChannelByCode      = NewCacheKey("get_recharge_channel_by_code")                                                                 //RechargeChannel
	KeyGetRechargeChannelById        = NewCacheKeyP1[int64]("get_recharge_channel_by_id:%v", "get_recharge_channel_by_id")                         //RechargeChannel
	KeyGameCompanyEnable             = NewCacheKey("game_company_enable")                                                                          //GameCompany
	KeyGameCompanyById               = NewCacheKeyP1[int64]("game_company_id_%v", "game_company_id")                                               //GameCompany
	KeyGameCompanyByCode             = NewCacheKeyP1[string]("game_company_code_%v", "game_company_code")                                          //GameCompany
	KeyAcctByIdMessage               = NewCacheKeyP1[int64]("acct_message_by_id_%v", "acct_message_by_id")                                         //Account
	KeyGameById                      = NewCacheKeyP1[int64]("game_by_id_%v", "game_by_id")
	KeyGameCollectById               = NewCacheKeyP1[int64]("game_collect_by_id_%v", "game_collect_by_id")
	KeyGameByIdWithTag               = NewCacheKeyP1[int64]("game_by_id_with_tag_%v", "game_by_id_with_tag") //Game
	GetTagIdByGameId                 = NewCacheKeyP1[int64]("Get)Tag_Id_By_Game_Id_%v", "Tag_Id_By_Game_Id")
	KeyGameByTip                     = NewCacheKey("game_by_tip")                                                                                         //Game
	KeyGetGameByCidAndCode           = NewCacheKeyP1[string]("game_by_cid_code_%v", "game_by_cid_code_")                                                  //Game
	KeyGameIsUserGameTag             = NewCacheKeyP1[int64]("game_isUserGameTag_%v", "game_isUserGameTag")                                                //Game
	KeyGameGetRtpGameByTagId         = NewCacheKeyP5[string, int64, int64, int32, bool]("game_getRtpGame_%v_%v_%v_%v_%v", "game_getRtpGame")              //Game
	KeyGameGetIndexGameByTagId       = NewCacheKeyP6[string, int64, int64, int32, bool, bool]("game_getIndexGame_%v_%v_%v_%v_%v_%v", "game_getIndexGame") //Game
	KeyGameGetIndexGameByTagIdRec    = NewCacheKeyP4[string, int64, int32, bool]("game_getIndexGame_rec_%v_%v_%v_%v", "game_getIndexGame_rec")            //Game
	KeyGameGetIndexCollectGame       = NewCacheKeyP2[int64, int32]("Key_Game_Get_Index_Collect_Game_%v_%v", "Key_Game_Get_Index_Collect_Game")            //Game
	KeyGameGetPkgGame                = NewCacheKeyP1[string]("game_getPkgGame_%v", "game_getPkgGame")                                                     //Game
	KeyCheckVersion                  = NewCacheKeyP2[string, int64]("vheck_version_%v_%v", "vheck_version")                                               //Appversion
	KeyCheckVersionHot               = NewCacheKeyP2[string, int64]("vheck_version_hot_%v_%v", "vheck_version_hot")                                       //Appversion
	KeyApkSrc                        = NewCacheKeyP2[string, int64]("apk_scr_%v_%v", "apk_scr_")                                                          //Appversion
	KeyGetVersonByVal                = NewCacheKeyP3[string, string, int64]("get_version_by_bal_%v_%v_%v", "get_version_by_bal")                          //AppVersion
	KeyGetLatestVersonByPkg          = NewCacheKeyP1[string]("get_latest_verson_by_pkg_%v", "get_latest_verson_by_pkg")                                   //AppVersion
	KeyGetLatestVersonByPkg2         = NewCacheKeyP1[string]("get_latest_verson_by_pkg_%v", "get_latest_verson_by_pkg")                                   //AppVersion
	KeyGetVersonByVer                = NewCacheKeyP2[string, string]("get_verson_by_ver_%v_%v", "get_verson_by_ver")                                      //AppVersion
	KeyListMessage                   = NewCacheKeyP1[int64]("key_list_message_%v", "key_list_message")
	KeyGetVipPoolTotalAmount         = NewCacheKey("get_vip_pool_total_amount")                                             //Activity
	KeyProductList                   = NewCacheKey("product_list")                                                          //GoogleProduct
	KeyMatchAccountChannel           = NewCacheKeyP1[int64]("match_account_channel_%v", "match_account_channel")            //GoogleProduct
	KeyGetByChannelId                = NewCacheKeyP1[int64]("key_get_channel_id_%v", "key_get_channel_id")                  //GoogleProduct
	KeyGetVipPoolForAddRate          = NewCacheKey("get_vip_pool_for_add_rate")                                             //ActivityVipPool
	KeyGetOfficialPkgName            = NewCacheKey("get_official_pkg_name")                                                 //ActivityVipPool
	KeyGetRechargeWayByCode          = NewCacheKeyP1[string]("get_recharge_way_by_code_%v", "get_recharge_way_by_code")     //RechargeWay
	KeyGetRechargeWayAByCode         = NewCacheKeyP1[string]("get_recharge_way_by_code_a_%v", "get_recharge_way_by_code_a") //RechargeWayA面
	KeyGetAppPackage                 = NewCacheKeyP1[string]("key_get_app_package_%v", "key_get_app_package")
	KeyGetAppAdvertise               = NewCacheKeyP1[string]("key_get_app_advertise_%v", "key_get_app_advertise")
	KeyGetAppKey                     = NewCacheKeyP2[string, string]("key_get_app_key_%v_%v", "key_get_app_key")
	KeyAesHash                       = NewCacheKeyP1[string]("key_aes_hash_%v", "key_aes_hash")
	KeyHostPwd                       = NewCacheKeyP2[string, string]("key_host_pwd_%v_%v", "key_host_pwd")
	KeyGoogleIapConfigList           = NewCacheKey("key_google_iap_config_list")                                        //GoogleIapConfig
	KeyGoogleIapConfig               = NewCacheKeyP1[string]("key_google_iap_config_%v", "key_google_iap_config")       //GoogleIapConfig
	KeyRechargeLbList                = NewCacheKeyP1[string]("key_recharge_lb_list_%v", "key_recharge_lb_list")         //ActivityRecharge
	KeyRechargeActList               = NewCacheKeyP1[string]("key_recharge_act_list_%v", "key_recharge_act_list")       //ActivityRecharge
	KeyRechargeFavActList            = NewCacheKey("key_recharge_fav_act_list")                                         //ActivityRecharge
	KeyRechargeFavActId              = NewCacheKeyP1[int64]("Key_Recharge_Fav_Act_Id_%v", "Key_Recharge_Fav_Act_Id")    //ActivityRecharge
	KeyActivityRechargeId            = NewCacheKeyP1[int64]("Key_Activity_Recharge_Id_%v", "Key_Activity_Recharge_Id_") //ActivityRecharge
	KeyWinMessage                    = NewCacheKeyP1[string]("key_win_message_%v", "key_win_message")                   //
	KeyThirdUserId                   = NewCacheKeyP1[string]("third_user_id_%v", "third_user_id")                       //
	KeyGetPkgJsonStr                 = NewCacheKeyP1[string]("get_pkg_json_str%v", "get_pkg_json_str")                  //
	KeyGetPkgCfg                     = NewCacheKeyP1[string]("get_pkg_cfg_%v", "get_pkg_cfg")                           //
	KeyEnableProxyList               = NewCacheKey("key_enable_proxy_list")
	KeyGetHostByCompanyId            = NewCacheKeyP1[int64]("key_get_host_ny_company_id_%v", "key_get_host_ny_company_id") //RechargeWay
	KeyGetHostByCache                = NewCacheKeyP1[string]("key_get_host_by_cache_%v", "key_get_host_by_cache")          //
	KeyGetLangPack                   = NewCacheKeyP2[string, int64]("key_get_lang_pack_%v_%v", "key_get_lang_pack")        //
	KeyGetAvatarList                 = NewCacheKey("Key_Get_Avatar_List")
	KeyCacheLastDataFl               = NewCacheKeyP1[int64]("key_cache_last_data_fl_%v", "key_cache_last_data_fl") //Fanli
	KeyNotValidBetGameList           = NewCacheKey("Key_Not_Valid_Bet_Game_List")
	KeyOnceHistoryByAcctLastIdLimit  = NewCacheKeyP5[int64, int64, int32, int64, int64]("Key_once_history_By_acct_lastid_limit_%v_%v_%v_%v_%v", "Key_once_history_By_acct_lastid_limit")
	KeyGetPartitionByChannelId       = NewCacheKeyP1[int64]("key_get_partition_channel_id_%v", "key_get_partition_channel_id") //partition
	KeyAccountByInvite               = NewCacheKeyP1[string]("account_by_invite_%s", "account_by_invite")
	KeyActLuckyByCode                = NewCacheKeyP1[int64]("Key_Act_Lucky_By_Code_%v", "Key_Act_Lucky_By_Code") //ActivityRecharge
	KeyActLuckyByLatest              = NewCacheKey("Key_Act_Lucky_By_Latest")
	KeyLuckyTotalPoolAmount          = NewCacheKeyP1[int64]("Key_Lucky_Total_Pool_Amount_%v", "Key_Lucky_Total_Pool_Amount") //GameCompany
	KeyGoldFavAmount                 = NewCacheKeyP1[int64]("Key_Gold_Fav_%v", "Key_Gold_Fav")                               //goldfav
	KeyShouCiChongzhiLog             = NewCacheKey("key_shoucichongzhi_log")                                                 //首次充值日志
	KeyWelfareTaskList               = NewCacheKeyP1[string]("welfare_taskList_%v", "welfare_taskList_")                     //福利中心
	KeyVerifyCode                    = NewCacheKeyP1[string]("key_verify_code_%v", "device")                                 //验证码
	KeJinBiaoSaiList                 = NewCacheKey("jin_biao_sai_List")                                                      //锦标赛
	KeyAccountChannelId              = NewCacheKeyP1[int64]("key_account_channel_%d", "key_account_channel")                 //渠道数据
	KeyActivityRankList              = NewCacheKeyP1[int32]("activity_rank_%d", "activity_rank")                             //排行榜
	KeyActivityRankSelfList          = NewCacheKeyP1[string]("activity_rank_self_%s", "activity_rank_self")                  //排行榜自身数据
	KeyFanshuiRatioGameId            = NewCacheKeyP1[int64]("fanshui_ratio_game_id_%v", "fanshui_ratio_game_id")             //返水比例
	KeyLeijichongzhiLog              = NewCacheKey("key_leijichongzhi_log")                                                  //累计充值日志
	KeyPWDQuestionList               = NewCacheKeyP1[string]("key_question_list_%s", "key_question_list_")                   //密保问题
	KeyAgentCommissionLog            = NewCacheKeyP1[int64]("agent_commission_log_%v", "agent_commission_log")               //佣金使用日志
)

type ExprKey interface {
	Expr() string
}

type Key interface {
	Key() string
	ExprKey
}

type CacheKey struct {
	key string
}

func NewCacheKey(k string) *CacheKey {
	return &CacheKey{key: k}
}

func (key *CacheKey) Key() string {
	return key.key
}

func (key *CacheKey) Expr() string {
	return key.key
}

type CacheKeyP1[PT any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP1[PT any](k string, expr string) *CacheKeyP1[PT] {
	return &CacheKeyP1[PT]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP1[PT]) P1(t PT) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, t),
	}
}

func (key *CacheKeyP1[PT]) Expr() string {
	return key.matchExpr
}

type CacheKeyP2[PT1 any, PT2 any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP2[PT1 any, PT2 any](k string, expr string) *CacheKeyP2[PT1, PT2] {
	return &CacheKeyP2[PT1, PT2]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP2[PT1, PT2]) P2(p1 PT1, p2 PT2) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, p1, p2),
	}
}

func (key *CacheKeyP2[PT1, PT2]) Expr() string {
	return key.matchExpr
}

type CacheKeyP3[PT1 any, PT2 any, PT3 any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP3[PT1 any, PT2 any, PT3 any](k string, expr string) *CacheKeyP3[PT1, PT2, PT3] {
	return &CacheKeyP3[PT1, PT2, PT3]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP3[PT1, PT2, PT3]) P3(p1 PT1, p2 PT2, p3 PT3) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, p1, p2, p3),
	}
}

func (key *CacheKeyP3[PT1, PT2, PT3]) Expr() string {
	return key.matchExpr
}

type CacheKeyP4[PT1 any, PT2 any, PT3 any, PT4 any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP4[PT1 any, PT2 any, PT3 any, PT4 any](k string, expr string) *CacheKeyP4[PT1, PT2, PT3, PT4] {
	return &CacheKeyP4[PT1, PT2, PT3, PT4]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP4[PT1, PT2, PT3, PT4]) P4(p1 PT1, p2 PT2, p3 PT3, p4 PT4) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, p1, p2, p3, p4),
	}
}

func (key *CacheKeyP4[PT1, PT2, PT3, PT4]) Expr() string {
	return key.matchExpr
}

type CacheKeyP5[PT1 any, PT2 any, PT3 any, PT4 any, PT5 any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP5[PT1 any, PT2 any, PT3 any, PT4 any, PT5 any](k string, expr string) *CacheKeyP5[PT1, PT2, PT3, PT4, PT5] {
	return &CacheKeyP5[PT1, PT2, PT3, PT4, PT5]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP5[PT1, PT2, PT3, PT4, PT5]) P5(p1 PT1, p2 PT2, p3 PT3, p4 PT4, p5 PT5) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, p1, p2, p3, p4, p5),
	}
}

func (key *CacheKeyP5[PT1, PT2, PT3, PT4, PT5]) Expr() string {
	return key.matchExpr
}

type CacheKeyP6[PT1 any, PT2 any, PT3 any, PT4 any, PT5 any, PT6 any] struct {
	fmtStr    string
	matchExpr string
}

func NewCacheKeyP6[PT1 any, PT2 any, PT3 any, PT4 any, PT5 any, PT6 any](k string, expr string) *CacheKeyP6[PT1, PT2, PT3, PT4, PT5, PT6] {
	return &CacheKeyP6[PT1, PT2, PT3, PT4, PT5, PT6]{fmtStr: k, matchExpr: expr}
}

func (key *CacheKeyP6[PT1, PT2, PT3, PT4, PT5, PT6]) P6(p1 PT1, p2 PT2, p3 PT3, p4 PT4, p5 PT5, p6 PT6) Key {
	return &CacheKey{
		key: fmt.Sprintf(key.fmtStr, p1, p2, p3, p4, p5, p6),
	}
}

func (key *CacheKeyP6[PT1, PT2, PT3, PT4, PT5, PT6]) Expr() string {
	return key.matchExpr
}
