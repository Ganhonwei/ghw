package ucache

import (
	"server/internals/generated/event_bus/evtbase"
	"server/internals/redisbus"
)

func RemoveRemoteCacheKeys(key ...string) {
	evt := &evtbase.CleanupCacheEvent{}
	evt.Keys = append(evt.Keys, key...)

	_ = redisbus.PublishTopic(redisbus.TopicCleanupCache, evt)
}

func RemoveRemoteCacheExpr(expr ExprKey) {
	evt := &evtbase.CleanupCacheEvent{MatchExpr: expr.Expr()}
	_ = redisbus.PublishTopic(redisbus.TopicCleanupCache, evt)
}
