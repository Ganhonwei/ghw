package ver

import (
	"flag"
	"os"
	"runtime/debug"

	"server/internals/logger"
)

var (
	flag_version = flag.Bool("version", false, "-version")
)

func CheckVersion() {

	if !flag.Parsed() {
		flag.Parse()
	}

	PrintVersion()
	if *flag_version {
		os.Exit(0)
	}
}

func PrintVersion() {
	bi, ok := debug.ReadBuildInfo()
	if !ok {
		panic("PrintVersion: debug.ReadBuildInfo()")
	}

	logger.Sys.Infof("BuildInfo: %s", bi.String())
}
