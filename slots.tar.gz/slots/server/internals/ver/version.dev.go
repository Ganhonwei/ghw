//go:build dev
// +build dev

package ver

func getVersion() string {
	return "Dev"
}
