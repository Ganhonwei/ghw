package saccount

import (
	"sync"
	"time"
)

type updateLastVisitAt struct {
	id  int64
	vip int32
}

var (
	updateLastVisitAtCh = make(chan *updateLastVisitAt, 1000)
	closeCh             = make(chan bool)
	wg                  = sync.WaitGroup{}
)

func Start() {
	wg.Add(1)

	doit := func(map[int64]int32) {

	}

	go func() {
		defer wg.Done()
		t := time.NewTicker(100 * time.Millisecond)

		cachedOp := map[int64]int32{}

		for {
			select {
			case <-closeCh:
				// TODO close and save

				for u := range updateLastVisitAtCh {
					cachedOp[u.id] = u.vip
					if len(cachedOp) >= 500 {
						// TODO batch do it
						doit(cachedOp)
						cachedOp = map[int64]int32{}
					}
				}
				if len(cachedOp) > 0 {
					doit(cachedOp)
					cachedOp = map[int64]int32{}
				}
				return

			case u := <-updateLastVisitAtCh:
				// TODO batch save
				cachedOp[u.id] = u.vip
				if len(cachedOp) >= 500 {
					// TODO batch do it
					doit(cachedOp)
					cachedOp = map[int64]int32{}
				}

			case <-t.C:
				// TODO
				doit(cachedOp)
				cachedOp = map[int64]int32{}

			}

		}

	}()
}

func Stop() {
	close(closeCh)
	wg.Wait()
}

func AddUpateLastVisitAt(id int64, vipLevel int32) {
	updateLastVisitAtCh <- &updateLastVisitAt{id, vipLevel}
}
