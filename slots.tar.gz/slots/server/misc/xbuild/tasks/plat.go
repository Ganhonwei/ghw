package tasks

import (
	"fmt"
	"server/misc/xbuild/conf"
	"server/misc/xbuild/tasks/runtask"
)

func init() {
	registerTask(&Task{
		Order:       12,
		Name:        "Plat",
		defSelected: true,
		Type:        TaskType_Game,
		DoWork: func() error {
			return runtask.GoBuild(
				conf.GetOSName(),
				"server/cmd/plat",
				fmt.Sprintf("dist/%s/plat", conf.GetOSName()))
		},
	})
}
