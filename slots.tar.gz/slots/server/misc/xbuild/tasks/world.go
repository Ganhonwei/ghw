package tasks

import (
	"fmt"
	"server/misc/xbuild/conf"
	"server/misc/xbuild/tasks/runtask"
)

func init() {
	registerTask(&Task{
		Order:       13,
		Name:        "World",
		defSelected: true,
		Type:        TaskType_Game,
		DoWork: func() error {
			return runtask.GoBuild(
				conf.GetOSName(),
				"server/cmd/world",
				fmt.Sprintf("dist/%s/world", conf.GetOSName()))
		},
	})
}
