package tasks

import (
	"fmt"
	"server/misc/xbuild/conf"
	"server/misc/xbuild/tasks/runtask"
)

func init() {
	registerTask(&Task{
		Order:       1000,
		Name:        "Migrate DB",
		defSelected: true,
		Type:        TaskType_Misc,
		DoWork: func() error {
			return runtask.GoBuild(
				conf.GetOSName(),
				"server/cmd/tools/migrate_db",
				fmt.Sprintf("dist/%s/migrate_db", conf.GetOSName()))
		},
	})
}
